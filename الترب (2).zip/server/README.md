# خادم لعبة الترب الحاكم (Tirb Authoritative Game Server)

خادم لعبة بطاقات الترب التنافسية المعتمد للنشر على **Google Cloud Run** أو أي بيئة حاويات Docker.

## ميزات الخادم:
1. **مرجع وحيد لحالة اللعبة (Authoritative Server):**
   - التحقق من صلاحية المزايدات (100 - 187).
   - التحقق من قاعدة الإلزام لفئة البداية (Leading Suit Rule).
   - احتساب أكلات الجوكر (25ن في الكراول) وباقي الأوراق.
   - منع أي تعديل مباشر من جانب العميل.

2. **نظام المطابقة (Matchmaking):**
   - توليد رموز غرف قصيرة مثل `TRB-7824`.
   - روابط انضمام مباشرة.
   - دعم غرف متعددة في نفس الوقت.

3. **المزامنة اللحظية ومعالجة انقطاع الاتصال:**
   - بث لحظي عبر WebSocket / Socket.io.
   - استعادة المقعد والأوراق فور إعادة الاتصال.

## أوامر النشر على Google Cloud Run:

```bash
# 1. الدخول لمجلد السيرفر
cd server

# 2. بناء ونشر الحاوية على Cloud Run
gcloud run deploy tirb-authoritative-server \
  --source . \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --port 8080
```
