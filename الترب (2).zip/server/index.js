const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

const PORT = process.env.PORT || 8080;

// In-Memory Authoritative Rooms Registry
const rooms = new Map();

// Suits and Ranks Definition
const SUITS = {
  SPADES: { name: 'SPADES', arabic: 'سبيك', symbol: '♠', isRed: false },
  HEARTS: { name: 'HEARTS', arabic: 'هتين', symbol: '♥', isRed: true },
  DIAMONDS: { name: 'DIAMONDS', arabic: 'ديمن', symbol: '♦', isRed: true },
  CLUBS: { name: 'CLUBS', arabic: 'كراول', symbol: '♣', isRed: false }
};

const RANKS = {
  TWO: { power: 16, label: '2', points: 10 },
  ACE: { power: 13, label: 'A', points: 11 },
  KING: { power: 12, label: 'K', points: 4 },
  QUEEN: { power: 11, label: 'Q', points: 4 },
  JACK: { power: 10, label: 'J', points: 4 },
  TEN: { power: 9, label: '10', points: 10 },
  NINE: { power: 8, label: '9', points: 0 },
  EIGHT: { power: 7, label: '8', points: 0 },
  SEVEN: { power: 6, label: '7', points: 0 },
  SIX: { power: 5, label: '6', points: 0 }
};

function createDeck() {
  const deck = [];
  for (const suitKey in SUITS) {
    const suit = SUITS[suitKey];
    for (const rankKey in RANKS) {
      const rank = RANKS[rankKey];
      let points = rank.points;
      let isJoker = false;
      if (rankKey === 'TWO') {
        if (suitKey === 'CLUBS') {
          points = 25; // Joker
          isJoker = true;
        } else {
          points = 10;
        }
      }
      deck.push({
        id: `${suitKey}_${rankKey}`,
        suit: suitKey,
        rank: rankKey,
        points,
        power: rank.power,
        isJoker
      });
    }
  }
  return deck;
}

function shuffle(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

// REST Endpoints
app.get('/health', (req, res) => {
  res.json({ status: 'ok', uptime: process.uptime(), roomsCount: rooms.size });
});

app.get('/api/rooms', (req, res) => {
  const publicRooms = [];
  for (const [code, room] of rooms.entries()) {
    publicRooms.push({
      roomId: room.roomId,
      roomCode: room.roomCode,
      roomName: room.roomName,
      hostName: room.hostName,
      playersCount: room.players.length,
      phase: room.gameState.phase,
      isGameStarted: room.gameState.phase !== 'LOBBY'
    });
  }
  res.json({ rooms: publicRooms });
});

app.post('/api/rooms/create', (req, res) => {
  const { roomName, hostUid, hostName, avatarEmoji } = req.body;
  const roomCode = `TRB-${Math.floor(1000 + Math.random() * 9000)}`;

  const newRoom = {
    roomId: roomCode,
    roomCode,
    roomName: roomName || `طاولة ${roomCode}`,
    hostUid,
    hostName: hostName || 'لاعب',
    players: [
      {
        uid: hostUid,
        seatId: 0,
        username: hostName || 'المستضيف',
        avatarEmoji: avatarEmoji || '👑',
        hand: [],
        currentBid: 0,
        hasPassed: false,
        pointsWon: 0,
        tricksWon: 0,
        redCards: 0,
        blackCards: 0,
        isConnected: true,
        isHost: true
      }
    ],
    gameState: {
      phase: 'LOBBY',
      roundNumber: 1,
      dealerSeatId: 0,
      currentTurnSeatId: 0,
      starterSeatId: 0,
      currentAuctionBid: 0,
      winningBid: 0,
      buyerSeatId: null,
      trumpSuit: null,
      fieldCards: [],
      currentTrickPlays: [],
      lastTrickPlays: [],
      lastActionLog: `تم إنشاء الغرفة بواسطة ${hostName}`
    }
  };

  rooms.set(roomCode, newRoom);
  res.json({ success: true, roomCode, inviteLink: `https://tirb-game.web.app/join/${roomCode}` });
});

// WebSocket Connection Handling
io.on('connection', (socket) => {
  let currentRoomCode = null;
  let userUid = null;

  socket.on('join_room', ({ roomCode, uid, username, avatarEmoji }) => {
    const room = rooms.get(roomCode);
    if (!room) {
      socket.emit('error_message', 'الغرفة غير موجودة');
      return;
    }

    currentRoomCode = roomCode;
    userUid = uid;
    socket.join(roomCode);

    let player = room.players.find(p => p.uid === uid);
    if (!player) {
      if (room.players.length >= 5) {
        socket.emit('error_message', 'الغرفة ممتلئة (5 لاعبين كحد أقصى)');
        return;
      }
      const nextSeat = [0, 1, 2, 3, 4].find(s => !room.players.some(p => p.seatId === s));
      player = {
        uid,
        seatId: nextSeat,
        username: username || 'لاعب',
        avatarEmoji: avatarEmoji || '🎴',
        hand: [],
        currentBid: 0,
        hasPassed: false,
        pointsWon: 0,
        tricksWon: 0,
        redCards: 0,
        blackCards: 0,
        isConnected: true,
        isHost: false
      };
      room.players.push(player);
    } else {
      player.isConnected = true;
    }

    io.to(roomCode).emit('room_state_update', room);
  });

  socket.on('player_action', ({ roomCode, actionType, payload }) => {
    const room = rooms.get(roomCode);
    if (!room) return;

    // Process Authoritative Action
    switch (actionType) {
      case 'START_MATCH': {
        if (room.players.length !== 5) {
          socket.emit('error_message', 'يجب اكتمال 5 لاعبين لبدء لعبة الترب');
          return;
        }
        dealNewRound(room, 0);
        break;
      }

      case 'PLACE_BID': {
        const { uid, bidAmount } = payload;
        const currentP = room.players.find(p => p.seatId === room.gameState.currentTurnSeatId);
        if (!currentP || currentP.uid !== uid) return;

        if (bidAmount <= room.gameState.currentAuctionBid || bidAmount < 100 || bidAmount > 187) {
          socket.emit('error_message', 'قيمة المزايدة غير صحيحة');
          return;
        }

        currentP.currentBid = bidAmount;
        room.gameState.currentAuctionBid = bidAmount;
        room.gameState.winningBid = bidAmount;
        room.gameState.buyerSeatId = currentP.seatId;

        if (bidAmount >= 187) {
          room.gameState.phase = 'FIELD_DISTRIBUTION';
          room.gameState.currentTurnSeatId = currentP.seatId;
          room.gameState.lastActionLog = `${currentP.username} وصل للحد الأقصى (187) وفاز بالمزاد!`;
        } else {
          room.gameState.currentTurnSeatId = getNextActiveSeat(room.players, currentP.seatId);
          room.gameState.lastActionLog = `${currentP.username} رفع المزاد إلى ${bidAmount}`;
        }
        break;
      }

      case 'PASS_BID': {
        const { uid } = payload;
        const currentP = room.players.find(p => p.seatId === room.gameState.currentTurnSeatId);
        if (!currentP || currentP.uid !== uid) return;

        currentP.hasPassed = true;
        const active = room.players.filter(p => !p.hasPassed);
        if (active.length <= 1) {
          const winner = active[0] || room.players.find(p => p.seatId === room.gameState.buyerSeatId) || room.players[0];
          room.gameState.phase = 'FIELD_DISTRIBUTION';
          room.gameState.buyerSeatId = winner.seatId;
          room.gameState.winningBid = Math.max(100, room.gameState.currentAuctionBid);
          room.gameState.currentTurnSeatId = winner.seatId;
          room.gameState.lastActionLog = `فاز ${winner.username} بالمزاد بـ ${room.gameState.winningBid} نقطة!`;
        } else {
          room.gameState.currentTurnSeatId = getNextActiveSeat(room.players, currentP.seatId);
          room.gameState.lastActionLog = `قال ${currentP.username} باص في المزاد`;
        }
        break;
      }

      case 'DECLARE_TRUMP': {
        const { uid, suit } = payload;
        if (room.gameState.buyerSeatId !== room.players.find(p => p.uid === uid)?.seatId) return;

        room.gameState.trumpSuit = suit;
        room.gameState.phase = 'PLAYING';
        room.gameState.currentTurnSeatId = room.gameState.starterSeatId;
        room.gameState.lastActionLog = `أعلن المشتري الترب (${SUITS[suit]?.arabic || suit})! بدأت الأكلات.`;
        break;
      }

      case 'PLAY_CARD': {
        const { uid, cardId } = payload;
        const currentP = room.players.find(p => p.seatId === room.gameState.currentTurnSeatId);
        if (!currentP || currentP.uid !== uid) return;

        // Card validation & playing logic
        currentP.hand = currentP.hand.filter(c => c !== cardId);
        room.gameState.currentTrickPlays.push({
          seatId: currentP.seatId,
          cardId,
          playerName: currentP.username
        });

        if (room.gameState.currentTrickPlays.length === 5) {
          // Resolve trick
          resolveTrick(room);
        } else {
          room.gameState.currentTurnSeatId = (room.gameState.currentTurnSeatId + 1) % 5;
        }
        break;
      }
    }

    io.to(roomCode).emit('room_state_update', room);
  });

  socket.on('disconnect', () => {
    if (currentRoomCode && userUid) {
      const room = rooms.get(currentRoomCode);
      if (room) {
        const player = room.players.find(p => p.uid === userUid);
        if (player) {
          player.isConnected = false;
          io.to(currentRoomCode).emit('room_state_update', room);
        }
      }
    }
  });
});

function getNextActiveSeat(players, currentSeat) {
  let next = (currentSeat + 1) % 5;
  while (players.find(p => p.seatId === next)?.hasPassed) {
    next = (next + 1) % 5;
  }
  return next;
}

function dealNewRound(room, dealerSeat) {
  const deck = shuffle(createDeck());
  let cardIdx = 0;

  room.players.forEach(p => {
    p.hand = deck.slice(cardIdx, cardIdx + 7).map(c => c.id);
    cardIdx += 7;
    p.currentBid = 0;
    p.hasPassed = p.redCards >= 2;
    p.pointsWon = 0;
    p.tricksWon = 0;
  });

  room.gameState.fieldCards = deck.slice(cardIdx, cardIdx + 5).map(c => c.id);
  room.gameState.dealerSeatId = dealerSeat;
  room.gameState.starterSeatId = (dealerSeat + 1) % 5;
  room.gameState.currentTurnSeatId = room.gameState.starterSeatId;
  room.gameState.phase = 'AUCTION';
  room.gameState.currentAuctionBid = 0;
  room.gameState.winningBid = 0;
  room.gameState.buyerSeatId = null;
  room.gameState.currentTrickPlays = [];
}

function resolveTrick(room) {
  const plays = room.gameState.currentTrickPlays;
  const deck = createDeck();
  const trump = room.gameState.trumpSuit;
  const leadingSuit = deck.find(c => c.id === plays[0].cardId)?.suit;

  let winnerPlay = plays[0];
  let highestPower = -1;

  for (const play of plays) {
    const card = deck.find(c => c.id === play.cardId);
    if (!card) continue;

    let score = card.power;
    if (card.suit === trump) score += 100;
    else if (card.suit === leadingSuit) score += 50;

    if (score > highestPower) {
      highestPower = score;
      winnerPlay = play;
    }
  }

  const trickPoints = plays.reduce((acc, p) => {
    const c = deck.find(card => card.id === p.cardId);
    return acc + (c ? c.points : 0);
  }, 0);

  const winningPlayer = room.players.find(p => p.seatId === winnerPlay.seatId);
  if (winningPlayer) {
    winningPlayer.pointsWon += trickPoints;
    winningPlayer.tricksWon += 1;
  }

  room.gameState.lastTrickPlays = [...plays];
  room.gameState.currentTrickPlays = [];
  room.gameState.currentTurnSeatId = winnerPlay.seatId;
  room.gameState.lastActionLog = `أكل ${winnerPlay.playerName} الأكلة ونال ${trickPoints} نقطة!`;
}

server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
