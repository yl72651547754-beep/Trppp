package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.audio.SoundManager
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class SoundManagerTest {

    @Test
    fun testSoundManagerLifecycleAndAudioTriggers() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val soundManager = SoundManager.getInstance(context)

        assertNotNull(soundManager)
        assertTrue(soundManager.isSoundEnabled.value)

        // Test safe execution of required audio events
        soundManager.playCardDeal()
        soundManager.playAuctionBid()
        soundManager.playRoundWin()
        soundManager.playRoundLose()
        soundManager.playCardPlay()
        soundManager.playTrickWin()

        // Test toggle sound
        val toggled = soundManager.toggleSound()
        assertFalse(toggled)
        assertFalse(soundManager.isSoundEnabled.value)

        // Sound plays should be safely muted without crashing
        soundManager.playCardDeal()
        soundManager.playAuctionBid()
        soundManager.playRoundWin()

        // Re-enable sound
        soundManager.setSoundEnabled(true)
        assertTrue(soundManager.isSoundEnabled.value)
    }
}
