package com.example

import com.example.logic.TirbGameLogic
import com.example.model.Card
import com.example.model.Rank
import com.example.model.Suit
import com.example.model.TrickPlay
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TirbGameLogicTest {

    @Test
    fun testDeckCreationAndTotalPoints() {
        val deck = TirbGameLogic.createDeck()
        // يجب أن تحتوي الرزمة على 40 ورقة فقط (10 أوراق لكل فئة من الفئات الـ 4)
        assertEquals(40, deck.size)

        // التحقق من أن كل فئة تحتوي على 10 أوراق فقط
        for (suit in Suit.entries) {
            val suitCards = deck.filter { it.suit == suit }
            assertEquals(10, suitCards.size)
            val ranksInSuit = suitCards.map { it.rank }.toSet()
            assertEquals(
                setOf(
                    Rank.TWO, Rank.ACE, Rank.KING, Rank.QUEEN, Rank.JACK,
                    Rank.TEN, Rank.NINE, Rank.EIGHT, Rank.SEVEN, Rank.SIX
                ),
                ranksInSuit
            )
        }

        // إجمالي النقاط الثابت = 187 نقطة
        val totalPoints = TirbGameLogic.verifyDeckTotalPoints(deck)
        assertEquals(187, totalPoints)

        // التحقق من أن 2 كراول هي الجوكر وتساوي 25 نقطة
        val clubsTwo = deck.find { it.suit == Suit.CLUBS && it.rank == Rank.TWO }
        assertTrue(clubsTwo?.isJoker == true)
        assertEquals(25, clubsTwo?.points)

        // التحقق من أن الرقم 2 في فئات (سبيت، حمرا، دمني) يساوي 10 نقاط
        val twos = deck.filter { it.rank == Rank.TWO }
        assertEquals(4, twos.size)
        assertEquals(25, twos.find { it.suit == Suit.CLUBS }?.points)
        assertEquals(10, twos.find { it.suit == Suit.SPADES }?.points)
        assertEquals(10, twos.find { it.suit == Suit.HEARTS }?.points)
        assertEquals(10, twos.find { it.suit == Suit.DIAMONDS }?.points)

        // التحقق من عدم وجود رتب 3، 4، 5 أو جواكر خارجية في الرزمة
        assertFalse(deck.any { it.rank == Rank.THREE || it.rank == Rank.FOUR || it.rank == Rank.FIVE })
        assertFalse(deck.any { it.rank == Rank.JOKER_BIG || it.rank == Rank.JOKER_SMALL })
    }

    @Test
    fun testGoldenRuleLogic() {
        // حالة فوز المشتري: مجموع نقاط الخصوم + المزاد <= 187
        val opponentsPoints1 = 60
        val winningBid1 = 120
        val sum1 = opponentsPoints1 + winningBid1 // 180 <= 187
        assertTrue(sum1 <= 187)

        // حالة التساوي مع السقف بالضبط (187 = 187) -> فوز المشتري
        val opponentsPointsExact = 67
        val winningBidExact = 120
        val sumExact = opponentsPointsExact + winningBidExact // 187
        assertTrue(sumExact <= 187)

        // حالة خسارة المشتري: مجموع نقاط الخصوم + المزاد > 187
        val opponentsPointsLoss = 70
        val winningBidLoss = 120
        val sumLoss = opponentsPointsLoss + winningBidLoss // 190 > 187
        assertFalse(sumLoss <= 187)
    }

    @Test
    fun testTrickWinnerDetermination() {
        // إذا كان الترب هو الكراول
        val trumpSuit = Suit.CLUBS
        val leadingSuit = Suit.SPADES

        val plays = listOf(
            TrickPlay(playerId = 0, playerName = "أنت", card = Card("S_K", Suit.SPADES, Rank.KING, 4)),
            TrickPlay(playerId = 1, playerName = "سارة", card = Card("S_A", Suit.SPADES, Rank.ACE, 11)),
            TrickPlay(playerId = 2, playerName = "فهد", card = Card("C_7", Suit.CLUBS, Rank.SEVEN, 0)), // قطع بالترب
            TrickPlay(playerId = 3, playerName = "نورة", card = Card("S_10", Suit.SPADES, Rank.TEN, 10)),
            TrickPlay(playerId = 4, playerName = "كريم", card = Card("H_2", Suit.HEARTS, Rank.TWO, 10))
        )

        // فهد قطع بالترب لذلك هو الفائز
        val winner = TirbGameLogic.determineTrickWinner(plays, leadingSuit, trumpSuit)
        assertEquals(2, winner.playerId)
    }

    @Test
    fun testRedAndBlackCardRules() {
        val player = com.example.model.Player(
            id = 0,
            name = "أنت",
            isHuman = true,
            redCards = 1,
            blackCards = 1
        )
        assertFalse(player.isExemptFromAuction)
        assertFalse(player.isEliminated)

        // فوز المشتري بكرتين حمر -> يخرج من طور الشراء
        val winnerPlayer = player.copy(redCards = 2)
        assertTrue(winnerPlayer.isExemptFromAuction)
        assertFalse(winnerPlayer.isEliminated)

        // خسارة لاعب بكرتين سود -> استبعاد / خسارة وتنتهي اللعبة
        val eliminatedPlayer = player.copy(blackCards = 2)
        assertFalse(eliminatedPlayer.isExemptFromAuction)
        assertTrue(eliminatedPlayer.isEliminated)
    }

    @Test
    fun testDealerRotationSequence() {
        var currentDealer = 0
        val dealers = mutableListOf<Int>()
        val starters = mutableListOf<Int>()

        repeat(5) {
            dealers.add(currentDealer)
            val starter = (currentDealer + 1) % 5
            starters.add(starter)
            currentDealer = (currentDealer + 1) % 5
        }

        // توزيع الورق يمشي بالتتالي: 0، 1، 2، 3، 4
        assertEquals(listOf(0, 1, 2, 3, 4), dealers)
        // من يبدأ هو أول شخص بعد الموزع: 1، 2، 3، 4، 0
        assertEquals(listOf(1, 2, 3, 4, 0), starters)
    }

    @Test
    fun testInitialDealAndHiddenFieldCards() {
        val deck = TirbGameLogic.createDeck().shuffled()
        val players = TirbGameLogic.createInitialPlayers().toMutableList()
        var cardIndex = 0
        for (p in players.indices) {
            val hand = deck.subList(cardIndex, cardIndex + 7)
            players[p] = players[p].copy(hand = TirbGameLogic.sortHand(hand))
            cardIndex += 7
        }
        val field = deck.subList(cardIndex, cardIndex + 5)

        // كل لاعب يمتلك 7 أوراق يراها قبل المزاد
        assertEquals(7, players[0].hand.size)
        // أوراق الميدان 5 أوراق غير مكشوفة
        assertEquals(5, field.size)
    }

    @Test
    fun testBuyerDistributionFrom12Cards() {
        val deck = TirbGameLogic.createDeck()
        val buyerHand = deck.subList(0, 7)
        val fieldCards = deck.subList(7, 12)
        val combined12 = buyerHand + fieldCards
        assertEquals(12, combined12.size)

        val otherPlayerIds = listOf(1, 2, 3, 4)
        val assignments = TirbGameLogic.aiDistributeFieldCards(
            aiPlayerId = 0,
            buyerCombinedHand = combined12,
            otherPlayerIds = otherPlayerIds,
            trumpSuit = null
        )

        assertEquals(5, assignments.size)
        // أوراق موزعة للخصوم الـ 4
        for (id in otherPlayerIds) {
            assertTrue(assignments.containsKey(id))
        }
        // ورقة مخصصة للمشتري
        assertTrue(assignments.containsKey(0))

        // الأوراق المتبقية للمشتري بعد إعطاء 4 أوراق للخصوم = 8 أوراق
        val givenToOthers = assignments.filter { it.key != 0 }.values.map { it.id }
        val remainingForBuyer = combined12.filter { it.id !in givenToOthers }
        assertEquals(8, remainingForBuyer.size)
    }

    @Test
    fun testTwoIsStrongestRankInFieldAndTricks() {
        // التحقق من أن قوة الرقم 2 هي الأعلى في اللعبة (16)
        assertEquals(16, Rank.TWO.power)
        assertTrue(Rank.TWO.power > Rank.ACE.power)
        assertTrue(Rank.TWO.power > Rank.KING.power)
        assertTrue(Rank.TWO.power > Rank.JOKER_BIG.power)

        // اختبار جولة عادية بدون ترب: الرقم 2 يفوز على الآس والشايب من نفس الفئة
        val normalPlays = listOf(
            TrickPlay(playerId = 0, playerName = "أنت", card = Card("S_2", Suit.SPADES, Rank.TWO, 10)),
            TrickPlay(playerId = 1, playerName = "سارة", card = Card("S_A", Suit.SPADES, Rank.ACE, 11)),
            TrickPlay(playerId = 2, playerName = "فهد", card = Card("S_K", Suit.SPADES, Rank.KING, 4)),
            TrickPlay(playerId = 3, playerName = "نورة", card = Card("S_10", Suit.SPADES, Rank.TEN, 10)),
            TrickPlay(playerId = 4, playerName = "كريم", card = Card("S_9", Suit.SPADES, Rank.NINE, 0))
        )
        val winnerNormal = TirbGameLogic.determineTrickWinner(normalPlays, Suit.SPADES, Suit.HEARTS)
        assertEquals(0, winnerNormal.playerId) // ورقة S_2 للاعب "أنت" تفوز على الجميع

        // اختبار فئة الترب: 2 الترب يفوز على الجوكر الكبير
        val trumpPlays = listOf(
            TrickPlay(playerId = 1, playerName = "سارة", card = Card("S_A", Suit.SPADES, Rank.ACE, 11)),
            TrickPlay(playerId = 2, playerName = "فهد", card = Card("C_JOKER_BIG", Suit.CLUBS, Rank.JOKER_BIG, 0, isJoker = true)),
            TrickPlay(playerId = 3, playerName = "نورة", card = Card("C_2", Suit.CLUBS, Rank.TWO, 25))
        )
        val winnerTrump = TirbGameLogic.determineTrickWinner(trumpPlays, Suit.SPADES, Suit.CLUBS)
        assertEquals(3, winnerTrump.playerId) // نورة تفوز بـ 2 الترب
    }

    @Test
    fun testAiSmartBidding() {
        val field = TirbGameLogic.createDeck().take(5)

        // يد ضعيفة جداً (كلها أوراق 0 نقاط وبدون أوراق 2 أو آسات)
        val weakHand = listOf(
            Card("S_6", Suit.SPADES, Rank.SIX, 0),
            Card("S_7", Suit.SPADES, Rank.SEVEN, 0),
            Card("H_8", Suit.HEARTS, Rank.EIGHT, 0),
            Card("D_9", Suit.DIAMONDS, Rank.NINE, 0),
            Card("C_6", Suit.CLUBS, Rank.SIX, 0),
            Card("C_7", Suit.CLUBS, Rank.SEVEN, 0),
            Card("H_6", Suit.HEARTS, Rank.SIX, 0)
        )
        // الذكاء لا يجازف بيده الضعيفة في المزاد
        val weakBid = TirbGameLogic.calculateAiBid(weakHand, field, 100)
        assertEquals(null, weakBid)

        // يد قوية جداً (2 كراول 25ن + آس كراول 11ن + شايب كراول 4ن + 2 سبيت 10ن + آس سبيت 11ن)
        val strongHand = listOf(
            Card("C_2", Suit.CLUBS, Rank.TWO, 25, isJoker = true),
            Card("C_A", Suit.CLUBS, Rank.ACE, 11),
            Card("C_K", Suit.CLUBS, Rank.KING, 4),
            Card("C_Q", Suit.CLUBS, Rank.QUEEN, 4),
            Card("C_J", Suit.CLUBS, Rank.JACK, 4),
            Card("S_2", Suit.SPADES, Rank.TWO, 10),
            Card("S_A", Suit.SPADES, Rank.ACE, 11)
        )
        val strongBid = TirbGameLogic.calculateAiBid(strongHand, field, 100)
        assertTrue(strongBid != null && strongBid >= 105)
    }

    @Test
    fun testAiSmartCardPlayingDefenderCooperation() {
        // اختبار تعاون المدافعين: الزميل فائز بأكلة فيها 2 سبيت، والذكاء لديه فئة البداية
        // يقوم الذكاء برمي ورقة نقاط (10) لزميله لتسجيل النقاط لصالح الدفاع
        val partnerWinningPlays = listOf(
            TrickPlay(playerId = 1, playerName = "سارة (المشتري)", card = Card("S_K", Suit.SPADES, Rank.KING, 4)),
            TrickPlay(playerId = 2, playerName = "فهد (زميل)", card = Card("S_2", Suit.SPADES, Rank.TWO, 10))
        )
        val aiHand = listOf(
            Card("S_6", Suit.SPADES, Rank.SIX, 0),
            Card("S_10", Suit.SPADES, Rank.TEN, 10),
            Card("H_A", Suit.HEARTS, Rank.ACE, 11)
        )
        val chosenCard = TirbGameLogic.chooseAiCardToPlay(
            hand = aiHand,
            leadingSuit = Suit.SPADES,
            trumpSuit = Suit.CLUBS,
            isBuyer = false,
            currentPlays = partnerWinningPlays,
            buyerId = 1,
            myPlayerId = 3
        )
        // لأن الزميل سيفوز حتماً بـ 2 سبيت، يقوم الذكاء بتشحيم الأكلة بـ 10 سبيت لصالح الزميل
        assertEquals("S_10", chosenCard.id)
    }

    @Test
    fun testAiSmartDistributionProtectsTrumpsAndPoints() {
        // يد المشتري المدمجة 12 ورقة (فيها أوراق ترب وأوراق 2 وأوراق 0 نقاط)
        val combined12 = listOf(
            Card("C_2", Suit.CLUBS, Rank.TWO, 25, isJoker = true), // ترب
            Card("C_A", Suit.CLUBS, Rank.ACE, 11),                // ترب
            Card("C_K", Suit.CLUBS, Rank.KING, 4),                 // ترب
            Card("C_10", Suit.CLUBS, Rank.TEN, 10),               // ترب
            Card("S_2", Suit.SPADES, Rank.TWO, 10),                // 2
            Card("S_A", Suit.SPADES, Rank.ACE, 11),                // آس
            Card("D_A", Suit.DIAMONDS, Rank.ACE, 11),             // آس
            Card("H_10", Suit.HEARTS, Rank.TEN, 10),              // 10
            Card("H_6", Suit.HEARTS, Rank.SIX, 0),                // ضعيفة
            Card("H_7", Suit.HEARTS, Rank.SEVEN, 0),              // ضعيفة
            Card("D_8", Suit.DIAMONDS, Rank.EIGHT, 0),            // ضعيفة
            Card("D_9", Suit.DIAMONDS, Rank.NINE, 0)              // ضعيفة
        )

        val assignments = TirbGameLogic.aiDistributeFieldCards(
            aiPlayerId = 0,
            buyerCombinedHand = combined12,
            otherPlayerIds = listOf(1, 2, 3, 4),
            trumpSuit = Suit.CLUBS
        )

        // الأوراق الموزعة للخصوم الـ 4 يجب أن تكون أوراق 0 نقاط وبدون أي ورقة ترب أو ورقة 2
        val cardsGivenToOpponents = listOf(1, 2, 3, 4).mapNotNull { assignments[it] }
        assertEquals(4, cardsGivenToOpponents.size)
        assertTrue(cardsGivenToOpponents.all { it.points == 0 })
        assertTrue(cardsGivenToOpponents.none { it.suit == Suit.CLUBS })
        assertTrue(cardsGivenToOpponents.none { it.rank == Rank.TWO })
    }

    @Test
    fun testBossCardDetection() {
        val aceOfSpades = Card("S_A", Suit.SPADES, Rank.ACE, 11)
        val twoOfSpades = Card("S_2", Suit.SPADES, Rank.TWO, 10)
        val kingOfSpades = Card("S_K", Suit.SPADES, Rank.KING, 4)

        // ورقة 2 هي دائماً سيد الفئة (Boss)
        assertTrue(TirbGameLogic.isBossCard(twoOfSpades, listOf(twoOfSpades), emptyList()))

        // ورقة الآس ليست سيدة الفئة إذا كان الـ 2 لم يُلعب بعد ولا يوجد في يد اللاعب
        assertFalse(TirbGameLogic.isBossCard(aceOfSpades, listOf(aceOfSpades), emptyList()))

        // بمجرد لعب ورقة 2، تصبح ورقة الآس هي سيدة الفئة الرسمية (Boss)
        assertTrue(TirbGameLogic.isBossCard(aceOfSpades, listOf(aceOfSpades), listOf(twoOfSpades)))

        // إذا لُعب الـ 2 والآس، يصبح الشايب هو سيد الفئة (Boss)
        assertTrue(TirbGameLogic.isBossCard(kingOfSpades, listOf(kingOfSpades), listOf(twoOfSpades, aceOfSpades)))
    }

    @Test
    fun testBuyerPullsTrumpsThenCashesBossCards() {
        val trumpTwo = Card("C_2", Suit.CLUBS, Rank.TWO, 25, isJoker = true)
        val sideAce = Card("S_A", Suit.SPADES, Rank.ACE, 11)
        val sideTwo = Card("S_2", Suit.SPADES, Rank.TWO, 10)

        val buyerHand = listOf(trumpTwo, sideAce)
        // الخصوم ما زال لديهم ترب
        val cardWhenTrumpsRemain = TirbGameLogic.chooseAiCardToPlay(
            hand = buyerHand,
            leadingSuit = null,
            trumpSuit = Suit.CLUBS,
            isBuyer = true,
            currentPlays = emptyList(),
            playedCardsHistory = emptyList() // لم يُلعب أي ترب
        )
        // المشتري يقود بـ 2 الترب لسحب ترب الخصوم
        assertEquals("C_2", cardWhenTrumpsRemain.id)

        // إذا تم استنزاف كافة أوراق الترب لدى الخصوم والـ 2 سبيت قد لُعبت
        val allOtherTrumps = TirbGameLogic.createDeck().filter { it.suit == Suit.CLUBS && it.id != "C_2" }
        val historyWithExhaustedTrumps = allOtherTrumps + sideTwo // تم لعب كل ترب الخصوم + 2 سبيت

        val handAfterTrumps = listOf(sideAce, Card("H_6", Suit.HEARTS, Rank.SIX, 0))
        val cardAfterTrumpsExhausted = TirbGameLogic.chooseAiCardToPlay(
            hand = handAfterTrumps,
            leadingSuit = null,
            trumpSuit = Suit.CLUBS,
            isBuyer = true,
            currentPlays = emptyList(),
            playedCardsHistory = historyWithExhaustedTrumps
        )
        // لأن تراب الخصوم انتهى ولُعب 2 سبيت، فإن آس سبيت سيد مضمون 100% ولا يمكن قطعه، فيلعبه المشتري
        assertEquals("S_A", cardAfterTrumpsExhausted.id)
    }

    @Test
    fun testAuctionStarterIsPlayerAfterDealerAndOpensFirstTrick() {
        // إذا كان الموزع هو اللاعب 0 (أنت)، فالبادئ بالمزاد هو اللاعب 1 (سارة)
        val dealer0 = 0
        val starter0 = (dealer0 + 1) % 5
        assertEquals(1, starter0)

        // إذا كان الموزع هو اللاعب 4 (عمر)، فالبادئ بالمزاد هو اللاعب 0 (أنت)
        val dealer4 = 4
        val starter4 = (dealer4 + 1) % 5
        assertEquals(0, starter4)

        // التحقق من أن من بدأ المزاد هو من يفتتح الجولة الأولى (الشولة 1 من 8)
        val testAuctionStarter = 2 // فهد بدأ المزاد
        val buyerPlayerId = 0      // أنت فزت بالمزاد واشتريت

        // بعد تصريح المشتري بنوع الترب، يجب أن تكون الشولة الأولى من نصيب من بدأ المزاد (اللاعب 2)
        val uiState = com.example.model.GameUIState(
            phase = com.example.model.GamePhase.TRICK_PLAYING,
            currentRound = 1,
            buyerId = buyerPlayerId,
            auctionStarterPlayerId = testAuctionStarter,
            currentTurnPlayerId = testAuctionStarter,
            starterPlayerId = testAuctionStarter
        )

        // اللاعب الحالي الذي عليه الدور لافتتاح أول جولة لعب هو من بدأ المزاد وليس المشتري
        assertEquals(testAuctionStarter, uiState.currentTurnPlayerId)
        assertEquals(testAuctionStarter, uiState.starterPlayerId)
    }
}
