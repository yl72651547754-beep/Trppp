package com.example.logic

import com.example.model.Card
import com.example.model.Player
import com.example.model.Rank
import com.example.model.Suit
import com.example.model.TrickPlay
import kotlin.random.Random

object TirbGameLogic {

    /**
     * الأوراق الـ 10 المشاركة في اللعبة لكل فئة:
     * رقم 2، اليكه (A)، الشايب (K)، البنت (Q)، الغلام (J)، 10، 9، 8، 7، 6
     * (4 فئات × 10 = 40 ورقة فقط تشارك بالكامل في اللعبة)
     */
    val ACTIVE_GAME_RANKS = Rank.ACTIVE_RANKS

    /**
     * إنشاء رزمة الورق المشاركة في اللعبة (40 ورقة: 10 أوراق في كل فئة من فئات الترب الأربع)
     * الأوراق المشاركة فقط: 2، اليكه، الشايب، البنت، الغلام، 10، 9، 8، 7، 6
     * رقم 2 في الكراول هي الجوكر وتساوي 25 نقطة.
     * رقم 2 في باقي الفئات تساوي 10 نقاط.
     * مجموع النقاط = 187 نقطة ثابتة.
     */
    fun createDeck(): List<Card> {
        val deck = mutableListOf<Card>()

        // 4 فئات × 10 أوراق = 40 ورقة
        for (suit in Suit.entries) {
            for (rank in ACTIVE_GAME_RANKS) {
                val points = when (rank) {
                    Rank.ACE -> 11
                    Rank.TEN -> 10
                    Rank.KING, Rank.QUEEN, Rank.JACK -> 4
                    Rank.TWO -> if (suit == Suit.CLUBS) 25 else 10 // في الكراول 25ن (الجوكر)، وفي باقي الفئات 10ن
                    else -> 0
                }

                deck.add(
                    Card(
                        id = "${suit.name}_${rank.name}",
                        suit = suit,
                        rank = rank,
                        points = points,
                        isJoker = (suit == Suit.CLUBS && rank == Rank.TWO)
                    )
                )
            }
        }

        return deck
    }

    private val cachedDeckMap by lazy {
        createDeck().associateBy { it.id }
    }

    fun getCardById(cardId: String): Card? {
        return cachedDeckMap[cardId]
    }

    /**
     * التحقق من مجموع النقاط الكلي في الرزمة (يجب أن يكون 187)
     */
    fun verifyDeckTotalPoints(deck: List<Card>): Int {
        return deck.sumOf { it.points }
    }

    /**
     * توزيع 5 لاعبين افتراضيين مع دعم اسم المستخدم المخصص
     */
    fun createInitialPlayers(humanName: String = "أنت"): List<Player> {
        return listOf(
            Player(id = 0, name = humanName, isHuman = true),
            Player(id = 1, name = "سارة", isHuman = false),
            Player(id = 2, name = "فهد", isHuman = false),
            Player(id = 3, name = "نورة", isHuman = false),
            Player(id = 4, name = "كريم", isHuman = false)
        )
    }

    /**
     * ترتيب اليد لتسهيل القراءة (حسب الفئة ثم القوة تنازلياً)
     */
    fun sortHand(hand: List<Card>, trumpSuit: Suit? = null): List<Card> {
        return hand.sortedWith(
            compareByDescending<Card> { card ->
                // وضع الترب في البداية إن وُجد
                if (trumpSuit != null && card.suit == trumpSuit) 100 else 0
            }.thenBy { card ->
                // ترتيب الفئات
                card.suit.ordinal
            }.thenByDescending { card ->
                card.rank.power
            }
        )
    }

    /**
     * فحص إمكانية لعب ورقة معينة وفق قاعدة الإلزام
     * إذا كان لدى اللاعب ورقة من نفس فئة البداية (leadingSuit)، وجب عليه لعبها.
     * ملاحظة: الجوكر تابع للكراول.
     */
    fun isCardPlayable(card: Card, hand: List<Card>, leadingSuit: Suit?): Boolean {
        if (leadingSuit == null) return true // أول لاعب في الجولة يمكنه لعب أي ورقة

        val hasLeadingSuit = hand.any { it.suit == leadingSuit }
        return if (hasLeadingSuit) {
            card.suit == leadingSuit
        } else {
            true // يحق له لعب أي ورقة أخرى بما فيها الترب
        }
    }

    /**
     * تحديد الفائز بالجولة
     * 1. إذا لُعبت أوراق ترب (trumpSuit)، فأعلى ورقة ترب تفوز.
     * 2. إن لم يُلعب ترب، فأعلى ورقة من فئة البداية (leadingSuit) تفوز.
     */
    fun determineTrickWinner(
        plays: List<TrickPlay>,
        leadingSuit: Suit,
        trumpSuit: Suit
    ): TrickPlay {
        val trumpPlays = plays.filter { it.card.suit == trumpSuit }
        return if (trumpPlays.isNotEmpty()) {
            trumpPlays.maxByOrNull { it.card.rank.power } ?: trumpPlays.first()
        } else {
            val leadingPlays = plays.filter { it.card.suit == leadingSuit }
            leadingPlays.maxByOrNull { it.card.rank.power } ?: plays.first()
        }
    }

    /**
     * فحص هل الورقة هي الأقوى حالياً في فئتها (سيد الفئة / Boss Card):
     * تفحص الأوراق التي لُعبت سابقاً وتلك الموجودة في يد اللاعب؛
     * فإذا كانت كل الأوراق الأعلى منها في القوة قد لُعبت أو بيده، فهذا يعني أنه لا يوجد أي خصم يملك ورقة أعلى منها!
     */
    fun isBossCard(card: Card, hand: List<Card>, playedCardsHistory: List<Card>): Boolean {
        val higherRanks = Rank.ACTIVE_RANKS.filter { it.power > card.rank.power }
        if (higherRanks.isEmpty()) return true // أعلى ورقة في اللعبة (الرقم 2)
        val knownHigherCards = (playedCardsHistory + hand)
            .filter { it.suit == card.suit && it.rank.power > card.rank.power }
            .map { it.rank }
            .toSet()
        return higherRanks.all { it in knownHigherCards }
    }

    /**
     * حساب عدد أوراق الترب المتبقية لدى الخصوم:
     * إجمالي أوراق الترب في اللعبة هو 10 أوراق.
     */
    fun countRemainingOpponentTrumps(
        trumpSuit: Suit,
        hand: List<Card>,
        playedCardsHistory: List<Card>
    ): Int {
        val trumpsInHand = hand.count { it.suit == trumpSuit }
        val trumpsPlayed = playedCardsHistory.count { it.suit == trumpSuit }
        return (10 - trumpsInHand - trumpsPlayed).coerceAtLeast(0)
    }

    /**
     * فحص هل الورقة هي ورقة كاسحة مطلقة في اللعبة بأكملها (Absolute Boss):
     * - إذا كانت من فئة الترب: فهي أعلى ورقة ترب متبقية، وبالتالي لا يمكن لأي ورقة في اللعبة هزيمتها!
     * - إذا كانت من فئة جانبية: فهي أعلى ورقة متبقية في فئتها، بشرط أن يكون الترب قد نفد بالكامل لدى الخصوم!
     */
    fun isAbsoluteBoss(
        card: Card,
        hand: List<Card>,
        playedCardsHistory: List<Card>,
        trumpSuit: Suit
    ): Boolean {
        if (!isBossCard(card, hand, playedCardsHistory)) return false
        if (card.suit == trumpSuit) return true
        val opponentTrumpsLeft = countRemainingOpponentTrumps(trumpSuit, hand, playedCardsHistory)
        return opponentTrumpsLeft == 0
    }

    /**
     * ذكاء اصطناعي أستاذ دولي خارق (Grandmaster AI) لمرحلة المزاد:
     * يعتمد على المحاكاة الرياضية الدقيقة وقيمة الأمل الرياضي (Expected Value):
     * 1. الأكلات المحسومة (Sure Tricks): أوراق الـ 2 (أقوى أوراق اللعبة) والآسات المحمية.
     * 2. ميزة الميدان (Field Gain): المشتري سيحصل على 5 أوراق من الميدان ويتخلص من أضعف 4 أوراق!
     *    مما يرفع قوة يده بشكل حاسم من 7 إلى 8 أوراق ممتازة مصفاة.
     * 3. طول فئة الترب والسيطرة: 4+ أوراق ترب في اليد الأولية تعني شبه يقين بامتلاك 5 إلى 7 أوراق
     *    ترب بعد أخذ الميدان، مما يضمن سحب ترب الخصوم بالكامل وإسقاط دفاعاتهم.
     * 4. الفراغات (Voids) والقطع: القدرة على تفريغ فئة أو فئتين جانبيتين بالكامل لقطع أكلات الخصوم.
     * 5. حماية الكروت السوداء والحمر التنافسية: الحذر المضاعف عند امتلاك كرت أسود، والجرأة عند امتلاك كرت أحمر.
     */
    fun calculateAiBid(
        hand: List<Card>,
        fieldCards: List<Card>,
        currentBid: Int,
        playerRedCards: Int = 0,
        playerBlackCards: Int = 0,
        highestBidderId: Int? = null,
        myPlayerId: Int? = null,
        allPlayers: List<Player> = emptyList()
    ): Int? {
        val pointsInHand = hand.sumOf { it.points }
        val bestTrump = chooseBestTrumpSuit(hand)
        val trumpCards = hand.filter { it.suit == bestTrump }
        val trumpCount = trumpCards.size

        // تصنيف الأوراق حسب القوة الحتمية
        val twos = hand.filter { it.rank == Rank.TWO }
        val twosCount = twos.size
        val hasClubsTwo = hand.any { it.suit == Suit.CLUBS && it.rank == Rank.TWO } // الجوكر الملكي 25ن
        val aces = hand.filter { it.rank == Rank.ACE }
        val acesCount = aces.size
        val tensCount = hand.count { it.rank == Rank.TEN }
        val kingsCount = hand.count { it.rank == Rank.KING }

        // فحص الفئات الخالية والأحادية (Voids & Singletons) لخلق فرص القطع بعد الميدان
        val nonTrumpCards = hand.filter { it.suit != bestTrump }
        val nonTrumpSuits = nonTrumpCards.groupBy { it.suit }
        var voidCount = 0
        var singletonCount = 0
        Suit.entries.filter { it != bestTrump }.forEach { suit ->
            val count = nonTrumpSuits[suit]?.size ?: 0
            if (count == 0) voidCount++
            else if (count == 1) singletonCount++
        }

        // 1. حساب الأكلات المحسومة المؤكدة (Sure Tricks out of 8)
        var sureTricks = 0.0
        // أوراق الـ 2 مضمونة الفوز بأكلاتها
        sureTricks += twosCount * 1.0
        // الآسات التي يوجد معها الـ 2 في نفس الفئة مضمونة 100%
        hand.filter { it.rank == Rank.ACE }.forEach { ace ->
            if (hand.any { it.suit == ace.suit && it.rank == Rank.TWO }) {
                sureTricks += 1.0 // أكلة ثانية مضمونة بنفس الفئة
            } else if (ace.suit == bestTrump && trumpCount >= 4) {
                sureTricks += 0.8
            } else {
                sureTricks += 0.6 // الآس الخارجي يفوز بنسبة عالية إذا لم يُقطع
            }
        }
        // أثر طول فئة الترب في تحقيق أكلات إضافية حتمية بعد سحب ترب الخصوم
        when {
            trumpCount >= 5 -> sureTricks += 2.5
            trumpCount == 4 -> sureTricks += 1.6
            trumpCount == 3 -> sureTricks += 0.8
        }
        // أثر الفراغات (Voids) في القطع بالترب
        sureTricks += voidCount * 0.9 + singletonCount * 0.45

        // 2. القيمة المتوقعة للنقاط (Expected Value Points):
        // متوسط نقاط الأكلة الواحدة = 187 / 8 ≈ 23.4 نقطة
        val expectedTricksWon = sureTricks.coerceIn(1.0, 8.0)
        var expectedPoints = (expectedTricksWon * 23.4)

        // تعديل بالنقاط المضمونة الممسوكة باليد
        if (hasClubsTwo) expectedPoints += 14.0 // الجوكر يضمن 25ن لنفسه
        expectedPoints += (pointsInHand * 0.25) // وزن إضافي لنقاط اليد الفعلية

        // 3. عامل الميدان (Field Gain):
        // الميدان يحتوي 5 أوراق من أصل 33 غير مكشوفة، المشتري يصفي الـ 12 ورقة ليأخذ أفضل 8
        val unseenPoints = (187 - pointsInHand).coerceAtLeast(0)
        val expectedFieldPoints = unseenPoints * (5.0 / 33.0)
        expectedPoints += (expectedFieldPoints * 0.4)

        // 4. الحسابات التكتيكية للسياق التنافسي (Tournament Context)
        if (playerBlackCards >= 1) {
            // اللاعب مهدد بالإقصاء (لديه كرت أسود)، فيلزم الحذر الشديد وعدم المخاطرة
            expectedPoints -= 12.0
        }
        if (playerRedCards == 1) {
            // اللاعب على بعد كرت أحمر واحد من الفوز بالبطولة والإعفاء!
            expectedPoints += 6.0
        }

        // تحديد السقف الأقصى الآمن والمدروس للمزايدة
        val maxWillingBid = when {
            expectedPoints >= 165 && (twosCount >= 2 || (hasClubsTwo && trumpCount >= 4)) -> 187 // كاسح Slam!
            expectedPoints >= 150 && (twosCount >= 2 || (hasClubsTwo && acesCount >= 1)) -> 175
            expectedPoints >= 138 && (twosCount >= 1 || acesCount >= 2) -> 160
            expectedPoints >= 125 && (twosCount >= 1 || acesCount >= 1) -> 145
            expectedPoints >= 115 && trumpCount >= 3 -> 130
            expectedPoints >= 102 && trumpCount >= 3 -> 115
            expectedPoints >= 90 -> 105
            expectedPoints >= 80 && currentBid < 100 -> 100
            else -> 0 // باص (تمرير)
        }

        val nextRaise = if (currentBid < 100) 100 else currentBid + 5
        return if (nextRaise <= maxWillingBid && nextRaise <= 187) {
            nextRaise
        } else {
            null // باص مدروس
        }
    }

    /**
     * اختيار الذكاء الاصطناعي الأستاذ لنوع الترب الأقوى (Grandmaster Trump Selection):
     * معايير الاختيار الدقيقة:
     * 1. طول الفئة (الطول يعطي السيطرة والقدرة على سحب تراب الخصوم).
     * 2. وجود ورقة الـ 2 (الجوكر بـ 25ن في الكراول، وباقي الـ 2 بـ 10ن).
     * 3. وجود الآس والشايب والبنت والعشرة.
     * 4. جودة الفئات الجانبية المتبقية (تفضيل الفئة التي تترك فئات خالية أو أحادية للقطع).
     */
    fun chooseBestTrumpSuit(hand: List<Card>): Suit {
        val suitScores = Suit.entries.associateWith { suit ->
            val cardsOfSuit = hand.filter { it.suit == suit }
            val count = cardsOfSuit.size
            if (count == 0) return@associateWith -100

            // طول الفئة: أسي الأساس في لعبة الترب
            var score = when (count) {
                1 -> 5
                2 -> 20
                3 -> 45
                4 -> 85
                5 -> 135
                else -> 190 + (count - 5) * 35
            }

            // قوة الأوراق الداخلية
            val hasTwo = cardsOfSuit.any { it.rank == Rank.TWO }
            val hasAce = cardsOfSuit.any { it.rank == Rank.ACE }
            val hasKing = cardsOfSuit.any { it.rank == Rank.KING }
            val hasQueen = cardsOfSuit.any { it.rank == Rank.QUEEN }
            val hasJack = cardsOfSuit.any { it.rank == Rank.JACK }
            val hasTen = cardsOfSuit.any { it.rank == Rank.TEN }

            if (hasTwo) {
                // الجوكر في الكراول يمنح أفضلية استثنائية (25 نقطة كاسحة وأعلى قوة)
                score += if (suit == Suit.CLUBS) 55 else 35
            }
            if (hasAce) score += 22
            if (hasKing) score += 12
            if (hasQueen) score += 8
            if (hasJack) score += 6
            if (hasTen) score += 15

            // فحص الفئات الأخرى في حال اختيار هذا الترب: كم فراغاً (Void) سينشأ للقطع؟
            val sideCards = hand.filter { it.suit != suit }
            val sideSuits = sideCards.groupBy { it.suit }
            Suit.entries.filter { it != suit }.forEach { s ->
                val c = sideSuits[s]?.size ?: 0
                if (c == 0) score += 20 // فراغ كامل للقطع
                else if (c == 1) score += 10 // فئة أحادية سهلة التصفية
            }

            score
        }
        return suitScores.maxByOrNull { it.value }?.key ?: Suit.CLUBS
    }

    /**
     * توزيع أوراق الميدان الأستاذي (Grandmaster Field Distribution):
     * المشتري يملك 12 ورقة (7 أصلية + 5 ميدان). يحتفظ بأفضل 8 أوراق ويوزع 4 أوراق للخصوم الـ4.
     * القواعد الصارمة للذكاء الاصطناعي الخارق:
     * 1. حظر تام ومطلق: لا يُعطى أي خصم ورقة 2 (10 أو 25ن) أبداً تحت أي ظرف!
     * 2. حظر تام: لا يُعطى أي خصم آس (11ن) أو عشرة (10ن) أو أي ورقة ترب!
     * 3. استراتيجية الفراغ الملكي (Perfect Void Engineering):
     *    يحدد الذكاء الفئات الجانبية التي تحتوي ورقة أو ورقتين من الرتب الضعيفة (6، 7، 8، 9 بـ 0ن)
     *    ويعطيها للخصوم، ليصبح لديه خلو تام (Void 100%) في تلك الفئات، مما يمكنه من قطع أي ورقة
     *    يلعبها الخصوم في تلك الفئة برتب ترب منخفضة والاستيلاء على كل أكلاتهم ونقاطهم!
     * 4. توزيع الأوراق الضعيفة بعدالة وتشتيت بين الخصوم الأربعة دون تركيز أي فئة لدى خصم واحد.
     */
    fun aiDistributeFieldCards(
        aiPlayerId: Int,
        buyerCombinedHand: List<Card>,
        otherPlayerIds: List<Int>,
        trumpSuit: Suit?
    ): Map<Int, Card> {
        val effectiveTrump = trumpSuit ?: chooseBestTrumpSuit(buyerCombinedHand)
        val remainingCards = buyerCombinedHand.toMutableList()
        val assignments = mutableMapOf<Int, Card>()

        // فحص الفئات الجانبية وأطوالها لمعرفة أسهل الفئات للتفريغ الكامل
        val nonTrumpCards = remainingCards.filter { it.suit != effectiveTrump }
        val nonTrumpCounts = nonTrumpCards.groupBy { it.suit }.mapValues { it.value.size }

        // تقييم رغبة الذكاء في الاحتفاظ بالورقة لنفسه (كلما زادت القيمة، كان التمسك بها واجباً)
        fun cardRetentionValue(c: Card): Int {
            var valScore = c.points * 8 + c.rank.power * 2
            if (c.suit == effectiveTrump) valScore += 500 // حظر التفريط في أي ورقة ترب
            if (c.rank == Rank.TWO) valScore += 400       // أوراق الـ 2 مقدسة لا تُفرط
            if (c.rank == Rank.ACE) valScore += 250       // الآسات
            if (c.rank == Rank.TEN) valScore += 180       // العشرات (10 نقاط ثمينة)
            if (c.rank == Rank.KING) valScore += 50
            if (c.rank == Rank.QUEEN) valScore += 40

            // إذا كانت الورقة 0 نقاط وخارج الترب، وكان طول فئتها قصيراً (1 أو 2)،
            // فإن التخلص منها يمنح ميزة جبارة بصنع فراغ كامل (Void) للقطع بالترب
            if (c.points == 0 && c.suit != effectiveTrump) {
                val len = nonTrumpCounts[c.suit] ?: 5
                if (len <= 2) {
                    valScore -= 120 // أولوية قصوى لرميها للخصوم لصنع Void
                } else if (len == 3) {
                    valScore -= 60
                }
            }
            return valScore
        }

        // ترتيب الأوراق تصاعدياً حسب قيمة الاحتفاظ: الأقل قيمة وأقل نقاط أولاً ليتم منحها للخصوم
        remainingCards.sortWith(
            compareBy<Card> { cardRetentionValue(it) }
                .thenBy { it.points }
                .thenBy { it.rank.power }
        )

        // توزيع أقل 4 أوراق قيمة على الخصوم الـ 4
        for (i in otherPlayerIds.indices) {
            if (i < remainingCards.size) {
                assignments[otherPlayerIds[i]] = remainingCards[i]
            }
        }

        // الورقة المتبقية من الـ 5 الموزعة تُخصص للمشتري (أفضل ورقة متبقية)
        val nonAssignedToOthers = remainingCards.filter { c -> assignments.values.none { it.id == c.id } }
        val bestForAi = nonAssignedToOthers.maxByOrNull { cardRetentionValue(it) } ?: nonAssignedToOthers.firstOrNull()

        if (bestForAi != null) {
            assignments[aiPlayerId] = bestForAi
        }

        return assignments
    }

    /**
     * محرك لعب الأوراق التكتيكي الخارق (Grandmaster Trick Engine):
     * يقود الذكاء الاصطناعي كل جولة بأعلى درجات التفكير الاستراتيجي والشطرنجي:
     * - الذاكرة الكاملة والمطلقة: تتبع كامل الأوراق الـ 40 المكشوفة وتحديد المتبقي منها في يد الخصوم.
     * - حساب أسياد الفئات (Boss Cards): معرفة الورقة التي لا يوجد أعلى منها في الميدان.
     * - استراتيجية سحب الترب (Trump Extraction): المشتري يسحب تراب الخصوم بأعلى تراب لضمان نجاح أوراق الفئات الجانبية.
     * - التنسيق الدفاعي التام (4 لاعبين كفريق واحد ضد المشتري):
     *   1. التشحيم والتلغيم الثقيل (Heavy Smear): عند فوز الزميل بالأكلة برتبة مضمونة، يرمي باقي الخصوم العشرات (10ن)
     *      والآسات (11ن) والشيبان (4ن) لزيادة رصيد الدفاع.
     *   2. التجويع الصارم للمشتري (Starvation): عند فوز المشتري بالأكلة، يرمي الخصوم فقط أوراق 0 نقاط (6، 7، 8، 9)
     *      دون إعطائه أي نقطة واحدة مجاناً!
     *   3. القطع فوق المشتري (Over-Trumping): اصطياد المشتري بقطع أكلاته بالترب وتجريده من العشرات.
     *   4. حظر قيادة الترب للمدافعين: تجنب لعب الترب كبادئ حتى لا يفرغ المشتري تراب المدافعين.
     *   5. حماية العشرات (Ten Protection): عدم رمي العشرات منفردة إلا كأسياد فئات أو في أكلات الزميل المضمونة.
     */
    fun chooseAiCardToPlay(
        hand: List<Card>,
        leadingSuit: Suit?,
        trumpSuit: Suit,
        isBuyer: Boolean,
        currentPlays: List<TrickPlay>,
        buyerId: Int? = null,
        myPlayerId: Int? = null,
        playedCardsHistory: List<Card> = emptyList(),
        players: List<Player> = emptyList(),
        currentRound: Int = 1,
        winningBid: Int = 100
    ): Card {
        val legalCards = hand.filter { isCardPlayable(it, hand, leadingSuit) }
        if (legalCards.isEmpty()) return hand.first()
        if (legalCards.size == 1) return legalCards.first()

        val opponentTrumpsLeft = countRemainingOpponentTrumps(trumpSuit, hand, playedCardsHistory)
        val trickPoints = currentPlays.sumOf { it.card.points }
        val isLastToPlay = currentPlays.size == 4 // اللاعب الأخير في الأكلة يملك الرؤية الكاملة 100%

        // =====================================================================
        // الحالة الأولى: اللاعب هو قائد الأكلة والبادئ بها (leadingSuit == null)
        // =====================================================================
        if (leadingSuit == null) {
            if (isBuyer) {
                // -------------------------------------------------------------
                // استراتيجية المشتري كبادئ (Buyer Lead Strategy):
                // -------------------------------------------------------------
                val trumpCards = legalCards.filter { it.suit == trumpSuit }

                // أ) إذا كان لدى الخصوم أوراق ترب، والمشتري يملك سيد الترب (Boss Trump):
                //    اسحب الترب فوراً لتجريد الخصوم ومنعهم من قطع أوراقك الجانبية!
                if (opponentTrumpsLeft > 0 && trumpCards.isNotEmpty()) {
                    val bossTrumps = trumpCards.filter { isBossCard(it, hand, playedCardsHistory) }
                    if (bossTrumps.isNotEmpty()) {
                        return bossTrumps.maxByOrNull { it.rank.power } ?: bossTrumps.first()
                    }
                    // إذا كان يملك ورقة 2 أو آس في الترب، يقود بها لسحب أكبر عدد من تراب الخصوم
                    val highTrumps = trumpCards.filter { it.rank == Rank.TWO || it.rank == Rank.ACE }
                    if (highTrumps.isNotEmpty()) {
                        return highTrumps.maxByOrNull { it.rank.power } ?: highTrumps.first()
                    }
                }

                // ب) إذا نفد الترب لدى الخصوم أو المشتري آمن: احصد أسياد الفئات الجانبية (Side Boss Cards)
                val sideBossCards = legalCards.filter { it.suit != trumpSuit && isBossCard(it, hand, playedCardsHistory) }
                if (sideBossCards.isNotEmpty()) {
                    // إذا نفد ترب الخصوم، فأي سيد فئة هو أكلة مؤكدة 100%، العب صاحب أعلى نقاط أولاً
                    if (opponentTrumpsLeft == 0) {
                        return sideBossCards.maxByOrNull { it.points * 10 + it.rank.power } ?: sideBossCards.first()
                    } else {
                        // إذا كان لدى الخصوم ترب، العب ورقة الـ 2 أولاً لجني الأكلة فورياً
                        val sideTwos = sideBossCards.filter { it.rank == Rank.TWO }
                        if (sideTwos.isNotEmpty()) return sideTwos.first()
                        val sideAces = sideBossCards.filter { it.rank == Rank.ACE }
                        if (sideAces.isNotEmpty()) return sideAces.first()
                    }
                }

                // ج) لعب أوراق الـ 2 الحتمية الفائزة
                val twos = legalCards.filter { it.rank == Rank.TWO }
                if (twos.isNotEmpty()) return twos.first()

                // د) لعب الآسات (A) خارج الترب
                val nonTrumpAces = legalCards.filter { it.suit != trumpSuit && it.rank == Rank.ACE }
                if (nonTrumpAces.isNotEmpty()) return nonTrumpAces.first()

                // هـ) قيادة آمنة بأوراق 0 نقاط لتفادي التضحية بالعشرات
                val safeZeroCards = legalCards.filter { it.points == 0 && it.suit != trumpSuit }
                if (safeZeroCards.isNotEmpty()) {
                    return safeZeroCards.minByOrNull { it.rank.power } ?: safeZeroCards.first()
                }

                // و) تجنب رمي العشرات كقائد للأكلة إلا إذا كانت الورقة الوحيدة
                return legalCards.filter { it.rank != Rank.TEN && it.rank != Rank.TWO }
                    .minByOrNull { it.points * 10 + it.rank.power }
                    ?: legalCards.minByOrNull { it.points * 10 + it.rank.power }
                    ?: legalCards.first()

            } else {
                // -------------------------------------------------------------
                // استراتيجية المدافع كبادئ (Defender Lead Strategy):
                // -------------------------------------------------------------
                // أ) حصد الأوراق الكاسحة المضمونة (Boss Cards) فورياً قبل أن يحصل المشتري على فرصة القطع بالترب
                val safeBossCards = legalCards.filter { isBossCard(it, hand, playedCardsHistory) && it.suit != trumpSuit }
                if (safeBossCards.isNotEmpty()) {
                    val bossTwo = safeBossCards.find { it.rank == Rank.TWO }
                    if (bossTwo != null) return bossTwo
                    val bossAce = safeBossCards.find { it.rank == Rank.ACE }
                    if (bossAce != null) return bossAce
                }

                // ب) لعب أوراق الـ 2 في الفئات الجانبية (تسجيل 10ن أو 25ن فورياً لصالح الدفاع)
                val sideTwos = legalCards.filter { it.suit != trumpSuit && it.rank == Rank.TWO }
                if (sideTwos.isNotEmpty()) return sideTwos.first()

                // ج) قيادة آمنة بأوراق 0 نقاط في الفئات التي قد يملك فيها الزملاء أوراقاً عليا
                val nonTrumpSafeZeros = legalCards.filter { it.suit != trumpSuit && it.points == 0 }
                if (nonTrumpSafeZeros.isNotEmpty()) {
                    return nonTrumpSafeZeros.minByOrNull { it.rank.power } ?: nonTrumpSafeZeros.first()
                }

                // د) حظر قيادة الترب للمدافع! قيادة الترب تخدم المشتري، تجنبها إلا إذا كان كل ما بيدك ترب
                val nonTrumpCards = legalCards.filter { it.suit != trumpSuit && it.rank != Rank.TEN }
                if (nonTrumpCards.isNotEmpty()) {
                    return nonTrumpCards.minByOrNull { it.points * 10 + it.rank.power } ?: nonTrumpCards.first()
                }

                return legalCards.filter { it.rank != Rank.TEN }
                    .minByOrNull { it.points * 10 + it.rank.power }
                    ?: legalCards.first()
            }
        }

        // =====================================================================
        // الحالة الثانية: هناك فئة بداية محددة (leadingSuit != null)
        // =====================================================================
        val hasLeadingSuit = hand.any { it.suit == leadingSuit }
        val currentWinningPlay = determineTrickWinner(currentPlays, leadingSuit, trumpSuit)
        val isWinningPlayByBuyer = (buyerId != null && currentWinningPlay.playerId == buyerId) ||
                (!isBuyer && buyerId == null && currentWinningPlay.playerId == 0)
        val isWinningPlayByPartner = (!isBuyer && !isWinningPlayByBuyer)

        // فحص هل فوز الزميل مضمون 100% (أو أن اللاعب الحالي هو الأخير في الأكلة):
        val isPartnerWinGuaranteed = isWinningPlayByPartner && (
            isLastToPlay ||
            currentWinningPlay.card.rank == Rank.TWO ||
            isBossCard(currentWinningPlay.card, hand, playedCardsHistory) ||
            (currentWinningPlay.card.suit == trumpSuit && opponentTrumpsLeft == 0) ||
            (currentWinningPlay.card.rank == Rank.ACE && currentPlays.size >= 3 && !isWinningPlayByBuyer)
        )

        // ---------------------------------------------------------------------
        // مسار 1: اللاعب يملك أوراقاً من فئة البداية (ملتزم قانونياً)
        // ---------------------------------------------------------------------
        if (hasLeadingSuit) {
            val canBeatCurrent = legalCards.filter { card ->
                if (currentWinningPlay.card.suit == trumpSuit && leadingSuit != trumpSuit) {
                    false // لا يمكن لورقة عادية التغلب على الترب
                } else {
                    card.rank.power > currentWinningPlay.card.rank.power
                }
            }

            if (!isBuyer && isWinningPlayByPartner) {
                // -------------------------------------------------------------
                // الزميل في الدفاع هو الفائز حالياً في الأكلة!
                // -------------------------------------------------------------
                if (isPartnerWinGuaranteed) {
                    // تشحيم ثقيل لصالح الزميل: رمي أعلى نقاط ممكنة لتعزيز رصيد الدفاع!
                    // أولوية التشحيم: العشرة (10ن) أو الآس (11ن) أو الشايب/البنت/الغلام (4ن)
                    val tenCard = legalCards.find { it.rank == Rank.TEN }
                    if (tenCard != null) return tenCard
                    val aceCard = legalCards.find { it.rank == Rank.ACE }
                    if (aceCard != null) return aceCard
                    val honorCard = legalCards.filter { it.points > 0 }.maxByOrNull { it.points }
                    if (honorCard != null) return honorCard
                } else {
                    // إذا كان فوز الزميل غير مضمون (المشتري سيلعب بعدنا وقد يكسر الأكلة):
                    // إذا كنا نستطيع الفوز بأمان بأقل ورقة تفوز، نتصدر نحن الأكلة
                    if (canBeatCurrent.isNotEmpty()) {
                        val minWinning = canBeatCurrent.minByOrNull { it.rank.power }
                        if (minWinning != null && minWinning.rank != Rank.TWO) {
                            return minWinning
                        }
                    }
                }
                // وإلا اللعب بأمان بأقل ورقة لتوفير القوة
                return legalCards.minByOrNull { it.rank.power } ?: legalCards.first()
            }

            if (canBeatCurrent.isNotEmpty()) {
                // الفوز بأقل ورقة فائزة ممكنة لحفظ الأوراق الأعلى للأكلات القادمة
                return canBeatCurrent.minByOrNull { it.rank.power } ?: canBeatCurrent.first()
            } else {
                // لا نستطيع الفوز بالأكلة -> تجويع الفائز (خاصة إذا كان المشتري)
                val zeroPointCards = legalCards.filter { it.points == 0 }
                return if (zeroPointCards.isNotEmpty()) {
                    zeroPointCards.minByOrNull { it.rank.power } ?: zeroPointCards.first()
                } else {
                    // إذا كنا مجبرين على التضحية بنقاط، نضحي بأقل ورقة نقاط ممكنة
                    legalCards.minByOrNull { it.points * 10 + it.rank.power } ?: legalCards.first()
                }
            }
        } else {
            // -----------------------------------------------------------------
            // مسار 2: اللاعب خالٍ من فئة البداية (خيارات القطع بالترب أو الكش والتخلص)
            // -----------------------------------------------------------------
            val trumpCards = legalCards.filter { it.suit == trumpSuit }

            if (!isBuyer && isWinningPlayByPartner) {
                // -------------------------------------------------------------
                // الزميل فائز بالفعل بالأكلة: لا تقطع بالترب أبداً!
                // -------------------------------------------------------------
                if (isPartnerWinGuaranteed) {
                    // تشحيم جانبي فاخر: ارمِ عشرة أو آس أو شايب من فئة أخرى إلى أكلة الزميل!
                    val nonTrumpPoints = legalCards.filter { it.suit != trumpSuit && it.points > 0 }
                    if (nonTrumpPoints.isNotEmpty()) {
                        val tenOrAce = nonTrumpPoints.find { it.rank == Rank.TEN }
                            ?: nonTrumpPoints.find { it.rank == Rank.ACE }
                            ?: nonTrumpPoints.maxByOrNull { it.points }
                        if (tenOrAce != null) return tenOrAce
                    }
                }
                // وإلا التخلص من ورقة 0 نقاط من فئة قصيرة لخلق Void إضافي
                val zeroCards = legalCards.filter { it.suit != trumpSuit && it.points == 0 }
                if (zeroCards.isNotEmpty()) {
                    val suitCounts = hand.groupBy { it.suit }.mapValues { it.value.size }
                    return zeroCards.minByOrNull { suitCounts[it.suit] ?: 99 } ?: zeroCards.first()
                }
                return legalCards.filter { it.suit != trumpSuit }
                    .minByOrNull { it.points * 10 + it.rank.power }
                    ?: legalCards.first()
            }

            // إذا كان المشتري هو الفائز حالياً بالأكلة (أو كانت الأكلة محملة بنقاط ثمينة):
            if (trumpCards.isNotEmpty()) {
                val currentWinnerIsTrump = currentWinningPlay.card.suit == trumpSuit
                val winningTrumps = if (currentWinnerIsTrump) {
                    trumpCards.filter { it.rank.power > currentWinningPlay.card.rank.power }
                } else {
                    trumpCards
                }

                // القطع واجب إذا كان المشتري هو الفائز أو الأكلة فيها نقاط تستحق القطع
                val isWorthCutting = isBuyer || isWinningPlayByBuyer || trickPoints >= 4
                if (winningTrumps.isNotEmpty() && isWorthCutting) {
                    // القطع بأقل ورقة ترب فائزة ممكنة (لحفظ كبار التراب)
                    return winningTrumps.minByOrNull { it.rank.power } ?: winningTrumps.first()
                }
            }

            // لا نستطيع القطع أو الأكلة لا تستحق إهدار الترب -> تخلص (كش) من أوراق 0 نقاط
            val zeroPointCards = legalCards.filter { it.suit != trumpSuit && it.points == 0 }
            if (zeroPointCards.isNotEmpty()) {
                // تفضيل التخلص من فئة قصيرة لصنع فراغ (Void) كامل للجولات القادمة
                val suitCounts = hand.groupBy { it.suit }.mapValues { it.value.size }
                return zeroPointCards.minByOrNull { suitCounts[it.suit] ?: 99 } ?: zeroPointCards.first()
            }

            // التخلص من أقل بطاقة نقاط وقوة خارج الترب
            return legalCards.filter { it.suit != trumpSuit }
                .minByOrNull { it.points * 10 + it.rank.power }
                ?: legalCards.minByOrNull { it.points * 10 + it.rank.power }
                ?: legalCards.first()
        }
    }
}

