package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.HapticManager
import com.example.audio.SoundManager
import com.example.profile.AchievementManager
import com.example.reaction.ReactionManager
import com.example.settings.GameSettingsManager
import com.example.settings.GameSpeed
import com.example.bluetooth.BluetoothGameManager
import com.example.bluetooth.BluetoothPacket
import com.example.bluetooth.LobbyPlayer
import com.example.data.AppDatabase
import com.example.data.GameRecord
import com.example.data.GameRepository
import com.example.logic.TirbGameLogic
import com.example.localization.LocalizationManager
import com.example.model.Card
import com.example.model.GameLogEntry
import com.example.model.GamePhase
import com.example.model.GameUIState
import com.example.model.Player
import com.example.model.Rank
import com.example.model.Suit
import com.example.model.TrickPlay
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class TirbViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: GameRepository
    val historyList: StateFlow<List<GameRecord>>

    val soundManager = SoundManager.getInstance(application)
    val isSoundEnabled: StateFlow<Boolean> = soundManager.isSoundEnabled
    val settingsManager = GameSettingsManager.getInstance(application)
    val hapticManager = HapticManager.getInstance(application)

    fun getAiDelay(baseMs: Long): Long {
        return when (settingsManager.gameSpeed.value) {
            GameSpeed.NORMAL -> baseMs
            GameSpeed.FAST -> (baseMs * 0.55).toLong().coerceAtLeast(180L)
            GameSpeed.TURBO -> (baseMs * 0.25).toLong().coerceAtLeast(100L)
        }
    }

    fun toggleSound(): Boolean {
        return soundManager.toggleSound()
    }

    fun setSoundEnabled(enabled: Boolean) {
        soundManager.setSoundEnabled(enabled)
    }

    private val _uiState = MutableStateFlow(GameUIState())
    val uiState: StateFlow<GameUIState> = _uiState.asStateFlow()

    private var bluetoothManager: BluetoothGameManager? = null

    fun setBluetoothManager(manager: BluetoothGameManager) {
        this.bluetoothManager = manager
        manager.onPacketReceived = { packet ->
            handleIncomingBluetoothPacket(packet)
        }
        manager.onGameStartedWithDeck = { dealerId, deck ->
            startMultiplayerGame(
                lobbyPlayers = manager.lobbyPlayers.value,
                mySeatId = manager.mySeatId.value,
                roomName = manager.deviceName,
                syncedDeck = deck
            )
        }
    }

    init {
        val db = AppDatabase.getDatabase(application)
        repository = GameRepository(db.gameHistoryDao())
        historyList = repository.allRecords.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )
        // Observe language changes and dynamically re-format all log entries
        viewModelScope.launch {
            LocalizationManager.strings.collect { strings ->
                _uiState.update { current ->
                    if (current.logEntries.isEmpty()) current
                    else current.copy(
                        gameLog = current.logEntries.map { it.format(strings, current.players) }
                    )
                }
            }
        }
        startNewTournament()
    }

    /**
     * بدء بطولة / مباراة جديدة كلياً وتصفير الكروت الحمر والسود
     */
    fun startNewTournament() {
        startRound(dealerId = 0, preserveCards = false)
    }

    /**
     * الانتقال إلى الجولة التالية مع الحفاظ على الكروت الحمر والسود وتدوير الموزع
     */
    fun startNextRound() {
        val currentDealer = _uiState.value.dealerPlayerId
        val nextDealer = (currentDealer + 1) % 5
        startRound(dealerId = nextDealer, preserveCards = true)
    }

    /**
     * دالة بدء جولة جديدة (تُستخدم من زر اللعب مجدداً)
     */
    fun startNewGame() {
        if (_uiState.value.isMatchOver) {
            startNewTournament()
        } else {
            startNextRound()
        }
    }

    /**
     * بدء جولة وتوزيع الأوراق (35 للاعبين + 5 في الميدان + 14 احتياط)
     */
    private fun startRound(
        dealerId: Int,
        preserveCards: Boolean,
        customPlayers: List<Player>? = null,
        customDeck: List<Card>? = null
    ) {
        viewModelScope.launch {
            val fullDeck = customDeck ?: TirbGameLogic.createDeck().shuffled()
            val basePlayers = when {
                customPlayers != null -> customPlayers
                preserveCards && _uiState.value.players.isNotEmpty() -> _uiState.value.players
                else -> TirbGameLogic.createInitialPlayers(com.example.profile.UserProfileManager.profile.value.username)
            }

            val players = basePlayers.toMutableList()

            // توزيع 7 أوراق لكل لاعب (35 ورقة)
            var cardIndex = 0
            for (p in players.indices) {
                val hand = fullDeck.subList(cardIndex, cardIndex + 7)
                val isExempt = players[p].isExemptFromAuction
                players[p] = players[p].copy(
                    hand = TirbGameLogic.sortHand(hand),
                    pointsWon = 0,
                    tricksWon = 0,
                    hasPassedAuction = isExempt, // اللاعب الفائز بكرتين حمر يخرج من طور الشراء
                    currentBid = 0
                )
                cardIndex += 7
            }

            // 5 أوراق مكشوفة في الميدان
            val field = fullDeck.subList(cardIndex, cardIndex + 5)
            cardIndex += 5

            // من يبدأ اللعبة والمزاد هو أول شخص بعد الموزع
            var starterId = (dealerId + 1) % 5
            // إذا كان خارج طور الشراء، ننتقل لأول لاعب نشط في المزاد
            val anyActive = players.any { !it.isExemptFromAuction }
            if (anyActive) {
                while (players.find { it.id == starterId }?.isExemptFromAuction == true) {
                    starterId = (starterId + 1) % 5
                }
            }

            val dealerName = players.find { it.id == dealerId }?.name ?: "الموزع"
            val starterName = players.find { it.id == starterId }?.name ?: "البادئ"
            val roundNum = if (preserveCards) _uiState.value.matchRoundNumber + 1 else 1

            val exemptNotice = players.filter { it.isExemptFromAuction }.map { it.name }
            val exemptText = if (exemptNotice.isNotEmpty()) {
                " (خارج طور الشراء لفوزهم بكرتين حمر: ${exemptNotice.joinToString()})"
            } else ""

            val roundStrings = LocalizationManager.strings.value
            val initialEntries = listOf(
                GameLogEntry.RoundDeal(roundNum, dealerId, starterId),
                GameLogEntry.DealInitialInstructions
            )

            _uiState.value = GameUIState(
                phase = GamePhase.INITIAL_DEAL,
                players = players,
                dealerPlayerId = dealerId,
                matchRoundNumber = roundNum,
                isMatchOver = false,
                matchLoserPlayerId = null,
                roundRedCardAwardedPlayerId = null,
                roundBlackCardAwardedPlayerId = null,
                fieldCards = field,
                unassignedFieldCards = field,
                fieldAssignments = emptyMap(),
                currentTurnPlayerId = starterId,
                starterPlayerId = starterId,
                auctionStarterPlayerId = starterId,
                buyerId = null,
                winningBid = 100,
                currentAuctionBid = 100,
                highestBidderId = null,
                trumpSuit = null,
                currentRound = 1,
                currentTrickCards = emptyList(),
                leadingSuit = null,
                isMultiplayerMode = _uiState.value.isMultiplayerMode,
                localPlayerSeatId = _uiState.value.localPlayerSeatId,
                multiplayerRoomName = _uiState.value.multiplayerRoomName,
                logEntries = initialEntries,
                gameLog = initialEntries.map { it.format(roundStrings, players) }
            )
            soundManager.playCardDeal()
        }
    }

    /**
     * بدء مرحلة المزاد بعد أن يفحص اللاعب أوراقه
     */
    fun startAuction() {
        val state = _uiState.value
        if (state.phase != GamePhase.INITIAL_DEAL) return
        val entry = GameLogEntry.AuctionStarted(state.currentTurnPlayerId)
        val formatted = entry.format(LocalizationManager.strings.value, state.players)
        _uiState.value = state.copy(
            phase = GamePhase.AUCTION,
            logEntries = state.logEntries + entry,
            gameLog = state.gameLog + formatted
        )
        if (state.isMultiplayerMode) {
            broadcastAction(BluetoothPacket.PacketType.ACTION_START_AUCTION, "")
        }
        checkAuctionTurn()
    }

    /**
     * مزايدة اللاعب المحلي
     */
    fun humanBid(amount: Int) {
        val state = _uiState.value
        val localSeat = state.localPlayerSeatId
        if (state.phase != GamePhase.AUCTION || state.currentTurnPlayerId != localSeat) return
        hapticManager.tapMedium()
        processBid(localSeat, amount)
        if (state.isMultiplayerMode) {
            broadcastAction(BluetoothPacket.PacketType.ACTION_BID, "$localSeat:$amount")
        }
    }

    /**
     * باص اللاعب المحلي
     */
    fun humanPass() {
        val state = _uiState.value
        val localSeat = state.localPlayerSeatId
        if (state.phase != GamePhase.AUCTION || state.currentTurnPlayerId != localSeat) return
        hapticManager.tapLight()
        processPass(localSeat)
        if (state.isMultiplayerMode) {
            broadcastAction(BluetoothPacket.PacketType.ACTION_PASS, "$localSeat")
        }
    }

    fun processBid(playerId: Int, amount: Int) {
        val state = _uiState.value
        if (state.phase != GamePhase.AUCTION || state.currentTurnPlayerId != playerId) return

        val bidder = state.players.find { it.id == playerId } ?: return
        val bid = amount.coerceIn(state.currentAuctionBid + 1, 187)
        soundManager.playAuctionBid()

        // تفاعل الروبوتات عند المزايدات القوية
        if (bid >= 135) {
            val otherBot = state.players.filter { !it.isHuman && it.id != playerId }.randomOrNull()
            if (otherBot != null && (1..2).random() == 1) {
                ReactionManager.triggerReaction(otherBot.id, listOf("😱", "🔥", "💣").random())
            }
        }
        val updatedPlayers = state.players.map {
            if (it.id == playerId) it.copy(currentBid = bid) else it
        }

        val bidEntry = if (bid >= 187) GameLogEntry.BidMaxReached(playerId) else GameLogEntry.BidRaised(playerId, bid)
        val formattedBid = bidEntry.format(LocalizationManager.strings.value, state.players)

        if (bid >= 187) {
            // وصول السقف (187) -> فوز مباشر بالمزاد
            _uiState.update {
                it.copy(
                    isAiThinking = false,
                    players = updatedPlayers,
                    currentAuctionBid = 187,
                    winningBid = 187,
                    highestBidderId = playerId,
                    buyerId = playerId,
                    logEntries = it.logEntries + bidEntry,
                    gameLog = it.gameLog + formattedBid
                )
            }
            proceedToFieldDistribution()
            return
        }

        _uiState.update {
            it.copy(
                isAiThinking = false,
                players = updatedPlayers,
                currentAuctionBid = bid,
                highestBidderId = playerId,
                logEntries = it.logEntries + bidEntry,
                gameLog = it.gameLog + formattedBid
            )
        }

        advanceAuctionTurn()
    }

    fun processPass(playerId: Int) {
        val state = _uiState.value
        if (state.phase != GamePhase.AUCTION || state.currentTurnPlayerId != playerId) return

        val passer = state.players.find { it.id == playerId } ?: return
        val updatedPlayers = state.players.map {
            if (it.id == playerId) it.copy(hasPassedAuction = true) else it
        }

        val passEntry = GameLogEntry.PlayerPassed(playerId)
        val formattedPass = passEntry.format(LocalizationManager.strings.value, state.players)

        _uiState.update {
            it.copy(
                isAiThinking = false,
                players = updatedPlayers,
                logEntries = it.logEntries + passEntry,
                gameLog = it.gameLog + formattedPass
            )
        }

        advanceAuctionTurn()
    }

    private fun advanceAuctionTurn() {
        val state = _uiState.value
        val activePlayers = state.players.filter { !it.hasPassedAuction }

        // إذا بقي لاعب واحد فقط لم يقل باص، ومعه أعلى مزايدة
        if (activePlayers.size == 1 && state.highestBidderId != null) {
            val winner = activePlayers.first()
            val wonEntry = GameLogEntry.AuctionWon(winner.id, state.currentAuctionBid)
            val formattedWon = wonEntry.format(LocalizationManager.strings.value, state.players)
            _uiState.update {
                it.copy(
                    buyerId = winner.id,
                    winningBid = state.currentAuctionBid,
                    logEntries = it.logEntries + wonEntry,
                    gameLog = it.gameLog + formattedWon
                )
            }
            proceedToFieldDistribution()
            return
        }

        // إذا قال الجميع باص في البداية
        if (activePlayers.isEmpty()) {
            val eligible = state.players.filter { !it.isExemptFromAuction }
            val winner = eligible.firstOrNull() ?: state.players.first()
            val wonEntry = GameLogEntry.AuctionWon(winner.id, 100)
            val formattedWon = wonEntry.format(LocalizationManager.strings.value, state.players)
            _uiState.update {
                it.copy(
                    buyerId = winner.id,
                    winningBid = 100,
                    logEntries = it.logEntries + wonEntry,
                    gameLog = it.gameLog + formattedWon
                )
            }
            proceedToFieldDistribution()
            return
        }

        // الانتقال للاعب التالي النشط
        var nextId = (state.currentTurnPlayerId + 1) % 5
        while (state.players.find { it.id == nextId }?.hasPassedAuction == true) {
            nextId = (nextId + 1) % 5
        }

        _uiState.update { it.copy(currentTurnPlayerId = nextId) }
        checkAuctionTurn()
    }

    private fun checkAuctionTurn() {
        val state = _uiState.value
        if (state.phase != GamePhase.AUCTION) return

        val currentP = state.players.find { it.id == state.currentTurnPlayerId } ?: return
        if (!currentP.isHuman && !currentP.isRemoteFriend && !currentP.hasPassedAuction) {
            // دور الذكاء الاصطناعي للمزايدة
            viewModelScope.launch {
                _uiState.update { it.copy(isAiThinking = true) }
                delay(getAiDelay(700))

                val aiBid = TirbGameLogic.calculateAiBid(
                    hand = currentP.hand,
                    fieldCards = state.fieldCards,
                    currentBid = state.currentAuctionBid,
                    playerRedCards = currentP.redCards,
                    playerBlackCards = currentP.blackCards,
                    highestBidderId = state.highestBidderId,
                    myPlayerId = currentP.id,
                    allPlayers = state.players
                )

                if (aiBid != null && aiBid > state.currentAuctionBid) {
                    val cappedBid = aiBid.coerceAtMost(187)
                    val updatedPlayers = _uiState.value.players.map {
                        if (it.id == currentP.id) it.copy(currentBid = cappedBid) else it
                    }

                    if (cappedBid >= 187) {
                        val maxEntry = GameLogEntry.BidMaxReached(currentP.id)
                        val formattedMax = maxEntry.format(LocalizationManager.strings.value, updatedPlayers)
                        _uiState.update {
                            it.copy(
                                isAiThinking = false,
                                players = updatedPlayers,
                                currentAuctionBid = 187,
                                winningBid = 187,
                                highestBidderId = currentP.id,
                                buyerId = currentP.id,
                                logEntries = it.logEntries + maxEntry,
                                gameLog = it.gameLog + formattedMax
                            )
                        }
                        proceedToFieldDistribution()
                    } else {
                        val raiseEntry = GameLogEntry.BidRaised(currentP.id, cappedBid)
                        val formattedRaise = raiseEntry.format(LocalizationManager.strings.value, updatedPlayers)
                        _uiState.update {
                            it.copy(
                                isAiThinking = false,
                                players = updatedPlayers,
                                currentAuctionBid = cappedBid,
                                highestBidderId = currentP.id,
                                logEntries = it.logEntries + raiseEntry,
                                gameLog = it.gameLog + formattedRaise
                            )
                        }
                        advanceAuctionTurn()
                    }
                } else {
                    // الذكاء قال باص
                    val updatedPlayers = _uiState.value.players.map {
                        if (it.id == currentP.id) it.copy(hasPassedAuction = true) else it
                    }
                    val passEntry = GameLogEntry.PlayerPassed(currentP.id)
                    val formattedPass = passEntry.format(LocalizationManager.strings.value, updatedPlayers)
                    _uiState.update {
                        it.copy(
                            isAiThinking = false,
                            players = updatedPlayers,
                            logEntries = it.logEntries + passEntry,
                            gameLog = it.gameLog + formattedPass
                        )
                    }
                    advanceAuctionTurn()
                }
            }
        }
    }

    /**
     * الانتقال لمرحلة أخذ الميدان والتوزيع الفوري
     * يأخذ المشتري الـ 5 ورق من الميدان لتنضم إلى أوراقه الـ 7 (مجموع 12 ورقة).
     * ويختار بحرية توزيع أي 5 أوراق من بين الـ 12 ورقة (ورقة لكل لاعب بما فيهم نفسه)،
     * أو يوزع 4 أوراق للخصوم ويحتفظ بـ 8 أوراق لنفسه.
     */
    private fun proceedToFieldDistribution() {
        val buyerId = _uiState.value.buyerId ?: 0
        val buyer = _uiState.value.players.find { it.id == buyerId }
        val buyerCombined = TirbGameLogic.sortHand((buyer?.hand ?: emptyList()) + _uiState.value.fieldCards)

        val entry = GameLogEntry.FieldDistributed(buyerId)
        val formatted = entry.format(LocalizationManager.strings.value, _uiState.value.players)

        _uiState.update {
            it.copy(
                phase = GamePhase.FIELD_DISTRIBUTION,
                unassignedFieldCards = buyerCombined,
                fieldAssignments = emptyMap(),
                selectedCardForDistribution = null,
                logEntries = it.logEntries + entry,
                gameLog = it.gameLog + formatted
            )
        }

        if (buyer?.isHuman == false && buyer.isRemoteFriend == false) {
            // توزيع الذكاء الاصطناعي التلقائي
            viewModelScope.launch {
                _uiState.update { it.copy(isAiThinking = true) }
                delay(getAiDelay(1100))

                val otherIds = _uiState.value.players.map { it.id }.filter { it != buyerId }
                val intendedTrump = TirbGameLogic.chooseBestTrumpSuit(buyerCombined)
                val assignments = TirbGameLogic.aiDistributeFieldCards(
                    aiPlayerId = buyerId,
                    buyerCombinedHand = buyerCombined,
                    otherPlayerIds = otherIds,
                    trumpSuit = intendedTrump
                )

                applyFieldDistribution(assignments)
            }
        }
    }

    /**
     * اختيار ورقة للتوزيع من قبل اللاعب البشري (من بين أوراقه الـ 12)
     */
    fun selectCardForDistribution(card: Card) {
        hapticManager.tapLight()
        _uiState.update {
            if (it.selectedCardForDistribution?.id == card.id) {
                it.copy(selectedCardForDistribution = null)
            } else {
                it.copy(selectedCardForDistribution = card)
            }
        }
    }

    /**
     * تخصيص ورقة للاعب معين في مرحلة التوزيع
     */
    fun assignSelectedCardToPlayer(targetPlayerId: Int) {
        val state = _uiState.value
        val card = state.selectedCardForDistribution ?: return
        val buyerId = state.buyerId ?: 0
        val buyer = state.players.find { it.id == buyerId }
        val buyerAllCards = TirbGameLogic.sortHand((buyer?.hand ?: emptyList()) + state.fieldCards)

        // لا يمكن تخصيص أكثر من ورقة لنفس اللاعب
        val newAssignments = state.fieldAssignments.toMutableMap()

        // إذا كانت الورقة مخصصة مسبقاً للاعب آخر، يتم فك تخصيصها
        val previousOwner = newAssignments.entries.find { it.value.id == card.id }?.key
        if (previousOwner != null) {
            newAssignments.remove(previousOwner)
        }

        // وضع الورقة للاعب المحدد
        newAssignments[targetPlayerId] = card

        val unassigned = buyerAllCards.filter { c -> newAssignments.values.none { it.id == c.id } }

        _uiState.update {
            it.copy(
                fieldAssignments = newAssignments,
                unassignedFieldCards = unassigned,
                selectedCardForDistribution = null
            )
        }
    }

    /**
     * إلغاء تخصيص ورقة لاعب
     */
    fun unassignPlayerCard(targetPlayerId: Int) {
        val state = _uiState.value
        val buyerId = state.buyerId ?: 0
        val buyer = state.players.find { it.id == buyerId }
        val buyerAllCards = TirbGameLogic.sortHand((buyer?.hand ?: emptyList()) + state.fieldCards)

        val newAssignments = state.fieldAssignments.toMutableMap()
        val card = newAssignments.remove(targetPlayerId) ?: return
        val unassigned = buyerAllCards.filter { c -> newAssignments.values.none { it.id == c.id } }

        _uiState.update {
            it.copy(
                fieldAssignments = newAssignments,
                unassignedFieldCards = unassigned
            )
        }
    }

    /**
     * تأكيد التوزيع الفوري من قبل اللاعب البشري
     */
    fun confirmHumanDistribution() {
        val state = _uiState.value
        if (state.fieldAssignments.size != 5) return
        applyFieldDistribution(state.fieldAssignments)
        if (state.isMultiplayerMode) {
            val buyerId = state.buyerId ?: 0
            val assignmentPayload = state.fieldAssignments.entries.joinToString(",") { "${it.key}:${it.value.id}" }
            broadcastAction(BluetoothPacket.PacketType.ACTION_DISTRIBUTE_FIELD, "$buyerId|$assignmentPayload")
        }
    }

    private fun applyFieldDistribution(assignments: Map<Int, Card>) {
        val state = _uiState.value
        val buyerId = state.buyerId ?: 0
        val buyer = state.players.find { it.id == buyerId }
        val buyerAllCards = (buyer?.hand ?: emptyList()) + state.fieldCards

        val updatedPlayers = state.players.map { player ->
            if (player.id == buyerId) {
                // الأوراق الـ 4 الموزعة للخصوم يتم استبعادها من يد المشتري ليتبقى معه بالضبط 8 أوراق
                val givenToOthers = assignments.filter { it.key != buyerId }.values.map { it.id }
                val remainingBuyerCards = buyerAllCards.filter { it.id !in givenToOthers }
                player.copy(hand = TirbGameLogic.sortHand(remainingBuyerCards, state.trumpSuit))
            } else {
                // كل خصم ينال الورقة المخصصة له من المشتري فيصبح معه 8 أوراق
                val extraCard = assignments[player.id]
                val newHand = if (extraCard != null) {
                    TirbGameLogic.sortHand(player.hand + extraCard, state.trumpSuit)
                } else {
                    player.hand
                }
                player.copy(hand = newHand)
            }
        }

        val distEntry = GameLogEntry.FieldDistributed(buyerId)
        val formattedDist = distEntry.format(LocalizationManager.strings.value, updatedPlayers)

        _uiState.update {
            it.copy(
                isAiThinking = false,
                players = updatedPlayers,
                phase = GamePhase.DECLARE_TRUMP,
                logEntries = it.logEntries + distEntry,
                gameLog = it.gameLog + formattedDist,
                selectedCardForDistribution = null
            )
        }

        // إذا كان المشتري ذكاء اصطناعي، يختار نوع الترب فوراً
        val updatedBuyer = updatedPlayers.find { it.id == state.buyerId }
        if (updatedBuyer?.isHuman == false && updatedBuyer.isRemoteFriend == false) {
            viewModelScope.launch {
                _uiState.update { it.copy(isAiThinking = true) }
                delay(getAiDelay(900))
                val chosenSuit = TirbGameLogic.chooseBestTrumpSuit(updatedBuyer.hand)
                declareTrump(chosenSuit)
            }
        }
    }

    /**
     * التصريح بنوع الترب من قبل المشتري
     */
    fun declareTrump(suit: Suit) {
        hapticManager.tapMedium()
        val state = _uiState.value
        val buyer = state.buyer ?: state.players.first()

        // إعادة ترتيب أيادي اللاعبين لإبراز الترب
        val updatedPlayers = state.players.map {
            it.copy(hand = TirbGameLogic.sortHand(it.hand, suit))
        }

        val trickStarterId = state.auctionStarterPlayerId
        val trumpEntry = GameLogEntry.TrumpDeclared(buyer.id, suit)
        val formattedTrump = trumpEntry.format(LocalizationManager.strings.value, updatedPlayers)

        _uiState.update {
            it.copy(
                isAiThinking = false,
                trumpSuit = suit,
                players = updatedPlayers,
                phase = GamePhase.TRICK_PLAYING,
                currentRound = 1,
                currentTurnPlayerId = trickStarterId, // من بدأ المزاد هو من يفتتح جولة اللعب الأولى
                starterPlayerId = trickStarterId,
                logEntries = it.logEntries + trumpEntry,
                gameLog = it.gameLog + formattedTrump
            )
        }

        if (state.isMultiplayerMode) {
            broadcastAction(BluetoothPacket.PacketType.ACTION_DECLARE_TRUMP, "${buyer.id}:${suit.name}")
        }

        checkTrickTurn()
    }

    /**
     * لعب ورقة من قبل اللاعب المحلي
     */
    fun playHumanCard(card: Card) {
        val state = _uiState.value
        if (state.phase != GamePhase.TRICK_PLAYING) return
        val localSeat = state.localPlayerSeatId
        if (state.currentTurnPlayerId != localSeat) return

        val human = state.players.find { it.id == localSeat } ?: return

        // فحص الإلزام
        if (!TirbGameLogic.isCardPlayable(card, human.hand, state.leadingSuit)) {
            return
        }

        executeCardPlay(human, card)

        if (state.isMultiplayerMode) {
            broadcastAction(BluetoothPacket.PacketType.ACTION_PLAY_CARD, "${human.id}:${card.id}")
        }
    }

    private fun executeCardPlay(player: Player, card: Card) {
        val state = _uiState.value
        val isFirstCard = state.currentTrickCards.isEmpty()
        val newLeadingSuit = if (isFirstCard) card.suit else state.leadingSuit

        val newHand = player.hand.filter { it.id != card.id }
        val updatedPlayers = state.players.map {
            if (it.id == player.id) it.copy(hand = newHand) else it
        }

        val play = TrickPlay(playerId = player.id, playerName = player.name, card = card)
        val newPlays = state.currentTrickCards + play

        soundManager.playCardPlay()
        if (player.id == state.localPlayerSeatId) {
            hapticManager.tapLight()
        }

        val playEntry = GameLogEntry.CardPlayed(player.id, card)
        val formattedPlay = playEntry.format(LocalizationManager.strings.value, updatedPlayers)

        _uiState.update {
            it.copy(
                players = updatedPlayers,
                currentTrickCards = newPlays,
                leadingSuit = newLeadingSuit,
                logEntries = it.logEntries + playEntry,
                gameLog = it.gameLog + formattedPlay
            )
        }

        if (newPlays.size == 5) {
            // اكتملت الجولة الحالية (5 لاعبين لعبوا)
            resolveCurrentTrick(newPlays)
        } else {
            // انتقال الدور للاعب التالي باتجاه عقارب الساعة
            val nextPlayerId = (state.currentTurnPlayerId + 1) % 5
            _uiState.update { it.copy(currentTurnPlayerId = nextPlayerId) }
            checkTrickTurn()
        }
    }

    private fun checkTrickTurn() {
        val state = _uiState.value
        if (state.phase != GamePhase.TRICK_PLAYING) return

        val currentP = state.players.find { it.id == state.currentTurnPlayerId } ?: return
        if (!currentP.isHuman && !currentP.isRemoteFriend) {
            viewModelScope.launch {
                _uiState.update { it.copy(isAiThinking = true) }
                delay(getAiDelay(750))

                val history = state.playedCards + state.currentTrickCards.map { it.card }
                val cardToPlay = TirbGameLogic.chooseAiCardToPlay(
                    hand = currentP.hand,
                    leadingSuit = state.leadingSuit,
                    trumpSuit = state.trumpSuit ?: Suit.CLUBS,
                    isBuyer = currentP.id == state.buyerId,
                    currentPlays = state.currentTrickCards,
                    buyerId = state.buyerId,
                    myPlayerId = currentP.id,
                    playedCardsHistory = history,
                    players = state.players,
                    currentRound = state.currentRound,
                    winningBid = state.winningBid
                )

                _uiState.update { it.copy(isAiThinking = false) }
                executeCardPlay(currentP, cardToPlay)
            }
        } else if (currentP.id == state.localPlayerSeatId && settingsManager.autoPlaySingleLegal.value) {
            // ميزة اللعب التلقائي العالمية إذا لم يكن للاعب سوى ورقة قانونية واحدة
            val playableCards = currentP.hand.filter {
                TirbGameLogic.isCardPlayable(it, currentP.hand, state.leadingSuit)
            }
            if (playableCards.size == 1) {
                viewModelScope.launch {
                    delay(getAiDelay(450))
                    if (_uiState.value.phase == GamePhase.TRICK_PLAYING && _uiState.value.currentTurnPlayerId == currentP.id) {
                        playHumanCard(playableCards.first())
                    }
                }
            }
        }
    }

    /**
     * بدء مباراة متعددة اللاعبين عبر البلوتوث
     */
    fun startMultiplayerGame(
        lobbyPlayers: List<LobbyPlayer>,
        mySeatId: Int,
        roomName: String,
        syncedDeck: List<Card>? = null
    ) {
        val configuredPlayers = (0..4).map { seatIndex ->
            val lobbyPlayer = lobbyPlayers.find { it.seatId == seatIndex }
            if (lobbyPlayer != null) {
                Player(
                    id = seatIndex,
                    name = lobbyPlayer.name,
                    isHuman = (seatIndex == mySeatId),
                    isRemoteFriend = (seatIndex != mySeatId && !lobbyPlayer.isAi)
                )
            } else {
                Player(
                    id = seatIndex,
                    name = "بوت ${seatIndex + 1}",
                    isHuman = false,
                    isRemoteFriend = false
                )
            }
        }

        _uiState.update {
            it.copy(
                isMultiplayerMode = true,
                localPlayerSeatId = mySeatId,
                multiplayerRoomName = roomName
            )
        }

        startRound(dealerId = 0, preserveCards = false, customPlayers = configuredPlayers, customDeck = syncedDeck)
    }

    private fun broadcastAction(type: BluetoothPacket.PacketType, payload: String) {
        val manager = bluetoothManager ?: return
        val senderSeat = _uiState.value.localPlayerSeatId
        val senderName = _uiState.value.players.find { it.id == senderSeat }?.name ?: "لاعب"
        val packet = BluetoothPacket(
            type = type,
            senderSeatId = senderSeat,
            senderName = senderName,
            payload = payload
        )
        manager.broadcastPacket(packet)
    }

    fun handleIncomingBluetoothPacket(packet: BluetoothPacket) {
        when (packet.type) {
            BluetoothPacket.PacketType.ACTION_BID -> {
                val parts = packet.payload.split(":")
                if (parts.size >= 2) {
                    val playerId = parts[0].toIntOrNull() ?: return
                    val amount = parts[1].toIntOrNull() ?: return
                    processBid(playerId, amount)
                }
            }
            BluetoothPacket.PacketType.ACTION_PASS -> {
                val playerId = packet.payload.toIntOrNull() ?: return
                processPass(playerId)
            }
            BluetoothPacket.PacketType.ACTION_PLAY_CARD -> {
                val parts = packet.payload.split(":")
                if (parts.size >= 2) {
                    val playerId = parts[0].toIntOrNull() ?: return
                    val cardId = parts[1]
                    val player = _uiState.value.players.find { it.id == playerId } ?: return
                    val card = player.hand.find { it.id == cardId } ?: return
                    executeCardPlay(player, card)
                }
            }
            BluetoothPacket.PacketType.ACTION_DECLARE_TRUMP -> {
                val parts = packet.payload.split(":")
                val suitName = if (parts.size >= 2) parts[1] else parts[0]
                val suit = Suit.entries.find { it.name.equals(suitName, ignoreCase = true) } ?: return
                declareTrump(suit)
            }
            BluetoothPacket.PacketType.ACTION_DISTRIBUTE_FIELD -> {
                val parts = packet.payload.split("|")
                if (parts.size >= 2) {
                    val map = parts[1].split(",").mapNotNull { item ->
                        val pair = item.split(":")
                        if (pair.size >= 2) {
                            val seat = pair[0].toIntOrNull()
                            val card = TirbGameLogic.getCardById(pair[1])
                            if (seat != null && card != null) seat to card else null
                        } else null
                    }.toMap()
                    if (map.size == 5) {
                        applyFieldDistribution(map)
                    }
                }
            }
            BluetoothPacket.PacketType.ACTION_START_AUCTION -> {
                val state = _uiState.value
                if (state.phase == GamePhase.INITIAL_DEAL) {
                    val starterName = state.players.find { it.id == state.currentTurnPlayerId }?.name ?: "اللاعب"
                    _uiState.value = state.copy(
                        phase = GamePhase.AUCTION,
                        gameLog = state.gameLog + "بدأ المزاد! السعر الافتتاحي 100 نقطة. دور $starterName..."
                    )
                    checkAuctionTurn()
                }
            }
            else -> {}
        }
    }

    /**
     * حسم نتيجة الجولة (الشولة) بعد اكتمال الـ 5 أوراق
     */
    private fun resolveCurrentTrick(plays: List<TrickPlay>) {
        val state = _uiState.value
        val leadingSuit = state.leadingSuit ?: Suit.CLUBS
        val trumpSuit = state.trumpSuit ?: Suit.CLUBS

        val winningPlay = TirbGameLogic.determineTrickWinner(plays, leadingSuit, trumpSuit)
        val trickPoints = plays.sumOf { it.card.points }

        val updatedPlayers = state.players.map {
            if (it.id == winningPlay.playerId) {
                it.copy(
                    pointsWon = it.pointsWon + trickPoints,
                    tricksWon = it.tricksWon + 1
                )
            } else {
                it
            }
        }

        val trickWonEntry = GameLogEntry.TrickWon(winningPlay.playerId, trickPoints, state.currentRound)
        val formattedTrick = trickWonEntry.format(LocalizationManager.strings.value, updatedPlayers)

        soundManager.playTrickWin()

        // فحص إنجاز الجوكر الملكي والاهتزاز اللمسي
        if (plays.any { it.card.isJoker && it.playerId == winningPlay.playerId && it.playerId == state.localPlayerSeatId }) {
            AchievementManager.recordJokerPlayed()
        }
        if (winningPlay.playerId == state.localPlayerSeatId) {
            hapticManager.celebration()
        } else {
            // تفاعل الروبوتات عند الفوز بأكلة قوية
            val botReactions = listOf("😎", "🔥", "🏆", "👏", "🃏")
            if (trickPoints >= 15 || (1..3).random() == 1) {
                ReactionManager.triggerReaction(winningPlay.playerId, botReactions.random())
            }
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    players = updatedPlayers,
                    lastTrickWinnerId = winningPlay.playerId,
                    lastTrickPoints = trickPoints,
                    showLastTrickSummary = true,
                    playedCards = it.playedCards + plays.map { p -> p.card },
                    logEntries = it.logEntries + trickWonEntry,
                    gameLog = it.gameLog + formattedTrick
                )
            }

            delay(getAiDelay(1800))

            if (state.currentRound >= 8) {
                // انتهاء الـ 8 جولات -> فحص القاعدة الذهبية
                concludeGame(updatedPlayers)
            } else {
                // الانتقال للجولة التالية
                val nextTrickEntry = GameLogEntry.TrickStarted(state.currentRound + 1, winningPlay.playerId)
                val formattedNext = nextTrickEntry.format(LocalizationManager.strings.value, updatedPlayers)
                _uiState.update {
                    it.copy(
                        currentRound = it.currentRound + 1,
                        currentTrickCards = emptyList(),
                        leadingSuit = null,
                        showLastTrickSummary = false,
                        currentTurnPlayerId = winningPlay.playerId, // الفائز يقود الجولة التالية
                        starterPlayerId = winningPlay.playerId,
                        logEntries = it.logEntries + nextTrickEntry,
                        gameLog = it.gameLog + formattedNext
                    )
                }
                checkTrickTurn()
            }
        }
    }

    /**
     * احتساب النتيجة النهائية وتطبيق القاعدة الذهبية ومنح الكروت الحمر والسود
     */
    private fun concludeGame(finalPlayers: List<Player>) {
        val state = _uiState.value
        val buyerId = state.buyerId ?: 0
        val buyer = finalPlayers.find { it.id == buyerId } ?: finalPlayers.first()
        val opponentsPoints = finalPlayers.filter { it.id != buyerId }.sumOf { it.pointsWon }
        val winningBid = state.winningBid
        val totalSum = opponentsPoints + winningBid
        val isBuyerWon = totalSum <= 187

        // تحديث الكروت الحمر والسود للمشتري
        val updatedPlayers = finalPlayers.map { player ->
            if (player.id == buyerId) {
                if (isBuyerWon) {
                    player.copy(redCards = player.redCards + 1)
                } else {
                    player.copy(blackCards = player.blackCards + 1)
                }
            } else {
                player
            }
        }

        val updatedBuyer = updatedPlayers.find { it.id == buyerId } ?: buyer
        val hasWonTournament = updatedBuyer.isExemptFromAuction // فاز باللعبة بحصوله على كرتين حمر (redCards >= 2)
        val isEliminated = updatedBuyer.isEliminated           // خسر اللعبة بحصوله على كرتين سود (blackCards >= 2)

        val celebration = when {
            isEliminated -> "انتهت اللعبة! حصل ${buyer.name} على كرتين سود ⬛⬛ ويُعد هو الخاسر في اللعبة!"
            hasWonTournament -> "مبروك! حقق ${buyer.name} كرتان حمر 🟥🟥 ولا يحق له الشراء مرة أخرى حتى تنتهي اللعبة، وتتم المزايدة بين اللاعبين الآخرين إلى أن يحصل لاعب على كرتين سود ويُعد هو الخاسر وعندها تنتهي اللعبة!"
            isBuyerWon -> "مبروك! نجح الشراء بفارق ${187 - totalSum} نقطة ونال ${buyer.name} كرت أحمر 🟥."
            else -> "خسارة! تجاوز الناتج الحد الأقصى (187) ونال ${buyer.name} كرت أسود ⬛."
        }

        val cardOutcomeLog = if (isBuyerWon) {
            "حصل المشتري (${buyer.name}) على كرت أحمر 🟥 (المجموع: ${updatedBuyer.redCards} كروت حمر)." +
                    if (hasWonTournament) " 🎉 حقق كرتان حمر وأصبح معفى من الشراء حتى تنتهي اللعبة!" else ""
        } else {
            "حصل المشتري (${buyer.name}) على كرت أسود ⬛ (المجموع: ${updatedBuyer.blackCards} كروت سود)." +
                    if (isEliminated) " ❌ خسر اللعبة لحصوله على كرتين سود ⬛⬛! انتهت اللعبة بين الـ 5 لاعبين." else ""
        }

        val outcomeEntry = if (isBuyerWon) GameLogEntry.RoundWonBuyer(buyerId) else GameLogEntry.RoundLostBuyer(buyerId)
        val currentStrings = LocalizationManager.strings.value
        val finalEntries = mutableListOf(outcomeEntry)
        if (isEliminated) {
            finalEntries.add(GameLogEntry.MatchOver(buyerId))
        }
        val formattedFinalLogs = finalEntries.map { it.format(currentStrings, updatedPlayers) }

        if (isBuyerWon) {
            soundManager.playRoundWin()
            if (buyer.id == state.localPlayerSeatId) {
                hapticManager.celebration()
                AchievementManager.recordHighBidWon(winningBid)
                AchievementManager.recordMatchResult(isWin = true)
            } else {
                AchievementManager.recordMatchResult(isWin = false)
            }
        } else {
            soundManager.playRoundLose()
            if (buyer.id != state.localPlayerSeatId) {
                hapticManager.celebration()
                AchievementManager.recordDefenderWin()
                AchievementManager.recordMatchResult(isWin = true)
            } else {
                AchievementManager.recordMatchResult(isWin = false)
            }
        }

        _uiState.update {
            it.copy(
                phase = GamePhase.GAME_OVER,
                players = updatedPlayers,
                isMatchOver = isEliminated,
                matchLoserPlayerId = if (isEliminated) buyerId else null,
                roundRedCardAwardedPlayerId = if (isBuyerWon) buyerId else null,
                roundBlackCardAwardedPlayerId = if (!isBuyerWon) buyerId else null,
                winnerCelebration = celebration,
                showLastTrickSummary = false,
                logEntries = it.logEntries + finalEntries,
                gameLog = it.gameLog + formattedFinalLogs
            )
        }

        // حفظ في قاعدة البيانات Room وتحديث الملف الشخصي
        viewModelScope.launch {
            repository.insertRecord(
                GameRecord(
                    buyerName = buyer.name,
                    isBuyerHuman = buyer.isHuman,
                    bid = winningBid,
                    trumpSuitName = state.trumpSuit?.arabicName ?: "غير محدد",
                    opponentsPoints = opponentsPoints,
                    buyerPoints = buyer.pointsWon,
                    totalSum = totalSum,
                    isBuyerWon = isBuyerWon
                )
            )

            val isHumanBuyer = buyer.isHuman
            val isHumanWinner = if (isHumanBuyer) isBuyerWon else !isBuyerWon
            val redCardsGained = if (isHumanBuyer && isBuyerWon) 1 else 0
            val blackAvoidedGained = if (!isHumanBuyer && !isBuyerWon) 1 else 0

            com.example.profile.UserProfileManager.recordMatch(
                context = getApplication(),
                isWin = isHumanWinner,
                isBuyer = isHumanBuyer,
                bid = winningBid,
                redCardsGained = redCardsGained,
                blackCardsAvoidedGained = blackAvoidedGained
            )

            com.example.leaderboard.LeaderboardRepository.recordRivalMatchResult(
                context = getApplication(),
                buyerId = buyer.id,
                isBuyerWon = isBuyerWon
            )
        }
    }

    /**
     * بدء مباراة متعددة اللاعبين عبر الإنترنت (Online Multiplayer Table)
     */
    fun startOnlineGame(room: com.example.online.OnlineRoom) {
        viewModelScope.launch {
            val players = room.players.mapIndexed { index, p ->
                Player(
                    id = index,
                    name = p.username,
                    isHuman = !p.isAiBot && index == 0,
                    redCards = 0,
                    blackCards = 0
                )
            }
            startRound(dealerId = 0, preserveCards = false, customPlayers = players)
            _uiState.update {
                it.copy(
                    isMultiplayerMode = true,
                    multiplayerRoomName = room.roomName
                )
            }
        }
    }

    /**
     * بدء مباراة تنافسية خاضعة للخادم الحاكم (Authoritative Competitive Match)
     */
    fun startCompetitiveMatch(room: com.example.online.CompetitiveOnlineRoom) {
        viewModelScope.launch {
            val myUid = com.example.online.FirebaseAuthManager.authState.value.uid
            val players = room.gameState.players.mapIndexed { index, p ->
                Player(
                    id = p.seatId,
                    name = p.username,
                    isHuman = p.uid == myUid || (myUid.isBlank() && index == 0),
                    redCards = p.redCards,
                    blackCards = p.blackCards
                )
            }
            startRound(dealerId = room.gameState.dealerSeatId, preserveCards = false, customPlayers = players)
            _uiState.update {
                it.copy(
                    isMultiplayerMode = true,
                    multiplayerRoomName = "${room.roomName} (${room.roomCode})"
                )
            }
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    override fun onCleared() {
        super.onCleared()
        soundManager.release()
    }
}
