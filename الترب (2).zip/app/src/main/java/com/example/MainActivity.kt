package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.localization.LocalAppLanguage
import com.example.localization.LocalAppStrings
import com.example.localization.LocalizationManager
import com.example.ui.TirbGameScreen
import com.example.ui.components.PreGameReminderScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.TirbViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    LocalizationManager.init(applicationContext)
    com.example.profile.UserProfileManager.init(applicationContext)
    com.example.profile.AchievementManager.init(applicationContext)
    setContent {
      val currentLang by LocalizationManager.currentLanguage.collectAsState()
      val strings by LocalizationManager.strings.collectAsState()
      val layoutDirection = if (currentLang.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

      CompositionLocalProvider(
        LocalLayoutDirection provides layoutDirection,
        LocalAppLanguage provides currentLang,
        LocalAppStrings provides strings
      ) {
        MyApplicationTheme {
          val viewModel: TirbViewModel = viewModel()
          var hasEnteredGame by rememberSaveable { mutableStateOf(false) }

          Crossfade(targetState = hasEnteredGame, label = "game_entry_transition") { entered ->
            if (!entered) {
              PreGameReminderScreen(
                onEnterGame = { hasEnteredGame = true },
                modifier = Modifier
                  .fillMaxSize()
                  .statusBarsPadding()
              )
            } else {
              TirbGameScreen(
                viewModel = viewModel,
                modifier = Modifier
                  .fillMaxSize()
                  .statusBarsPadding()
              )
            }
          }
        }
      }
    }
  }
}

