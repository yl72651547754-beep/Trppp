package com.example.profile

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class Achievement(
    val id: String,
    val icon: String,
    val titleArabic: String,
    val titleEnglish: String,
    val descArabic: String,
    val descEnglish: String,
    val currentProgress: Int,
    val maxProgress: Int,
    val isUnlocked: Boolean,
    val xpReward: Int
)

enum class VipTier(val titleArabic: String, val titleEnglish: String, val badge: String, val minXp: Int) {
    BRONZE("برونزي VIP", "Bronze VIP", "🥉", 0),
    SILVER("فضي VIP", "Silver VIP", "🥈", 300),
    GOLD("ذهبي VIP", "Gold VIP", "🥇", 800),
    PLATINUM("بلاتيني VIP", "Platinum VIP", "💎", 1800),
    DIAMOND("الماسي VIP", "Diamond VIP", "👑", 3500),
    LEGEND("أسطورة الترب", "Tirb Legend", "⚡", 6000)
}

object AchievementManager {

    private const val PREFS_NAME = "tirb_achievements_prefs"
    private const val KEY_TOTAL_XP = "total_player_xp"
    private const val KEY_AUCTION_140 = "ach_auction_140"
    private const val KEY_JOKER_WINS = "ach_joker_wins"
    private const val KEY_DEFENDER_WINS = "ach_defender_wins"
    private const val KEY_STREAK = "ach_current_streak"
    private const val KEY_BEST_STREAK = "ach_best_streak"

    private lateinit var prefs: SharedPreferences

    private val _playerXp = MutableStateFlow(0)
    val playerXp: StateFlow<Int> = _playerXp.asStateFlow()

    private val _achievements = MutableStateFlow<List<Achievement>>(emptyList())
    val achievements: StateFlow<List<Achievement>> = _achievements.asStateFlow()

    fun init(context: Context) {
        prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        _playerXp.value = prefs.getInt(KEY_TOTAL_XP, 0)
        refreshAchievements()
    }

    fun getVipTier(xp: Int): VipTier {
        return VipTier.entries.lastOrNull { xp >= it.minXp } ?: VipTier.BRONZE
    }

    fun getLevel(xp: Int): Int {
        return (xp / 150) + 1
    }

    fun getXpForNextLevel(xp: Int): Pair<Int, Int> {
        val currentLevel = getLevel(xp)
        val levelStart = (currentLevel - 1) * 150
        val levelEnd = currentLevel * 150
        val inLevelXp = xp - levelStart
        val needed = levelEnd - levelStart
        return Pair(inLevelXp, needed)
    }

    fun addXp(amount: Int) {
        if (!::prefs.isInitialized) return
        val newXp = _playerXp.value + amount
        _playerXp.value = newXp
        prefs.edit().putInt(KEY_TOTAL_XP, newXp).apply()
        refreshAchievements()
    }

    fun recordJokerPlayed() {
        if (!::prefs.isInitialized) return
        val count = prefs.getInt(KEY_JOKER_WINS, 0) + 1
        prefs.edit().putInt(KEY_JOKER_WINS, count).apply()
        addXp(35)
        refreshAchievements()
    }

    fun recordHighBidWon(bid: Int) {
        if (!::prefs.isInitialized) return
        if (bid >= 140) {
            val count = prefs.getInt(KEY_AUCTION_140, 0) + 1
            prefs.edit().putInt(KEY_AUCTION_140, count).apply()
            addXp(60)
            refreshAchievements()
        }
    }

    fun recordDefenderWin() {
        if (!::prefs.isInitialized) return
        val count = prefs.getInt(KEY_DEFENDER_WINS, 0) + 1
        prefs.edit().putInt(KEY_DEFENDER_WINS, count).apply()
        addXp(40)
        refreshAchievements()
    }

    fun recordMatchResult(isWin: Boolean) {
        if (!::prefs.isInitialized) return
        val currentStreak = if (isWin) prefs.getInt(KEY_STREAK, 0) + 1 else 0
        val bestStreak = maxOf(currentStreak, prefs.getInt(KEY_BEST_STREAK, 0))
        prefs.edit()
            .putInt(KEY_STREAK, currentStreak)
            .putInt(KEY_BEST_STREAK, bestStreak)
            .apply()
        if (isWin) addXp(50) else addXp(15)
        refreshAchievements()
    }

    fun refreshAchievements() {
        if (!::prefs.isInitialized) return
        val ach140 = prefs.getInt(KEY_AUCTION_140, 0)
        val achJoker = prefs.getInt(KEY_JOKER_WINS, 0)
        val achDef = prefs.getInt(KEY_DEFENDER_WINS, 0)
        val bestStreak = prefs.getInt(KEY_BEST_STREAK, 0)
        val totalXp = _playerXp.value

        _achievements.value = listOf(
            Achievement(
                id = "joker_master",
                icon = "🃏",
                titleArabic = "سيد الجوكر الملكي",
                titleEnglish = "Royal Joker Ace",
                descArabic = "لعب 2 كراول (25ن) وكسب الأكلة بها 3 مرات",
                descEnglish = "Play 2 of Clubs (25pts) and win 3 times",
                currentProgress = achJoker.coerceAtMost(3),
                maxProgress = 3,
                isUnlocked = achJoker >= 3,
                xpReward = 150
            ),
            Achievement(
                id = "high_bidder",
                icon = "🎯",
                titleArabic = "قناص المزاد الجريء",
                titleEnglish = "Auction High Roller",
                descArabic = "المزايدة بـ 140+ وتحقيق المزاد بنجاح",
                descEnglish = "Win auction with 140+ bid and fulfill it",
                currentProgress = ach140.coerceAtMost(2),
                maxProgress = 2,
                isUnlocked = ach140 >= 2,
                xpReward = 200
            ),
            Achievement(
                id = "iron_shield",
                icon = "🛡️",
                titleArabic = "حائط الصد الحديدي",
                titleEnglish = "Iron Wall Defender",
                descArabic = "إسقاط المشتري وهزيمته كمدافع 3 مرات",
                descEnglish = "Defeat the buyer as defenders 3 times",
                currentProgress = achDef.coerceAtMost(3),
                maxProgress = 3,
                isUnlocked = achDef >= 3,
                xpReward = 150
            ),
            Achievement(
                id = "win_streak",
                icon = "🔥",
                titleArabic = "سلسلة الانتصارات النارية",
                titleEnglish = "Blazing Streak",
                descArabic = "تحقيق سلسلة انتصارات متتالية لـ 3 جولات",
                descEnglish = "Achieve a 3-game consecutive win streak",
                currentProgress = bestStreak.coerceAtMost(3),
                maxProgress = 3,
                isUnlocked = bestStreak >= 3,
                xpReward = 250
            ),
            Achievement(
                id = "vip_club",
                icon = "👑",
                titleArabic = "عضوية نادي كبار الشخصيات",
                titleEnglish = "VIP Club Member",
                descArabic = "الوصول إلى 800 نقطة خبرة وفتح VIP الذهبي",
                descEnglish = "Reach 800 XP and unlock Gold VIP",
                currentProgress = totalXp.coerceAtMost(800),
                maxProgress = 800,
                isUnlocked = totalXp >= 800,
                xpReward = 300
            )
        )
    }
}
