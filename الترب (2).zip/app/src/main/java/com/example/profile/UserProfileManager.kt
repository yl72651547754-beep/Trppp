package com.example.profile

import android.content.Context
import com.example.model.Suit
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlin.random.Random

data class UserProfile(
    val username: String = "لاعب_الترب",
    val playerId: String = "#TRB-7824",
    val avatarId: Int = 0, // 0 to 7
    val title: String = "مبتدئ الترب",
    val level: Int = 1,
    val totalMatches: Int = 0,
    val wins: Int = 0,
    val redCardsWon: Int = 0,
    val blackCardsAvoided: Int = 0,
    val highestBidWon: Int = 0,
    val currentStreak: Int = 0,
    val bestStreak: Int = 0,
    val favoriteSuit: Suit = Suit.CLUBS,
    val friends: List<FriendPlayer> = emptyList()
) {
    val winRate: Int
        get() = if (totalMatches > 0) ((wins.toDouble() / totalMatches) * 100).toInt() else 0
}

data class FriendPlayer(
    val playerId: String,
    val username: String,
    val avatarId: Int = 1,
    val isOnline: Boolean = true,
    val wins: Int = 0,
    val totalMatches: Int = 0,
    val title: String = "صديق"
)

object UserProfileManager {
    private const val PREFS_NAME = "tirb_user_profile_prefs"
    private const val KEY_USERNAME = "username"
    private const val KEY_PLAYER_ID = "player_id"
    private const val KEY_AVATAR_ID = "avatar_id"
    private const val KEY_TOTAL_MATCHES = "total_matches"
    private const val KEY_WINS = "wins"
    private const val KEY_RED_CARDS = "red_cards"
    private const val KEY_BLACK_CARDS = "black_cards"
    private const val KEY_HIGHEST_BID = "highest_bid"
    private const val KEY_CURRENT_STREAK = "current_streak"
    private const val KEY_BEST_STREAK = "best_streak"
    private const val KEY_IS_INITIALIZED_CLEAN = "is_clean_profile_v2"
    private const val KEY_FRIENDS_LIST = "friends_list_saved_v1"

    private var appContext: Context? = null
    private val _profile = MutableStateFlow(UserProfile())
    val profile: StateFlow<UserProfile> = _profile.asStateFlow()

    fun init(context: Context) {
        appContext = context.applicationContext
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        // التحقق من تنظيف البيانات الوهمية السابقة (48 مباراة، 34 فوز)
        val isClean = prefs.getBoolean(KEY_IS_INITIALIZED_CLEAN, false)
        val rawMatches = prefs.getInt(KEY_TOTAL_MATCHES, 0)
        val rawWins = prefs.getInt(KEY_WINS, 0)
        val rawReds = prefs.getInt(KEY_RED_CARDS, 0)

        // إذا كانت القيمة القديمة مطابقة للقالب الوهمي (48/34)، نصفرها لبدء سجل حقيقي نظيف
        val shouldResetMock = !isClean && (rawMatches == 48 && rawWins == 34 && rawReds == 31)

        val totalMatches = if (shouldResetMock) 0 else prefs.getInt(KEY_TOTAL_MATCHES, 0)
        val wins = if (shouldResetMock) 0 else prefs.getInt(KEY_WINS, 0)
        val redCards = if (shouldResetMock) 0 else prefs.getInt(KEY_RED_CARDS, 0)
        val blackCards = if (shouldResetMock) 0 else prefs.getInt(KEY_BLACK_CARDS, 0)
        val highestBid = if (shouldResetMock) 0 else prefs.getInt(KEY_HIGHEST_BID, 0)
        val currentStreak = if (shouldResetMock) 0 else prefs.getInt(KEY_CURRENT_STREAK, 0)
        val bestStreak = if (shouldResetMock) 0 else prefs.getInt(KEY_BEST_STREAK, 0)

        val defaultId = "#TRB-" + (1000 + Random.nextInt(9000))
        val playerId = prefs.getString(KEY_PLAYER_ID, null) ?: run {
            prefs.edit().putString(KEY_PLAYER_ID, defaultId).apply()
            defaultId
        }
        val username = prefs.getString(KEY_USERNAME, "لاعب_الترب") ?: "لاعب_الترب"
        val avatarId = prefs.getInt(KEY_AVATAR_ID, 0)

        if (shouldResetMock || !isClean) {
            prefs.edit()
                .putBoolean(KEY_IS_INITIALIZED_CLEAN, true)
                .putInt(KEY_TOTAL_MATCHES, totalMatches)
                .putInt(KEY_WINS, wins)
                .putInt(KEY_RED_CARDS, redCards)
                .putInt(KEY_BLACK_CARDS, blackCards)
                .putInt(KEY_HIGHEST_BID, highestBid)
                .putInt(KEY_CURRENT_STREAK, currentStreak)
                .putInt(KEY_BEST_STREAK, bestStreak)
                .apply()
        }

        val calculatedLevel = (wins / 3) + 1
        val calculatedTitle = when {
            wins >= 25 -> "أسطورة الترب الكبرى 👑"
            wins >= 15 -> "خبير الترب والمزادات ⚔️"
            wins >= 8 -> "محترف متقدم 💎"
            wins >= 3 -> "هاوي متمرس 🌟"
            else -> "مبتدئ الترب 🎴"
        }

        // تحميل قائمة الأصدقاء الحقيقية المحفوظة مع إزالة أي أسماء وهمية قديمة
        val mockNamesOrIds = setOf(
            "#TRB-9104", "#TRB-5520", "#TRB-8832", "#TRB-7719", "#TRB-3312", "#TRB-4412", "#TRB-6621",
            "بندر_العتيبي", "سالم_الدوسري", "خالد_الشمري", "أبو_فهد", "ناصر_الحربي", "سعد_القحطاني", "طارق_الغامدي"
        )
        val savedFriendsSet = prefs.getStringSet(KEY_FRIENDS_LIST, emptySet()) ?: emptySet()
        val loadedFriends = savedFriendsSet.mapNotNull { str ->
            val parts = str.split("\t")
            if (parts.size >= 7) {
                val fId = parts[0]
                val fName = parts[1]
                if (fId in mockNamesOrIds || fName in mockNamesOrIds) {
                    null
                } else {
                    FriendPlayer(
                        playerId = fId,
                        username = fName,
                        avatarId = parts[2].toIntOrNull() ?: 0,
                        isOnline = parts[3].toBooleanStrictOrNull() ?: true,
                        wins = parts[4].toIntOrNull() ?: 0,
                        totalMatches = parts[5].toIntOrNull() ?: 0,
                        title = parts[6]
                    )
                }
            } else null
        }

        // حفظ القائمة المنظفة من الأسماء الوهمية
        if (loadedFriends.size != savedFriendsSet.size) {
            val cleanedSet = loadedFriends.map { f ->
                "${f.playerId}\t${f.username}\t${f.avatarId}\t${f.isOnline}\t${f.wins}\t${f.totalMatches}\t${f.title}"
            }.toSet()
            prefs.edit().putStringSet(KEY_FRIENDS_LIST, cleanedSet).apply()
        }

        _profile.value = UserProfile(
            username = username,
            playerId = playerId,
            avatarId = avatarId,
            level = calculatedLevel,
            title = calculatedTitle,
            totalMatches = totalMatches,
            wins = wins,
            redCardsWon = redCards,
            blackCardsAvoided = blackCards,
            highestBidWon = highestBid,
            currentStreak = currentStreak,
            bestStreak = bestStreak,
            friends = loadedFriends
        )
    }

    fun updateUsername(context: Context, newName: String) {
        val trimmed = newName.trim()
        if (trimmed.isEmpty()) return
        _profile.update { it.copy(username = trimmed) }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_USERNAME, trimmed).apply()
    }

    fun updateUsernameFromAuth(newName: String, newPlayerId: String? = null) {
        val trimmed = newName.trim()
        if (trimmed.isEmpty()) return
        _profile.update { current ->
            current.copy(
                username = trimmed,
                playerId = newPlayerId ?: current.playerId
            )
        }
        appContext?.let { ctx ->
            val editor = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            editor.putString(KEY_USERNAME, trimmed)
            if (newPlayerId != null) {
                editor.putString(KEY_PLAYER_ID, newPlayerId)
            }
            editor.apply()
        }
    }

    fun updateAvatar(context: Context, newAvatarId: Int) {
        _profile.update { it.copy(avatarId = newAvatarId) }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putInt(KEY_AVATAR_ID, newAvatarId).apply()
    }

    fun recordMatch(
        context: Context,
        isWin: Boolean,
        isBuyer: Boolean,
        bid: Int,
        redCardsGained: Int,
        blackCardsAvoidedGained: Int = 0
    ) {
        _profile.update { current ->
            val newTotal = current.totalMatches + 1
            val newWins = if (isWin) current.wins + 1 else current.wins
            val newReds = current.redCardsWon + redCardsGained
            val newBlackAvoided = current.blackCardsAvoided + blackCardsAvoidedGained
            val newHighest = if (isWin && isBuyer && bid > current.highestBidWon) bid else current.highestBidWon
            val newStreak = if (isWin) current.currentStreak + 1 else 0
            val newBestStreak = maxOf(newStreak, current.bestStreak)

            val newLevel = (newWins / 3) + 1
            val newTitle = when {
                newWins >= 25 -> "أسطورة الترب الكبرى 👑"
                newWins >= 15 -> "خبير الترب والمزادات ⚔️"
                newWins >= 8 -> "محترف متقدم 💎"
                newWins >= 3 -> "هاوي متمرس 🌟"
                else -> "مبتدئ الترب 🎴"
            }

            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putInt(KEY_TOTAL_MATCHES, newTotal)
                .putInt(KEY_WINS, newWins)
                .putInt(KEY_RED_CARDS, newReds)
                .putInt(KEY_BLACK_CARDS, newBlackAvoided)
                .putInt(KEY_HIGHEST_BID, newHighest)
                .putInt(KEY_CURRENT_STREAK, newStreak)
                .putInt(KEY_BEST_STREAK, newBestStreak)
                .apply()

            current.copy(
                totalMatches = newTotal,
                wins = newWins,
                redCardsWon = newReds,
                blackCardsAvoided = newBlackAvoided,
                highestBidWon = newHighest,
                currentStreak = newStreak,
                bestStreak = newBestStreak,
                level = newLevel,
                title = newTitle
            )
        }
    }

    private fun saveFriendsToPrefs(friends: List<FriendPlayer>) {
        appContext?.let { ctx ->
            val set = friends.map { f ->
                "${f.playerId}\t${f.username}\t${f.avatarId}\t${f.isOnline}\t${f.wins}\t${f.totalMatches}\t${f.title}"
            }.toSet()
            ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putStringSet(KEY_FRIENDS_LIST, set)
                .apply()
        }
    }

    fun addFriend(friend: FriendPlayer): Boolean {
        if (friend.playerId == _profile.value.playerId || friend.username.equals(_profile.value.username, ignoreCase = true)) {
            return false
        }
        if (_profile.value.friends.any { it.playerId.equals(friend.playerId, ignoreCase = true) || it.username.equals(friend.username, ignoreCase = true) }) {
            return false
        }
        val updated = _profile.value.friends + friend
        _profile.update { it.copy(friends = updated) }
        saveFriendsToPrefs(updated)
        return true
    }

    fun addFriend(idOrUsername: String): Boolean {
        val query = idOrUsername.trim()
        if (query.isEmpty() || query == _profile.value.playerId || query.equals(_profile.value.username, ignoreCase = true)) {
            return false
        }

        // Check if already friends
        if (_profile.value.friends.any { it.playerId.equals(query, ignoreCase = true) || it.username.equals(query, ignoreCase = true) }) {
            return false
        }

        val newFriendId = if (query.startsWith("#TRB-")) query.uppercase() else "#TRB-" + (1000 + Random.nextInt(9000))
        val newFriendName = if (query.startsWith("#TRB-")) "لاعب_${query.takeLast(4)}" else query

        val newFriend = FriendPlayer(
            playerId = newFriendId,
            username = newFriendName,
            avatarId = Random.nextInt(availableAvatars.size),
            isOnline = true,
            wins = Random.nextInt(3, 15),
            totalMatches = Random.nextInt(15, 25),
            title = "صديق الترب 🎴"
        )

        val updated = _profile.value.friends + newFriend
        _profile.update { it.copy(friends = updated) }
        saveFriendsToPrefs(updated)
        return true
    }

    fun removeFriend(playerId: String) {
        val updated = _profile.value.friends.filterNot { f -> f.playerId == playerId }
        _profile.update { it.copy(friends = updated) }
        saveFriendsToPrefs(updated)
    }

    val availableAvatars = listOf(
        AvatarItem(0, "👑", "السلطان", "Sultan"),
        AvatarItem(1, "🦅", "الصقر", "Falcon"),
        AvatarItem(2, "🃏", "الجوكر الملكي", "Royal Joker"),
        AvatarItem(3, "🦁", "الأسد", "Lion"),
        AvatarItem(4, "⚔️", "الفارس", "Knight"),
        AvatarItem(5, "🎴", "سيد الورق", "Card Master"),
        AvatarItem(6, "💎", "الأمير", "Prince"),
        AvatarItem(7, "🌟", "البطل", "Champion")
    )
}

data class AvatarItem(
    val id: Int,
    val emoji: String,
    val titleArabic: String,
    val titleEnglish: String
)
