package com.example.profile

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.ForwardToInbox
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.localization.LocalizationManager
import com.example.ui.theme.CardIvory
import com.example.ui.theme.FeltGreenDark
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.JokerViolet
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuitRed
import com.example.ui.theme.SurfaceCardContainer
import com.example.ui.theme.SurfaceDarkNavy

@Composable
fun UserProfileDialog(
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val profile by UserProfileManager.profile.collectAsState()
    val strings = LocalizationManager.strings.collectAsState().value
    val isRtl = LocalizationManager.currentLanguage.collectAsState().value.isRtl

    var isEditingName by remember { mutableStateOf(false) }
    var editedName by remember(profile.username) { mutableStateOf(profile.username) }
    var showAvatarPicker by remember { mutableStateOf(false) }

    var friendInput by remember { mutableStateOf("") }
    var friendMessage by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDarkNavy),
            border = BorderStroke(2.dp, GoldPrimary),
            elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header with Close
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "👑", fontSize = 20.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isRtl) "الملف الشخصي للاعب" else "Player Profile",
                            color = GoldLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = strings.closeButton,
                            tint = GoldLight
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Avatar & Player Identity
                val currentAvatar = UserProfileManager.availableAvatars.getOrNull(profile.avatarId)
                    ?: UserProfileManager.availableAvatars.first()

                Box(contentAlignment = Alignment.BottomEnd) {
                    Surface(
                        modifier = Modifier
                            .size(76.dp)
                            .clickable { showAvatarPicker = !showAvatarPicker },
                        shape = CircleShape,
                        color = FeltGreenDark,
                        border = BorderStroke(2.5.dp, GoldPrimary)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(text = currentAvatar.emoji, fontSize = 38.sp)
                        }
                    }
                    Surface(
                        modifier = Modifier
                            .size(26.dp)
                            .clickable { showAvatarPicker = !showAvatarPicker },
                        shape = CircleShape,
                        color = GoldDark,
                        border = BorderStroke(1.5.dp, Color.White)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit Avatar",
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }

                // Avatar Picker Row
                if (showAvatarPicker) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isRtl) "اختر شعارك الملكي:" else "Choose Royal Avatar:",
                        color = GoldLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        UserProfileManager.availableAvatars.forEach { item ->
                            val isSelected = item.id == profile.avatarId
                            Surface(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clickable {
                                        UserProfileManager.updateAvatar(context, item.id)
                                        showAvatarPicker = false
                                    },
                                shape = CircleShape,
                                color = if (isSelected) GoldDark else SurfaceCardContainer,
                                border = BorderStroke(if (isSelected) 2.dp else 1.dp, if (isSelected) GoldLight else Color.Gray)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(text = item.emoji, fontSize = 18.sp)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Username & Edit
                if (isEditingName) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        OutlinedTextField(
                            value = editedName,
                            onValueChange = { editedName = it.take(20) },
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = GoldDark,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = {
                                UserProfileManager.updateUsername(context, editedName)
                                isEditingName = false
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .background(SuccessGreen, RoundedCornerShape(8.dp))
                        ) {
                            Icon(Icons.Default.Check, contentDescription = "Save", tint = Color.White)
                        }
                    }
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = profile.username,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = { isEditingName = true },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit Name", tint = GoldLight, modifier = Modifier.size(16.dp))
                        }
                    }
                }

                // Player ID with Copy Button
                Surface(
                    modifier = Modifier
                        .padding(vertical = 4.dp)
                        .clickable {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Tirb Player ID", profile.playerId))
                            Toast.makeText(context, if (isRtl) "تم نسخ الـ ID: ${profile.playerId}" else "Copied ID: ${profile.playerId}", Toast.LENGTH_SHORT).show()
                        },
                    shape = RoundedCornerShape(12.dp),
                    color = FeltGreenDark,
                    border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.8f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${if (isRtl) "معرف اللاعب (ID)" else "Player ID"}: ${profile.playerId}",
                            color = GoldLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy ID",
                            tint = GoldLight,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                // Title & Level Badge
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = JokerViolet.copy(alpha = 0.7f),
                    border = BorderStroke(1.dp, GoldLight)
                ) {
                    Text(
                        text = "⭐ ${profile.title} • ${if (isRtl) "مستوى" else "Level"} ${profile.level}",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Stats Grid
                Text(
                    text = if (isRtl) "📊 إحصائيات الإنجاز في الترب" else "📊 Career Achievements",
                    color = GoldLight,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = if (isRtl) TextAlign.Right else TextAlign.Left
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    StatCard(
                        title = if (isRtl) "المباريات" else "Matches",
                        value = "${profile.totalMatches}",
                        color = GoldDark,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = if (isRtl) "الفوز" else "Wins",
                        value = "${profile.wins}",
                        color = SuccessGreen,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = if (isRtl) "نسبة الفوز" else "Win Rate",
                        value = "${profile.winRate}%",
                        color = GoldPrimary,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    StatCard(
                        title = if (isRtl) "كروت حمر 🟥" else "Red Cards 🟥",
                        value = "${profile.redCardsWon}",
                        color = SuitRed,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = if (isRtl) "تجنب السود ⬛" else "Black Avoided",
                        value = "${profile.blackCardsAvoided}",
                        color = FeltGreenDark,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = if (isRtl) "أعلى مزاد" else "Max Bid",
                        value = "${profile.highestBidWon}",
                        color = JokerViolet,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Friends & Add Player section
                Text(
                    text = if (isRtl) "👥 قائمة الأصدقاء والمنافسين" else "👥 Friends & Rivals",
                    color = GoldLight,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Add Friend input
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = friendInput,
                        onValueChange = {
                            friendInput = it
                            friendMessage = null
                        },
                        placeholder = {
                            Text(
                                text = if (isRtl) "أدخل اسم المستخدم أو ID (مثال: #TRB-4190)" else "Enter username or ID (#TRB-...)",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = GoldDark.copy(alpha = 0.6f),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = {
                            val success = UserProfileManager.addFriend(friendInput)
                            if (success) {
                                friendMessage = if (isRtl) "تمت إضافة الصديق بنجاح!" else "Friend added successfully!"
                                friendInput = ""
                            } else {
                                friendMessage = if (isRtl) "الاسم أو الـ ID موجود بالفعل أو غير صالح" else "Already in friends or invalid"
                            }
                        },
                        modifier = Modifier.height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.PersonAdd, contentDescription = "Add Friend", tint = FeltGreenDark)
                    }
                }

                friendMessage?.let { msg ->
                    Text(
                        text = msg,
                        color = if (msg.contains("نجاح") || msg.contains("successfully")) SuccessGreen else SuitRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Friends List
                if (profile.friends.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isRtl) "لا يوجد أصدقاء بعد. أضف بالمعرف أو عبر البلوتوث!" else "No friends yet. Add by ID or via Bluetooth!",
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 140.dp)
                    ) {
                        items(profile.friends) { friend ->
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                shape = RoundedCornerShape(8.dp),
                                color = SurfaceCardContainer,
                                border = BorderStroke(1.dp, GoldDark.copy(alpha = 0.4f))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(if (friend.isOnline) SuccessGreen else Color.Gray)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = friend.username,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = friend.playerId,
                                            color = GoldLight.copy(alpha = 0.8f),
                                            fontSize = 10.sp
                                        )
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "${friend.wins} ${if (isRtl) "فوز" else "W"}",
                                            color = GoldLight,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        IconButton(
                                            onClick = { UserProfileManager.removeFriend(friend.playerId) },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Remove Friend",
                                                tint = Color.Gray,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = SurfaceCardContainer,
        border = BorderStroke(1.dp, color.copy(alpha = 0.7f))
    ) {
        Column(
            modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
            Text(text = title, color = GoldLight, fontSize = 9.sp, fontWeight = FontWeight.Medium)
        }
    }
}
