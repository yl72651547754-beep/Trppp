package com.example.localization

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import com.example.model.Card
import com.example.model.Player
import com.example.model.Rank
import com.example.model.Suit
import com.example.bluetooth.LobbyPlayer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * اللغات السبع المدعومة في لعبة الترب:
 * 1. العربية (Arabic)
 * 2. الإنجليزية (English)
 * 3. الفرنسية (French)
 * 4. الإسبانية (Spanish)
 * 5. التركية (Turkish)
 * 6. الأردية (Urdu)
 * 7. الروسية (Russian)
 */
enum class AppLanguage(
    val code: String,
    val nativeName: String,
    val englishName: String,
    val flag: String,
    val isRtl: Boolean
) {
    ARABIC("ar", "العربية", "Arabic", "🇸🇦", true),
    ENGLISH("en", "English", "English", "🇬🇧", false),
    FRENCH("fr", "Français", "French", "🇫🇷", false),
    SPANISH("es", "Español", "Spanish", "🇪🇸", false),
    TURKISH("tr", "Türkçe", "Turkish", "🇹🇷", false),
    URDU("ur", "اردو", "Urdu", "🇵🇰", true),
    RUSSIAN("ru", "Русский", "Russian", "🇷🇺", false)
}

data class LocalizedStrings(
    val appName: String,
    val gameTitle: String,
    val importantReminderBadge: String,
    val religiousReminder: String,
    val reminderSubtext: String,
    val enterGameButton: String,
    val chooseLanguage: String,
    val currentLangLabel: String,
    val closeButton: String,

    // Header & Navigation
    val roundOfEight: String,
    val trickLabel: String,
    val highestBidder: String,
    val buyerLabel: String,
    val trumpSuitLabel: String,
    val notDeclaredYet: String,
    val rulesButton: String,
    val historyButton: String,
    val multiplayerButton: String,
    val singlePlayerMode: String,
    val bluetoothMultiplayerMode: String,
    val phaseDeal: String,
    val phaseField: String,
    val phaseResult: String,
    val dealerLabel: String,
    val auctionStarterLabel: String,

    // Opponents & Player Area
    val youLabel: String,
    val dealerBadge: String,
    val buyerBadge: String,
    val winnerBadge: String,
    val loserBadge: String,
    val passBadge: String,
    val yourTurnToPlayBadge: String,
    val pointsAndTricks: String,
    val cardsCountAndPoints: String,
    val aiThinking: String,
    val friendThinking: String,
    val yourTurnToPlay: String,

    // Center Field & Initial Deal
    val fieldCardsHiddenTitle: String,
    val waitingRoundStart: String,
    val trickWonMessage: String,
    val gameBannerFivePlayers: String,
    val initialDealInspectCards: String,
    val initialDealHandSummary: String,
    val startAuctionButton: String,
    val welcomeTicker: String,
    val thinkingTicker: String,

    // Auction
    val auctionTitle: String,
    val currentBidLabel: String,
    val bidPass: String,
    val bidRaise: String,
    val bidBuyDirect: String,
    val yourTurnToBid: String,
    val waitingBids: String,
    val maxBidReached: String,
    val buyerWonAuction: String,
    val auctionTitleWithGavel: String,
    val auctionStarterAnnounce: String,
    val bidBuyDirectAction: String,
    val raiseCustomBid: String,
    val passedAlready: String,
    val waitingOthersBids: String,

    // Field Distribution
    val fieldDistributionTitle: String,
    val fieldDistributionDesc: String,
    val selectCardForPlayer: String,
    val confirmDistribution: String,
    val cardRemaining: String,
    val fieldDistrInstruction: String,
    val cardsRemainingToAssign: String,
    val assignedCardBadge: String,
    val tapToAssign: String,
    val confirmAndContinue: String,
    val buyerDistributingField: String,

    // Trump Declaration
    val declareTrumpTitle: String,
    val selectTrumpSuit: String,
    val spades: String,
    val hearts: String,
    val diamonds: String,
    val clubs: String,
    val confirmTrump: String,
    val trumpDialogTitle: String,
    val trumpDialogDesc: String,
    val confirmTrumpChoice: String,
    val trumpClubsJokerDesc: String,
    val trumpSpadesDesc: String,
    val trumpHeartsDesc: String,
    val trumpDiamondsDesc: String,

    // Suits & Ranks
    val spadesName: String,
    val heartsName: String,
    val diamondsName: String,
    val clubsName: String,
    val jokerBig: String,
    val jokerSmall: String,
    val jokerTitle: String,
    val rankAce: String,
    val rankKing: String,
    val rankQueen: String,
    val rankJack: String,

    // Game Over & Golden Rule
    val goldenRuleTitle: String,
    val goldenSumLabel: String,
    val buyerTargetPoints: String,
    val buyerWonGame: String,
    val opponentsWonGame: String,
    val newRoundButton: String,
    val redCardAwarded: String,
    val blackCardAwarded: String,
    val matchOverFivePlayers: String,
    val buyerWonRound: String,
    val buyerLostRound: String,
    val matchOverExplanation: String,
    val buyerSuccessExplanation: String,
    val buyerFailExplanation: String,
    val goldenRuleEquationTitle: String,
    val opponentsPointsLabel: String,
    val winningBidLabel: String,
    val goldenSumTotalLabel: String,
    val roundSummaryTitle: String,
    val startNextRoundButton: String,
    val startNewGameButton: String,

    // History Sheet
    val historyDialogTitle: String,
    val noHistoryRecorded: String,
    val historyBuyerWon: String,
    val historyBuyerLost: String,
    val historyBidDetails: String,
    val historyEquation: String,
    val clearHistoryButton: String,

    // Rules Help Sheet
    val rulesDialogTitle: String,
    val rule1Title: String,
    val rule1Content: String,
    val rule2Title: String,
    val rule2Content: String,
    val rule3Title: String,
    val rule3Content: String,
    val rule4Title: String,
    val rule4Content: String,
    val rule5Title: String,
    val rule5Content: String,
    val rule6Title: String,
    val rule6Content: String,
    val rule7Title: String,
    val rule7Content: String,
    val rule8Title: String,
    val rule8Content: String,

    // Bluetooth
    val bluetoothTitle: String,
    val bluetoothHostTab: String,
    val bluetoothJoinTab: String,
    val bluetoothRoomName: String,
    val bluetoothConnectedPlayers: String,
    val bluetoothStartGame: String,
    val bluetoothAddAiBot: String,
    val bluetoothRemoveAiBot: String,
    val bluetoothScanning: String,
    val bluetoothScanDevices: String,
    val bluetoothPairedDevices: String,
    val bluetoothAvailableDevices: String,
    val bluetoothNoDevicesFound: String,
    val bluetoothConnecting: String,
    val bluetoothConnected: String,
    val bluetoothDisconnected: String,
    val bluetoothSimulationMode: String,
    val bluetoothSimDesc: String,
    val bluetoothNeedPermission: String,
    val bluetoothGrantPermission: String,
    val bluetoothTurnOn: String,
    val bluetoothWaitingForHost: String,
    val bluetoothHostControlsGame: String,
    val bluetoothQuickChat: String,
    val quickChatHello: String,
    val quickChatWellPlayed: String,
    val quickChatStrongTrump: String,
    val quickChatGoodLuck: String,
    val suitSpadesSymbol: String,
    val suitHeartsSymbol: String,
    val suitDiamondsSymbol: String,
    val suitClubsSymbol: String,
    val exemptFromAuctionBanner: String,
    val exemptBadge: String,
    val bluetoothJoinedLobbyTitle: String,
    val bluetoothWaitingHostDesc: String,
    val bluetoothLeaveLobbyButton: String,
    val matchLoserCardBanner: String,
    val matchWinnersCardBanner: String,

    // Quick Chat extras
    val quickChatMyTrumpIsStrong: String,
    val quickChatStayFocused: String,

    // Auction & Rules extras
    val bidCapLabel: String,
    val buyerTwoRedCardsExemptNotice: String,

    // Bluetooth dialog extras
    val bluetoothSubHeader: String,
    val activeLabel: String,
    val testButton: String,
    val fiveSeatsFullGame: String,
    val seatNumberAndName: String,
    val hostBadge: String,
    val aiBotPlayer: String,
    val yourCurrentDevice: String,
    val bluetoothConnectedFriend: String,
    val openForFriend: String,
    val switchToAi: String,
    val pairedDeviceTapToConnect: String,
    val connectButton: String,

    // Cards & UI
    val jokerCard: String,
    val faceDownCard: String,
    val pointsBadgeSuffix: String,
    val equationSummaryProgress: String,
    val cardJokerDesc: String,

    // Dynamic Game Logs
    val logPlayerRaisedBid: String,
    val logPlayerPassedBid: String,
    val logPlayerWonAuction: String,
    val logMaxBidReached: String,
    val logRoundStarted: String,
    val logDealInitialInstructions: String,
    val logAuctionStarted: String,
    val logFieldDistributed: String,
    val logTrumpDeclared: String,
    val logTrickStarted: String,
    val logCardPlayed: String,
    val logTrickWon: String,
    val logRoundWonBuyer: String,
    val logRoundLostBuyer: String
)

object LocalizationManager {
    private const val PREFS_NAME = "tirb_app_preferences"
    private const val KEY_LANGUAGE = "selected_app_language"

    private val _currentLanguage = MutableStateFlow(AppLanguage.ARABIC)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    private val _strings = MutableStateFlow(getStringsForLanguage(AppLanguage.ARABIC))
    val strings: StateFlow<LocalizedStrings> = _strings.asStateFlow()

    fun init(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedCode = prefs.getString(KEY_LANGUAGE, AppLanguage.ARABIC.code) ?: AppLanguage.ARABIC.code
        val language = AppLanguage.entries.find { it.code == savedCode } ?: AppLanguage.ARABIC
        setLanguage(context, language)
    }

    fun setLanguage(context: Context, language: AppLanguage) {
        _currentLanguage.value = language
        _strings.value = getStringsForLanguage(language)
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_LANGUAGE, language.code).apply()
    }

    fun getStringsForLanguage(lang: AppLanguage): LocalizedStrings {
        return when (lang) {
            AppLanguage.ARABIC -> ArabicStrings
            AppLanguage.ENGLISH -> EnglishStrings
            AppLanguage.FRENCH -> FrenchStrings
            AppLanguage.SPANISH -> SpanishStrings
            AppLanguage.TURKISH -> TurkishStrings
            AppLanguage.URDU -> UrduStrings
            AppLanguage.RUSSIAN -> RussianStrings
        }
    }
}

fun Suit.getLocalizedName(strings: LocalizedStrings): String = when (this) {
    Suit.SPADES -> strings.spadesName
    Suit.HEARTS -> strings.heartsName
    Suit.DIAMONDS -> strings.diamondsName
    Suit.CLUBS -> strings.clubsName
}

fun Suit.getLocalizedSymbolWithName(strings: LocalizedStrings): String = when (this) {
    Suit.SPADES -> strings.suitSpadesSymbol
    Suit.HEARTS -> strings.suitHeartsSymbol
    Suit.DIAMONDS -> strings.suitDiamondsSymbol
    Suit.CLUBS -> strings.suitClubsSymbol
}

val LocalAppStrings = staticCompositionLocalOf {
    ArabicStrings
}

val LocalAppLanguage = staticCompositionLocalOf {
    AppLanguage.ARABIC
}

fun Card.getLocalizedTitle(strings: LocalizedStrings): String = when (rank) {
    Rank.JOKER_BIG -> "${strings.jokerBig} (0${strings.pointsBadgeSuffix})"
    Rank.JOKER_SMALL -> "${strings.jokerSmall} (0${strings.pointsBadgeSuffix})"
    Rank.TWO -> if (suit == Suit.CLUBS) "2 ${suit.getLocalizedName(strings)} (${strings.cardJokerDesc})" else "2 ${suit.getLocalizedName(strings)} (10${strings.pointsBadgeSuffix})"
    Rank.ACE -> "${strings.rankAce} ${suit.getLocalizedName(strings)} (11${strings.pointsBadgeSuffix})"
    Rank.KING -> "${strings.rankKing} ${suit.getLocalizedName(strings)} (4${strings.pointsBadgeSuffix})"
    Rank.QUEEN -> "${strings.rankQueen} ${suit.getLocalizedName(strings)} (4${strings.pointsBadgeSuffix})"
    Rank.JACK -> "${strings.rankJack} ${suit.getLocalizedName(strings)} (4${strings.pointsBadgeSuffix})"
    Rank.TEN -> "10 ${suit.getLocalizedName(strings)} (10${strings.pointsBadgeSuffix})"
    else -> "${rank.label} ${suit.getLocalizedName(strings)}"
}

fun Player.getDisplayName(strings: LocalizedStrings): String {
    if (this.isRemoteFriend) return this.name
    if (this.isHuman || this.id == 0 || this.name == "أنت" || this.name.equals("You", ignoreCase = true)) {
        return strings.youLabel
    }
    return when (this.id) {
        0 -> strings.youLabel
        1 -> when {
            strings.youLabel == "You" -> "Sarah"
            strings.youLabel == "Vous" -> "Sarah"
            strings.youLabel == "Tú" -> "Sara"
            strings.youLabel == "Sen" -> "Sare"
            strings.youLabel == "آپ" -> "سارہ"
            strings.youLabel == "Вы" -> "Сара"
            else -> "سارة"
        }
        2 -> when {
            strings.youLabel == "You" -> "Fahad"
            strings.youLabel == "Vous" -> "Fahad"
            strings.youLabel == "Tú" -> "Fahad"
            strings.youLabel == "Sen" -> "Fahad"
            strings.youLabel == "آپ" -> "فہد"
            strings.youLabel == "Вы" -> "Фахад"
            else -> "فهد"
        }
        3 -> when {
            strings.youLabel == "You" -> "Noura"
            strings.youLabel == "Vous" -> "Noura"
            strings.youLabel == "Tú" -> "Nora"
            strings.youLabel == "Sen" -> "Nura"
            strings.youLabel == "آپ" -> "نورہ"
            strings.youLabel == "Вы" -> "Нура"
            else -> "نورة"
        }
        4 -> when {
            strings.youLabel == "You" -> "Omar"
            strings.youLabel == "Vous" -> "Omar"
            strings.youLabel == "Tú" -> "Omar"
            strings.youLabel == "Sen" -> "Ömer"
            strings.youLabel == "آپ" -> "عمر"
            strings.youLabel == "Вы" -> "Омар"
            else -> "عمر"
        }
        else -> this.name
    }
}

fun LobbyPlayer.getDisplayName(strings: LocalizedStrings): String {
    if (this.isHost || this.seatId == 0) return "${strings.youLabel} (${strings.hostBadge})"
    if (this.name == "بانتظار صديق..." || this.name.contains("بانتظار") || this.name.contains("Waiting")) {
        return strings.bluetoothWaitingForHost
    }
    return when (this.seatId) {
        1 -> when {
            strings.youLabel == "You" -> "Sarah"
            strings.youLabel == "Vous" -> "Sarah"
            strings.youLabel == "Tú" -> "Sara"
            strings.youLabel == "Sen" -> "Sare"
            strings.youLabel == "آپ" -> "سارہ"
            strings.youLabel == "Вы" -> "Сара"
            else -> "سارة"
        }
        2 -> when {
            strings.youLabel == "You" -> "Fahad"
            strings.youLabel == "Vous" -> "Fahad"
            strings.youLabel == "Tú" -> "Fahad"
            strings.youLabel == "Sen" -> "Fahad"
            strings.youLabel == "آپ" -> "فہد"
            strings.youLabel == "Вы" -> "Фахад"
            else -> "فهد"
        }
        3 -> when {
            strings.youLabel == "You" -> "Noura"
            strings.youLabel == "Vous" -> "Noura"
            strings.youLabel == "Tú" -> "Nora"
            strings.youLabel == "Sen" -> "Nura"
            strings.youLabel == "آپ" -> "نورہ"
            strings.youLabel == "Вы" -> "Нура"
            else -> "نورة"
        }
        4 -> when {
            strings.youLabel == "You" -> "Omar"
            strings.youLabel == "Vous" -> "Omar"
            strings.youLabel == "Tú" -> "Omar"
            strings.youLabel == "Sen" -> "Ömer"
            strings.youLabel == "آپ" -> "عمر"
            strings.youLabel == "Вы" -> "Омар"
            else -> "عمر"
        }
        else -> this.name
    }
}

