package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.audio.HapticManager
import com.example.profile.AchievementManager
import com.example.settings.CardBackTheme
import com.example.settings.GameSettingsManager
import com.example.settings.GameSpeed
import com.example.settings.TableTheme
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary

@Composable
fun GameSettingsDialog(
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val settingsManager = remember { GameSettingsManager.getInstance(context) }
    val hapticManager = remember { HapticManager.getInstance(context) }

    val currentTableTheme by settingsManager.tableTheme.collectAsState()
    val currentCardBack by settingsManager.cardBackTheme.collectAsState()
    val currentGameSpeed by settingsManager.gameSpeed.collectAsState()
    val hapticEnabled by settingsManager.hapticEnabled.collectAsState()
    val cardGlowEnabled by settingsManager.cardGlowHighlight.collectAsState()
    val autoPlaySingle by settingsManager.autoPlaySingleLegal.collectAsState()
    val sfxVolume by settingsManager.sfxVolume.collectAsState()
    val turnTimerSec by settingsManager.turnTimerSeconds.collectAsState()

    val playerXp by AchievementManager.playerXp.collectAsState()
    val achievements by AchievementManager.achievements.collectAsState()
    val vipTier = AchievementManager.getVipTier(playerXp)
    val playerLevel = AchievementManager.getLevel(playerXp)
    val (inLevelXp, neededXp) = AchievementManager.getXpForNextLevel(playerXp)

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabTitles = listOf("المظهر", "اللعب", "الصوت", "VIP 👑")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = modifier
                .fillMaxWidth(0.95f)
                .heightIn(max = 680.dp)
                .padding(horizontal = 8.dp, vertical = 12.dp)
                .testTag("game_settings_dialog"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF101B22)),
            border = BorderStroke(1.8.dp, GoldPrimary),
            elevation = CardDefaults.cardElevation(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF1A2A33), Color(0xFF0F171C), Color(0xFF080D10))
                        )
                    )
            ) {
                // ترويسة نافذة الخصائص العالمية
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "⚙️", fontSize = 22.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "خصائص وإعدادات اللعبة العالمية",
                                color = GoldPrimary,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "تخصيص الكازينو، وتيرة اللعب، والتفاعل الحسي",
                                color = Color(0xFFB0BEC5),
                                fontSize = 11.sp
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(34.dp)
                            .background(Color(0x33FFFFFF), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = GoldLight,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // شريط التبويبات الفاخر
                TabRow(
                    selectedTabIndex = selectedTabIndex,
                    containerColor = Color(0xFF0B1216),
                    contentColor = GoldPrimary,
                    indicator = { tabPositions ->
                        TabRowDefaults.Indicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                            color = GoldPrimary,
                            height = 3.dp
                        )
                    }
                ) {
                    tabTitles.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTabIndex == index,
                            onClick = {
                                selectedTabIndex = index
                                hapticManager.tapLight()
                            },
                            text = {
                                Text(
                                    text = title,
                                    fontSize = 13.sp,
                                    fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Medium,
                                    color = if (selectedTabIndex == index) GoldPrimary else Color.White.copy(alpha = 0.65f)
                                )
                            }
                        )
                    }
                }

                // محتوى التبويبات
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    when (selectedTabIndex) {
                        0 -> ThemeSettingsTab(
                            currentTable = currentTableTheme,
                            onSelectTable = {
                                settingsManager.setTableTheme(it)
                                hapticManager.tapMedium()
                            },
                            currentCardBack = currentCardBack,
                            onSelectCardBack = {
                                settingsManager.setCardBackTheme(it)
                                hapticManager.tapMedium()
                            }
                        )
                        1 -> GameplaySettingsTab(
                            currentSpeed = currentGameSpeed,
                            onSelectSpeed = {
                                settingsManager.setGameSpeed(it)
                                hapticManager.tapMedium()
                            },
                            autoPlaySingle = autoPlaySingle,
                            onToggleAutoPlay = {
                                settingsManager.setAutoPlaySingleLegal(it)
                                hapticManager.tapLight()
                            },
                            cardGlow = cardGlowEnabled,
                            onToggleCardGlow = {
                                settingsManager.setCardGlowHighlight(it)
                                hapticManager.tapLight()
                            },
                            turnTimerSec = turnTimerSec,
                            onSelectTimer = {
                                settingsManager.setTurnTimerSeconds(it)
                                hapticManager.tapLight()
                            }
                        )
                        2 -> AudioHapticsTab(
                            sfxVolume = sfxVolume,
                            onVolumeChange = {
                                settingsManager.setSfxVolume(it)
                            },
                            hapticEnabled = hapticEnabled,
                            onToggleHaptic = {
                                settingsManager.setHapticEnabled(it)
                                hapticManager.isHapticEnabled = it
                                if (it) hapticManager.tapMedium()
                            }
                        )
                        3 -> VipAchievementsTab(
                            playerXp = playerXp,
                            playerLevel = playerLevel,
                            vipTier = vipTier,
                            inLevelXp = inLevelXp,
                            neededXp = neededXp,
                            achievements = achievements
                        )
                    }
                }
            }
        }
    }
}

/**
 * تبويب المظهر وسمات الكازينو
 */
@Composable
private fun ThemeSettingsTab(
    currentTable: TableTheme,
    onSelectTable: (TableTheme) -> Unit,
    currentCardBack: CardBackTheme,
    onSelectCardBack: (CardBackTheme) -> Unit
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text(
                text = "🎨 مخمل طاولة اللعب (Casino Felt)",
                color = GoldLight,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "اختر لون الطاولة الملكية المفضل لديك:",
                color = Color.LightGray,
                fontSize = 11.5.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        items(TableTheme.entries) { theme ->
            val isSelected = theme == currentTable
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectTable(theme) },
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(
                    if (isSelected) 2.dp else 1.dp,
                    if (isSelected) GoldPrimary else Color.White.copy(alpha = 0.15f)
                ),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131D24))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // دائرة عينة اللون
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Brush.radialGradient(theme.gradientColors))
                                .border(BorderStroke(1.5.dp, theme.rimColor), CircleShape)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = theme.titleArabic,
                                color = Color.White,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = theme.titleEnglish,
                                color = Color.Gray,
                                fontSize = 10.5.sp
                            )
                        }
                    }

                    if (isSelected) {
                        Surface(
                            shape = CircleShape,
                            color = GoldPrimary,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Selected",
                                tint = Color.Black,
                                modifier = Modifier.padding(3.dp)
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "🃏 تصميم ظهر الورقة الملكي (Card Back)",
                color = GoldLight,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "نقوش كازينو فاخرة مستوحاة من أوراق اللعب الملكية:",
                color = Color.LightGray,
                fontSize = 11.5.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        items(CardBackTheme.entries) { back ->
            val isSelected = back == currentCardBack
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectCardBack(back) },
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(
                    if (isSelected) 2.dp else 1.dp,
                    if (isSelected) GoldPrimary else Color.White.copy(alpha = 0.15f)
                ),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131D24))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // بطاقة صغيرة تمثل ظهر الورقة
                        Box(
                            modifier = Modifier
                                .width(30.dp)
                                .height(42.dp)
                                .clip(RoundedCornerShape(5.dp))
                                .background(Brush.radialGradient(back.gradientColors))
                                .border(BorderStroke(1.2.dp, back.borderColor), RoundedCornerShape(5.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "✦", color = back.emblemColor, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = back.titleArabic,
                                color = Color.White,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = back.titleEnglish,
                                color = Color.Gray,
                                fontSize = 10.5.sp
                            )
                        }
                    }

                    if (isSelected) {
                        Surface(
                            shape = CircleShape,
                            color = GoldPrimary,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Selected",
                                tint = Color.Black,
                                modifier = Modifier.padding(3.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * تبويب أسلوب ووتيرة اللعب
 */
@Composable
private fun GameplaySettingsTab(
    currentSpeed: GameSpeed,
    onSelectSpeed: (GameSpeed) -> Unit,
    autoPlaySingle: Boolean,
    onToggleAutoPlay: (Boolean) -> Unit,
    cardGlow: Boolean,
    onToggleCardGlow: (Boolean) -> Unit,
    turnTimerSec: Int,
    onSelectTimer: (Int) -> Unit
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // بطاقة ذكاء الكمبيوتر الخارق الأقصى
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF162530)),
                border = BorderStroke(1.5.dp, GoldPrimary)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "🧠", fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "ذكاء الروبوتات والكمبيوتر (AI Intelligence)",
                                    color = GoldPrimary,
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "مستوى التحدي: الخارق الأقصى (Grandmaster 👑)",
                                    color = Color(0xFFFFD54F),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = GoldDark.copy(alpha = 0.4f),
                            border = BorderStroke(1.dp, GoldPrimary)
                        ) {
                            Text(
                                text = "مفعّل للأقصى ⚡",
                                color = GoldLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "محرك تكتيكي متطور: حساب الأمل الرياضي للمزاد، سحب تراب الخصوم، تشحيم أكلات الزملاء، حماية العشرات وتجويع المشتري، مع تتبع كامل لأسياد الفئات الـ 40.",
                        color = Color(0xFFCFD8DC),
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("سحب الترب 🌪️", "تشحيم الأكلات 🍯", "تجويع المشتري 🛡️", "حماية العشرات 💎").forEach { tag ->
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color(0x33000000),
                                border = BorderStroke(0.6.dp, GoldPrimary.copy(alpha = 0.5f))
                            ) {
                                Text(
                                    text = tag,
                                    color = Color.White,
                                    fontSize = 9.5.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "⚡ سرعة وتيرة اللعب (Game Speed)",
                color = GoldLight,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "تحكم في سرعة تفكير ولعب الروبوتات والأنيميشن:",
                color = Color.LightGray,
                fontSize = 11.5.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                GameSpeed.entries.forEach { speed ->
                    val isSelected = speed == currentSpeed
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onSelectSpeed(speed) },
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) GoldDark.copy(alpha = 0.5f) else Color(0xFF131D24)
                        ),
                        border = BorderStroke(
                            if (isSelected) 1.8.dp else 0.8.dp,
                            if (isSelected) GoldPrimary else Color.White.copy(alpha = 0.2f)
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp, horizontal = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = speed.speedMultiplier,
                                color = if (isSelected) GoldPrimary else Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = speed.titleArabic,
                                color = if (isSelected) Color.White else Color.Gray,
                                fontSize = 10.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(4.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131D24)),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "🃏 اللعب التلقائي للورقة الإجبارية",
                            color = Color.White,
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "إذا لم يكن لديك سوى ورقة قانونية وحيدة، يتم لعبها فورياً دون انتظار لمسك للشاشة",
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = autoPlaySingle,
                        onCheckedChange = onToggleAutoPlay,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = GoldPrimary,
                            checkedTrackColor = GoldDark
                        )
                    )
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131D24)),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "✨ إبراز وتوهج الأوراق القابلة للعب",
                            color = Color.White,
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "تظليل ولمعان الأوراق المسموح لعبها قانونياً في الأكلة لتسهيل القراءة السريعة",
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = cardGlow,
                        onCheckedChange = onToggleCardGlow,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = GoldPrimary,
                            checkedTrackColor = GoldDark
                        )
                    )
                }
            }
        }

        item {
            Text(
                text = "⏳ عداد وقت الدور (Turn Timer)",
                color = GoldLight,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(10, 15, 25).forEach { sec ->
                    val isSel = sec == turnTimerSec
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onSelectTimer(sec) },
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSel) GoldDark.copy(alpha = 0.5f) else Color(0xFF131D24)
                        ),
                        border = BorderStroke(
                            if (isSel) 1.8.dp else 0.8.dp,
                            if (isSel) GoldPrimary else Color.White.copy(alpha = 0.2f)
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "$sec ثانية",
                                color = if (isSel) GoldPrimary else Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * تبويب الصوت والتفاعل اللمسي (Haptic Feedback)
 */
@Composable
private fun AudioHapticsTab(
    sfxVolume: Float,
    onVolumeChange: (Float) -> Unit,
    hapticEnabled: Boolean,
    onToggleHaptic: (Boolean) -> Unit
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF131D24)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "SFX",
                            tint = GoldPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "مستوى المؤثرات الصوتية (SFX)",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "${(sfxVolume * 100).toInt()}%",
                        color = GoldLight,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Slider(
                    value = sfxVolume,
                    onValueChange = onVolumeChange,
                    valueRange = 0f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = GoldPrimary,
                        activeTrackColor = GoldLight,
                        inactiveTrackColor = Color.DarkGray
                    )
                )
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF131D24)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Vibration,
                        contentDescription = "Haptic",
                        tint = GoldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "التفاعل اللمسي والاهتزاز (Haptics)",
                            color = Color.White,
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "اهتزازات فيزيائية ممتعة عند رمي الورقة، رفع المزاد، وفوز الأكلة كالألعاب العالمية",
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                    }
                }
                Switch(
                    checked = hapticEnabled,
                    onCheckedChange = onToggleHaptic,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = GoldPrimary,
                        checkedTrackColor = GoldDark
                    )
                )
            }
        }
    }
}

/**
 * تبويب إنجازات ومستوى VIP
 */
@Composable
private fun VipAchievementsTab(
    playerXp: Int,
    playerLevel: Int,
    vipTier: com.example.profile.VipTier,
    inLevelXp: Int,
    neededXp: Int,
    achievements: List<com.example.profile.Achievement>
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            // كارت رتبة الـ VIP ومستوى اللاعب
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1B262C)),
                border = BorderStroke(1.5.dp, GoldPrimary)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = vipTier.badge, fontSize = 28.sp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = vipTier.titleArabic,
                                    color = GoldPrimary,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "المستوى $playerLevel • $playerXp XP",
                                    color = Color.LightGray,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = GoldDark,
                            border = BorderStroke(0.6.dp, GoldLight)
                        ) {
                            Text(
                                text = "VIP LVL $playerLevel",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = { (inLevelXp.toFloat() / neededXp.toFloat()).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = GoldPrimary,
                        trackColor = Color(0xFF333333)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "$inLevelXp / $neededXp XP للمستوى التالي",
                        color = Color.Gray,
                        fontSize = 10.5.sp,
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "🏆 إنجازات وبطولات الترب",
                color = GoldLight,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
        }

        items(achievements) { ach ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (ach.isUnlocked) Color(0xFF12281D) else Color(0xFF131D24)
                ),
                border = BorderStroke(
                    if (ach.isUnlocked) 1.2.dp else 0.8.dp,
                    if (ach.isUnlocked) Color(0xFF4CAF50) else Color.White.copy(alpha = 0.15f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = ach.icon, fontSize = 24.sp)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = ach.titleArabic,
                                color = if (ach.isUnlocked) Color(0xFF81C784) else Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (ach.isUnlocked) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "✓ تم الإنجاز", color = Color(0xFF81C784), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text(
                            text = ach.descArabic,
                            color = Color.Gray,
                            fontSize = 10.5.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { (ach.currentProgress.toFloat() / ach.maxProgress.toFloat()).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(5.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = if (ach.isUnlocked) Color(0xFF4CAF50) else GoldLight,
                            trackColor = Color(0xFF2A2A2A)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0x33FFD700),
                        border = BorderStroke(0.6.dp, GoldLight)
                    ) {
                        Text(
                            text = "+${ach.xpReward} XP",
                            color = GoldLight,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}
