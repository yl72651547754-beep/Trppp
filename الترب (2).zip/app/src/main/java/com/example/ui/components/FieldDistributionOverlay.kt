package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.LocalizationManager
import com.example.model.Card
import com.example.model.GameUIState
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CardIvory
import com.example.ui.theme.DangerRed
import com.example.ui.theme.FeltGreenDark
import com.example.ui.theme.FeltGreenMedium
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceCardContainer
import com.example.ui.theme.SurfaceDarkNavy

@Composable
fun FieldDistributionOverlay(
    uiState: GameUIState,
    onSelectCard: (Card) -> Unit,
    onAssignToPlayer: (Int) -> Unit,
    onUnassignPlayer: (Int) -> Unit,
    onConfirm: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalizationManager.strings.collectAsState().value
    val isBuyerHuman = uiState.buyer?.isHuman == true
    val assignedCount = uiState.fieldAssignments.size
    val allAssigned = assignedCount == 5

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp)
            .testTag("field_distribution_overlay"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDarkNavy.copy(alpha = 0.96f)),
        border = BorderStroke(2.dp, GoldPrimary),
        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // شريط العنوان
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Stars,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = strings.fieldDistributionTitle,
                        color = GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (allAssigned) SuccessGreen.copy(alpha = 0.2f) else GoldDark.copy(alpha = 0.3f),
                    border = BorderStroke(1.dp, if (allAssigned) SuccessGreen else GoldPrimary)
                ) {
                    Text(
                        text = "$assignedCount / 5",
                        color = if (allAssigned) SuccessGreen else GoldLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = if (isBuyerHuman) {
                    strings.fieldDistrInstruction
                } else {
                    String.format(strings.buyerDistributingField, uiState.buyer?.name ?: "")
                },
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            // قسم أوراق المشتري الـ12 المتاحة للاختيار (التي لم تُوزع بعد)
            if (isBuyerHuman) {
                Text(
                    text = String.format(strings.cardRemaining, uiState.unassignedFieldCards.size),
                    color = AmberAccent,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                if (uiState.unassignedFieldCards.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(80.dp)
                            .background(FeltGreenDark, RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = strings.confirmDistribution,
                            color = SuccessGreen,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                } else {
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
                    ) {
                        items(uiState.unassignedFieldCards) { card ->
                            val isSelected = uiState.selectedCardForDistribution?.id == card.id
                            PlayingCardView(
                                card = card,
                                width = 58.dp,
                                height = 86.dp,
                                isSelected = isSelected,
                                onClick = { onSelectCard(card) }
                            )
                        }
                    }
                }

                if (uiState.selectedCardForDistribution != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowDownward,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${strings.tapToAssign}: ${uiState.selectedCardForDistribution.displayTitleArabic}",
                            color = GoldLight,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // قسم اللاعبين الخمسة والورقة المخصصة لكل لاعب
            Text(
                text = strings.fieldDistributionDesc,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                uiState.players.forEach { player ->
                    val assignedCard = uiState.fieldAssignments[player.id]
                    val isTargeted = uiState.selectedCardForDistribution != null && assignedCard == null

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = if (isTargeted) GoldDark.copy(alpha = 0.25f) else FeltGreenDark,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .border(
                                width = if (isTargeted) 1.5.dp else 1.dp,
                                color = if (isTargeted) GoldPrimary else Color.White.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable(enabled = isBuyerHuman) {
                                if (uiState.selectedCardForDistribution != null) {
                                    onAssignToPlayer(player.id)
                                }
                            }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                            .testTag("player_slot_${player.id}"),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // معلومات اللاعب
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(
                                        if (player.isHuman) GoldPrimary else FeltGreenMedium,
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = if (player.isHuman) Color.Black else Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = if (player.isHuman) "${player.name} (${strings.youLabel})" else player.name,
                                    color = if (player.isHuman) GoldLight else Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = if (player.id == uiState.buyerId) strings.buyerBadge else "•",
                                    color = AmberAccent,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // الورقة المخصصة
                        if (assignedCard != null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                PlayingCardView(
                                    card = assignedCard,
                                    width = 46.dp,
                                    height = 64.dp,
                                    showPointsBadge = true,
                                    onClick = if (isBuyerHuman) {
                                        { onUnassignPlayer(player.id) }
                                    } else null
                                )
                                if (isBuyerHuman) {
                                    IconButton(
                                        onClick = { onUnassignPlayer(player.id) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = strings.closeButton,
                                            tint = DangerRed,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        } else {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color.White.copy(alpha = 0.05f),
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                                modifier = Modifier.height(48.dp)
                            ) {
                                Box(
                                    modifier = Modifier.padding(horizontal = 12.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (isBuyerHuman) {
                                            if (uiState.selectedCardForDistribution != null) strings.tapToAssign else "---"
                                        } else strings.waitingOthersBids,
                                        color = if (isTargeted) GoldLight else Color.White.copy(alpha = 0.5f),
                                        fontSize = 12.sp,
                                        fontWeight = if (isTargeted) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // زر تأكيد التوزيع
            if (isBuyerHuman) {
                Button(
                    onClick = onConfirm,
                    enabled = allAssigned,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("confirm_distribution_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GoldPrimary,
                        contentColor = Color.Black,
                        disabledContainerColor = Color.White.copy(alpha = 0.1f),
                        disabledContentColor = Color.White.copy(alpha = 0.3f)
                    )
                ) {
                    Icon(imageVector = Icons.Default.Check, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (allAssigned) strings.confirmAndContinue else "$assignedCount / 5",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}
