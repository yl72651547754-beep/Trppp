package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Felt Table Emerald & Dark Woods
val FeltGreenDark = Color(0xFF092E1A)
val FeltGreenMedium = Color(0xFF0E4327)
val FeltGreenLight = Color(0xFF165B36)
val FeltFaded = Color(0xFF1E6F43)

// Luxury Accents
val GoldPrimary = Color(0xFFD4AF37)
val GoldLight = Color(0xFFFFE885)
val GoldDark = Color(0xFF997A15)
val AmberAccent = Color(0xFFFFB300)

// Card & Suits
val CardIvory = Color(0xFFFCFAF4)
val SuitRed = Color(0xFFD32F2F)
val SuitBlack = Color(0xFF1E1E1E)
val JokerViolet = Color(0xFF6A1B9A)

// Surfaces & Backgrounds
val SurfaceDarkNavy = Color(0xFF0D1B1E)
val SurfaceCardContainer = Color(0xFF122C24)
val SurfaceOverlay = Color(0xE60A1D16)

// Alerts & States
val SuccessGreen = Color(0xFF4CAF50)
val DangerRed = Color(0xFFEF5350)
val InfoCyan = Color(0xFF26C6DA)
