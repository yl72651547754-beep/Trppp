package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.LocalizationManager
import com.example.model.GameUIState
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CardIvory
import com.example.ui.theme.DangerRed
import com.example.ui.theme.FeltGreenDark
import com.example.ui.theme.FeltGreenMedium
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceCardContainer

@Composable
fun AuctionControls(
    uiState: GameUIState,
    onBid: (Int) -> Unit,
    onPass: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalizationManager.strings.collectAsState().value
    val currentBid = uiState.currentAuctionBid
    val localSeat = uiState.localPlayerSeatId
    val localPlayer = uiState.players.find { it.id == localSeat } ?: uiState.humanPlayer
    val isLocalTurn = uiState.currentTurnPlayerId == localSeat
    val localPassed = localPlayer?.hasPassedAuction == true
    val isLocalExempt = localPlayer?.isExemptFromAuction == true
    val isCappedAt187 = currentBid >= 187

    var proposedBid by remember(currentBid) {
        mutableIntStateOf(minOf(currentBid + 10, 187))
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 2.dp)
            .testTag("auction_controls_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCardContainer),
        border = BorderStroke(1.5.dp, GoldPrimary),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // شريط العنوان وحالة المزاد
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Gavel,
                        contentDescription = strings.auctionTitle,
                        tint = GoldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = strings.auctionTitleWithGavel,
                        color = GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isCappedAt187) DangerRed.copy(alpha = 0.2f) else GoldDark.copy(alpha = 0.3f),
                    border = BorderStroke(1.dp, if (isCappedAt187) DangerRed else GoldPrimary)
                ) {
                    Text(
                        text = if (isCappedAt187) strings.maxBidReached else "${strings.bidCapLabel}: 187",
                        color = if (isCappedAt187) DangerRed else GoldLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // عداد السعر الحالي
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(FeltGreenDark, RoundedCornerShape(10.dp))
                    .padding(vertical = 6.dp, horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = strings.currentBidLabel,
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 11.sp
                    )
                    val highestBidder = uiState.players.find { it.id == uiState.highestBidderId }
                    Text(
                        text = if (highestBidder != null) "${strings.highestBidder}: ${highestBidder.name}" else strings.waitingBids,
                        color = AmberAccent,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Text(
                    text = "$currentBid",
                    color = GoldLight,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.testTag("current_bid_text")
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            if (isLocalTurn && !localPassed && !isLocalExempt && !isCappedAt187) {
                // التحكم في الرفع لللاعب المحلي
                // عداد الرفع التفاعلي (+ / -)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            if (proposedBid > currentBid + 1) proposedBid -= 5
                        },
                        enabled = proposedBid > currentBid + 1,
                        modifier = Modifier
                            .size(36.dp)
                            .background(FeltGreenMedium, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Remove,
                            contentDescription = "-",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = FeltGreenDark,
                        border = BorderStroke(1.5.dp, GoldPrimary),
                        modifier = Modifier.width(95.dp)
                    ) {
                        Text(
                            text = "$proposedBid",
                            color = GoldLight,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    IconButton(
                        onClick = {
                            if (proposedBid < 187) proposedBid = minOf(proposedBid + 5, 187)
                        },
                        enabled = proposedBid < 187,
                        modifier = Modifier
                            .size(36.dp)
                            .background(FeltGreenMedium, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "+",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // أزرار الزيادة السريعة (+5، +10، السقف 187)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilledTonalButton(
                        onClick = { proposedBid = minOf(currentBid + 5, 187) },
                        modifier = Modifier.weight(1f).height(34.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = FeltGreenMedium)
                    ) {
                        Text("+5", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    FilledTonalButton(
                        onClick = { proposedBid = minOf(currentBid + 10, 187) },
                        modifier = Modifier.weight(1f).height(34.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = FeltGreenMedium)
                    ) {
                        Text("+10", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    FilledTonalButton(
                        onClick = { proposedBid = minOf(currentBid + 25, 187) },
                        modifier = Modifier.weight(1f).height(34.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = FeltGreenMedium)
                    ) {
                        Text("+25", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    FilledTonalButton(
                        onClick = { proposedBid = 187 },
                        modifier = Modifier.weight(1.3f).height(34.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = GoldDark)
                    ) {
                        Text(strings.bidBuyDirectAction, color = GoldLight, fontSize = 10.sp, fontWeight = FontWeight.Black)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // زر الرفع وزر الباص
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onPass,
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp)
                            .testTag("pass_button"),
                        border = BorderStroke(1.5.dp, DangerRed),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed)
                    ) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = strings.bidPass, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }

                    Button(
                        onClick = { onBid(proposedBid) },
                        enabled = proposedBid > currentBid && !isCappedAt187,
                        modifier = Modifier
                            .weight(1.4f)
                            .height(42.dp)
                            .testTag("raise_bid_button"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GoldPrimary,
                            contentColor = Color.Black
                        )
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = String.format(strings.raiseCustomBid, proposedBid),
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                // ليس دور اللاعب المحلي، أو معفى بكرتين حمر، أو تم قفل الرفع بسبب السقف 187
                val statusText = when {
                    isLocalExempt -> strings.exemptFromAuctionBanner
                    isCappedAt187 -> strings.maxBidReached
                    localPassed -> strings.passedAlready
                    uiState.isAiThinking -> strings.waitingOthersBids
                    else -> String.format(strings.aiThinking, uiState.players.find { it.id == uiState.currentTurnPlayerId }?.name ?: "")
                }

                Text(
                    text = statusText,
                    color = if (isLocalExempt) GoldLight else if (isCappedAt187) DangerRed else AmberAccent,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }
        }
    }
}
