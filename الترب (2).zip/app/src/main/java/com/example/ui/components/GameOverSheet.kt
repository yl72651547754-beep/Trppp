package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SentimentDissatisfied
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.localization.LocalizationManager
import com.example.localization.getDisplayName
import com.example.model.GameUIState
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.DangerRed
import com.example.ui.theme.FeltGreenDark
import com.example.ui.theme.FeltGreenMedium
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuitRed
import com.example.ui.theme.SurfaceDarkNavy

@Composable
fun GameOverSheet(
    uiState: GameUIState,
    onRestart: () -> Unit
) {
    val strings by LocalizationManager.strings.collectAsState()
    val buyer = uiState.buyer ?: uiState.players.first()
    val isBuyerWon = uiState.isBuyerWinner
    val opponentsPts = uiState.opponentsTotalPoints
    val winningBid = uiState.winningBid
    val totalSum = uiState.goldenSum

    Dialog(onDismissRequest = onRestart) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("game_over_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDarkNavy),
            border = BorderStroke(2.dp, if (isBuyerWon) GoldPrimary else DangerRed),
            elevation = CardDefaults.cardElevation(defaultElevation = 20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // أيقونة الفوز أو الخسارة
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .background(
                            brush = Brush.radialGradient(
                                colors = if (isBuyerWon) {
                                    listOf(GoldLight, GoldDark)
                                } else {
                                    listOf(DangerRed, Color(0xFF8B0000))
                                }
                            ),
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isBuyerWon) Icons.Default.EmojiEvents else Icons.Default.SentimentDissatisfied,
                        contentDescription = null,
                        tint = if (isBuyerWon) Color.Black else Color.White,
                        modifier = Modifier.size(38.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                val buyerDisplayName = buyer.getDisplayName(strings)
                val roundAwardText = if (isBuyerWon) {
                    String.format(strings.redCardAwarded, buyerDisplayName)
                } else {
                    String.format(strings.blackCardAwarded, buyerDisplayName)
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isBuyerWon) SuccessGreen.copy(alpha = 0.2f) else DangerRed.copy(alpha = 0.2f),
                    border = BorderStroke(1.dp, if (isBuyerWon) SuccessGreen else DangerRed)
                ) {
                    Text(
                        text = roundAwardText,
                        color = if (isBuyerWon) GoldLight else Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (uiState.isMatchOver) {
                        strings.matchOverFivePlayers
                    } else if (isBuyerWon) {
                        String.format(strings.buyerWonRound, buyerDisplayName)
                    } else {
                        String.format(strings.buyerLostRound, buyerDisplayName)
                    },
                    color = if (uiState.isMatchOver) DangerRed else if (isBuyerWon) GoldLight else DangerRed,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = when {
                        uiState.isMatchOver -> strings.matchOverExplanation
                        isBuyerWon -> strings.buyerSuccessExplanation
                        else -> strings.buyerFailExplanation
                    },
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )

                // إعلان خاص بالخاسر والفائزين عند نهاية اللعبة أو الفوز بكرتين حمر
                val loserPlayer = uiState.players.find { it.blackCards >= 2 }
                val exemptPlayers = uiState.players.filter { it.redCards >= 2 }

                if (uiState.isMatchOver && loserPlayer != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = DangerRed.copy(alpha = 0.2f),
                        border = BorderStroke(1.dp, DangerRed)
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = String.format(strings.matchLoserCardBanner, loserPlayer.getDisplayName(strings)),
                                color = DangerRed,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                            if (exemptPlayers.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                val winnersNames = exemptPlayers.joinToString { it.getDisplayName(strings) }
                                Text(
                                    text = String.format(strings.matchWinnersCardBanner, winnersNames),
                                    color = GoldLight,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 11.5.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                } else if (!uiState.isMatchOver && buyer.redCards >= 2) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = SuccessGreen.copy(alpha = 0.2f),
                        border = BorderStroke(1.dp, SuccessGreen)
                    ) {
                        val buyerName = buyer.getDisplayName(strings)
                        Text(
                            text = String.format(strings.buyerTwoRedCardsExemptNotice, buyerName),
                            color = GoldLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // بطاقة المعادلة الذهبية
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = FeltGreenDark,
                    border = BorderStroke(1.5.dp, if (isBuyerWon) GoldPrimary else DangerRed)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = strings.goldenRuleEquationTitle,
                            color = GoldLight,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = strings.opponentsPointsLabel, color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp)
                                Text(text = "$opponentsPts", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            }

                            Text(text = "+", color = GoldLight, fontSize = 20.sp, fontWeight = FontWeight.Bold)

                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = strings.winningBidLabel, color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp)
                                Text(text = "$winningBid", color = GoldLight, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            }

                            Text(text = "=", color = GoldLight, fontSize = 20.sp, fontWeight = FontWeight.Bold)

                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = strings.goldenSumTotalLabel, color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp)
                                Text(
                                    text = "$totalSum",
                                    color = if (isBuyerWon) SuccessGreen else DangerRed,
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (isBuyerWon) SuccessGreen.copy(alpha = 0.2f) else DangerRed.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = if (totalSum <= 187) {
                                    "$totalSum ≤ 187 ✓"
                                } else {
                                    "$totalSum > 187 ✗"
                                },
                                color = if (isBuyerWon) SuccessGreen else DangerRed,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // جدول نقاط اللاعبين والكروت الحمر والسود
                Text(
                    text = strings.roundSummaryTitle,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(6.dp))

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    uiState.players.forEach { player ->
                        val isThisBuyer = player.id == uiState.buyerId
                        val isEliminated = player.isEliminated
                        val isExempt = player.isExemptFromAuction

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    if (isEliminated) DangerRed.copy(alpha = 0.25f)
                                    else if (isExempt) SuccessGreen.copy(alpha = 0.2f)
                                    else if (isThisBuyer) GoldDark.copy(alpha = 0.25f)
                                    else Color.White.copy(alpha = 0.05f),
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    val pName = player.getDisplayName(strings)
                                    Text(
                                        text = if (player.id == uiState.localPlayerSeatId) "$pName (${strings.youLabel})" else pName,
                                        color = if (isEliminated) DangerRed else if (isExempt) GoldLight else if (isThisBuyer) GoldLight else Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = if (isThisBuyer || isExempt || isEliminated) FontWeight.Bold else FontWeight.Normal
                                    )
                                    if (isThisBuyer) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = GoldPrimary
                                        ) {
                                            Text(
                                                text = strings.buyerBadge,
                                                color = Color.Black,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Black,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                    if (isExempt) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(text = strings.winnerBadge, fontSize = 10.sp, color = GoldLight, fontWeight = FontWeight.Bold)
                                    }
                                    if (isEliminated) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(text = strings.loserBadge, fontSize = 10.sp, color = DangerRed, fontWeight = FontWeight.Bold)
                                    }
                                }

                                // عرض رصيد الكروت الحمر والسود
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "🟥: ${if (player.redCards > 0) "🟥".repeat(player.redCards) else "0"}",
                                        fontSize = 10.sp,
                                        color = if (player.redCards > 0) SuitRed else Color.White.copy(alpha = 0.6f)
                                    )
                                    Text(
                                        text = "⬛: ${if (player.blackCards > 0) "⬛".repeat(player.blackCards) else "0"}",
                                        fontSize = 10.sp,
                                        color = if (player.blackCards > 0) Color.White else Color.White.copy(alpha = 0.6f)
                                    )
                                }
                            }

                            Text(
                                text = String.format(strings.pointsAndTricks, player.pointsWon, player.tricksWon),
                                color = if (isThisBuyer) GoldLight else Color.White.copy(alpha = 0.85f),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                val nextDealerId = (uiState.dealerPlayerId + 1) % 5
                val nextDealerName = uiState.players.find { it.id == nextDealerId }?.name ?: ""

                Button(
                    onClick = onRestart,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("play_again_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (uiState.isMatchOver) DangerRed else GoldPrimary,
                        contentColor = if (uiState.isMatchOver) Color.White else Color.Black
                    )
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (uiState.isMatchOver) {
                            strings.startNewGameButton
                        } else {
                            "${strings.startNextRoundButton} (${strings.dealerLabel}: $nextDealerName 🎴)"
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}
