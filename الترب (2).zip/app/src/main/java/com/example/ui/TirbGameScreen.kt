package com.example.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bluetooth.BluetoothGameManager
import com.example.bluetooth.BluetoothPermissionHelper
import com.example.bluetooth.ConnectionStatus
import com.example.localization.LocalizationManager
import com.example.localization.LocalizedStrings
import com.example.logic.TirbGameLogic
import com.example.model.GamePhase
import com.example.model.GameUIState
import com.example.model.Player
import com.example.model.TrickPlay
import com.example.profile.UserProfileDialog
import com.example.profile.UserProfileManager
import com.example.reaction.ActiveReaction
import com.example.reaction.ReactionManager
import com.example.ui.components.AuctionControls
import com.example.ui.components.BluetoothLobbyDialog
import com.example.ui.components.BluetoothQuickChatBar
import com.example.ui.components.CardBackView
import com.example.ui.components.EmojiReactionsBar
import com.example.ui.components.FieldDistributionOverlay
import com.example.ui.components.GameHistorySheet
import com.example.ui.components.GameOverSheet
import com.example.ui.components.GameSettingsDialog
import com.example.ui.components.LanguageSelectionDialog
import com.example.ui.components.PlayingCardView
import com.example.ui.components.RulesHelpSheet
import com.example.ui.components.ScoreBoardHeader
import com.example.ui.components.TrumpDeclarationDialog
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.DangerRed
import com.example.ui.theme.FeltFaded
import com.example.ui.theme.FeltGreenDark
import com.example.ui.theme.FeltGreenMedium
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuitRed
import com.example.ui.theme.SurfaceCardContainer
import com.example.ui.theme.SurfaceDarkNavy
import com.example.viewmodel.TirbViewModel

@Composable
fun TirbGameScreen(
    viewModel: TirbViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val historyList by viewModel.historyList.collectAsState()
    val isSoundEnabled by viewModel.isSoundEnabled.collectAsState()
    val strings = LocalizationManager.strings.collectAsState().value

    val bluetoothManager = remember { BluetoothGameManager(context) }
    val bluetoothStatus by bluetoothManager.status.collectAsState()

    val tableTheme by viewModel.settingsManager.tableTheme.collectAsState()
    val activeReactions by ReactionManager.activeReactions.collectAsState()
    val reactionMap = remember(activeReactions) { activeReactions.associateBy { it.playerId } }

    var showRulesDialog by remember { mutableStateOf(false) }
    var showHistoryDialog by remember { mutableStateOf(false) }
    var showLanguageDialog by remember { mutableStateOf(false) }
    var showBluetoothDialog by remember { mutableStateOf(false) }
    var showQuickChatBar by remember { mutableStateOf(false) }
    var showProfileDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showReactionsBar by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        UserProfileManager.init(context)
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        bluetoothManager.scanDevices()
    }

    LaunchedEffect(bluetoothManager) {
        viewModel.setBluetoothManager(bluetoothManager)
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("tirb_game_screen"),
        topBar = {
            ScoreBoardHeader(
                uiState = uiState,
                onOpenRules = { showRulesDialog = true },
                onOpenHistory = { showHistoryDialog = true },
                onOpenLanguage = { showLanguageDialog = true },
                onOpenBluetooth = { showBluetoothDialog = true },
                onOpenProfile = { showProfileDialog = true },
                isSoundEnabled = isSoundEnabled,
                onToggleSound = { viewModel.toggleSound() },
                onOpenSettings = { showSettingsDialog = true },
                onToggleReactions = { showReactionsBar = !showReactionsBar },
                isBluetoothConnected = bluetoothStatus == ConnectionStatus.CONNECTED,
                onOpenQuickChat = { showQuickChatBar = !showQuickChatBar }
            )
        },
        containerColor = tableTheme.primaryColor
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(
                    brush = Brush.radialGradient(
                        colors = tableTheme.gradientColors,
                        radius = 1200f
                    )
                )
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // قسم اللاعبين الخصوم الأربعة (في الأعلى والوسط)
                OpponentsArea(
                    players = uiState.players.filter { it.id != uiState.localPlayerSeatId },
                    currentTurnPlayerId = uiState.currentTurnPlayerId,
                    buyerId = uiState.buyerId,
                    dealerPlayerId = uiState.dealerPlayerId,
                    strings = strings,
                    activeReactions = reactionMap,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )

                // منطقة الميدان (وسط الطاولة: الأوراق غير المكشوفة أو الجولة الحالية)
                CenterTableField(
                    uiState = uiState,
                    strings = strings,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                )

                // في مرحلة التوزيع الأولي: شريط فحص الأوراق قبل المزاد
                if (uiState.phase == GamePhase.INITIAL_DEAL) {
                    InitialDealPreviewBar(
                        uiState = uiState,
                        onStartAuction = { viewModel.startAuction() },
                        strings = strings,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }

                // لوحة التحكم في المزاد (تظهر فوق يد اللاعب مباشرة دون حجب أوراقه)
                if (uiState.phase == GamePhase.AUCTION) {
                    AuctionControls(
                        uiState = uiState,
                        onBid = { amount -> viewModel.humanBid(amount) },
                        onPass = { viewModel.humanPass() },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // شريط التنبيهات والأحداث المباشرة (Ticker)
                GameLogTicker(
                    uiState = uiState,
                    strings = strings,
                    modifier = Modifier.fillMaxWidth()
                )

                // يد اللاعب البشري ومجال التحكم
                HumanPlayerArea(
                    uiState = uiState,
                    onCardClick = { card ->
                        if (uiState.phase == GamePhase.TRICK_PLAYING && uiState.currentTurnPlayerId == uiState.localPlayerSeatId) {
                            viewModel.playHumanCard(card)
                        }
                    },
                    strings = strings,
                    activeReaction = reactionMap[uiState.localPlayerSeatId],
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                )
            }

            // شريط اختيار المشاعر والتفاعلات الاجتماعية (Emoji Reactions Bar)
            EmojiReactionsBar(
                isVisible = showReactionsBar,
                onEmojiSelected = { emoji ->
                    ReactionManager.triggerReaction(uiState.localPlayerSeatId, emoji)
                    showReactionsBar = false
                },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 120.dp)
            )

            // نافذة التوزيع الإجباري لأوراق الميدان (تظهر في مرحلة توزيع الميدان)
            if (uiState.phase == GamePhase.FIELD_DISTRIBUTION && uiState.buyerId == uiState.localPlayerSeatId) {
                FieldDistributionOverlay(
                    uiState = uiState,
                    onSelectCard = { card -> viewModel.selectCardForDistribution(card) },
                    onAssignToPlayer = { playerId -> viewModel.assignSelectedCardToPlayer(playerId) },
                    onUnassignPlayer = { playerId -> viewModel.unassignPlayerCard(playerId) },
                    onConfirm = { viewModel.confirmHumanDistribution() },
                    modifier = Modifier.align(Alignment.Center)
                )
            }

            // نافذة التصريح الإلزامي بالترب
            if (uiState.phase == GamePhase.DECLARE_TRUMP && uiState.buyerId == uiState.localPlayerSeatId) {
                val myHand = uiState.players.find { it.id == uiState.localPlayerSeatId }?.hand ?: emptyList()
                TrumpDeclarationDialog(
                    hand = myHand,
                    onSelectTrump = { suit -> viewModel.declareTrump(suit) }
                )
            }

            // نافذة نهاية الجولة وحكم المعادلة الذهبية
            if (uiState.phase == GamePhase.GAME_OVER) {
                GameOverSheet(
                    uiState = uiState,
                    onRestart = { viewModel.startNewGame() }
                )
            }

            // نافذة القواعد
            if (showRulesDialog) {
                RulesHelpSheet(onDismiss = { showRulesDialog = false })
            }

            // نافذة السجل
            if (showHistoryDialog) {
                GameHistorySheet(
                    historyList = historyList,
                    onClearHistory = { viewModel.clearHistory() },
                    onDismiss = { showHistoryDialog = false }
                )
            }

            // نافذة اختيار اللغة (7 لغات)
            if (showLanguageDialog) {
                LanguageSelectionDialog(
                    currentLanguage = com.example.localization.LocalizationManager.currentLanguage.collectAsState().value,
                    onDismiss = { showLanguageDialog = false },
                    onLanguageSelected = { selected ->
                        com.example.localization.LocalizationManager.setLanguage(context, selected)
                        showLanguageDialog = false
                    }
                )
            }

            // نافذة غرف البلوتوث (Multiplayer Lobby)
            if (showBluetoothDialog) {
                BluetoothLobbyDialog(
                    bluetoothManager = bluetoothManager,
                    onDismiss = { showBluetoothDialog = false },
                    onRequestPermissions = {
                        permissionLauncher.launch(BluetoothPermissionHelper.getRequiredPermissions())
                    },
                    onStartGame = {
                        showBluetoothDialog = false
                        val deck = if (bluetoothManager.role.value == com.example.bluetooth.BluetoothRole.HOST) {
                            bluetoothManager.startHostingGame()
                        } else null
                        viewModel.startMultiplayerGame(
                            lobbyPlayers = bluetoothManager.lobbyPlayers.value,
                            mySeatId = bluetoothManager.mySeatId.value,
                            roomName = bluetoothManager.deviceName,
                            syncedDeck = deck
                        )
                    }
                )
            }

            // نافذة الملف الشخصي واسم المستخدم والـ ID
            if (showProfileDialog) {
                UserProfileDialog(onDismiss = { showProfileDialog = false })
            }

            // نافذة إعدادات وخصائص اللعبة العالمية (Themes, Haptics, Card Backs, Speed)
            if (showSettingsDialog) {
                GameSettingsDialog(
                    onDismiss = { showSettingsDialog = false }
                )
            }

            // شريط المحادثة السريعة أثناء اللعب
            BluetoothQuickChatBar(
                bluetoothManager = bluetoothManager,
                isOpen = showQuickChatBar,
                onClose = { showQuickChatBar = false },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 85.dp)
            )
        }
    }
}

/**
 * منطقة الخصوم الأربعة حول الطاولة
 */
@Composable
private fun OpponentsArea(
    players: List<Player>,
    currentTurnPlayerId: Int,
    buyerId: Int?,
    dealerPlayerId: Int,
    strings: LocalizedStrings,
    activeReactions: Map<Int, ActiveReaction> = emptyMap(),
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "opponents_turn_glow")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "turn_glow_alpha"
    )

    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        players.forEach { player ->
            val isCurrentTurn = player.id == currentTurnPlayerId
            val isBuyer = player.id == buyerId
            val isDealer = player.id == dealerPlayerId
            val reaction = activeReactions[player.id]

            Box(contentAlignment = Alignment.TopCenter) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isCurrentTurn) GoldDark.copy(alpha = 0.4f) else SurfaceCardContainer.copy(alpha = 0.88f)
                    ),
                    border = BorderStroke(
                        width = if (isCurrentTurn) 2.dp else if (isBuyer) 1.5.dp else 1.dp,
                        color = if (isCurrentTurn) GoldPrimary.copy(alpha = glowAlpha) else if (isBuyer) AmberAccent else Color.White.copy(alpha = 0.2f)
                    ),
                    modifier = Modifier
                        .width(82.dp)
                        .testTag("opponent_badge_${player.id}")
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 5.dp, horizontal = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        val opponentEmoji = when (player.name) {
                            "سارة" -> "🦅"
                            "فهد" -> "🦁"
                            "نورة" -> "🌟"
                            "كريم" -> "🛡️"
                            else -> if (!player.isHuman) "🤖" else "👑"
                        }

                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .border(
                                    width = if (isCurrentTurn) 2.dp else 0.dp,
                                    color = if (isCurrentTurn) GoldPrimary else Color.Transparent,
                                    shape = CircleShape
                                )
                                .background(
                                    if (isCurrentTurn) GoldPrimary.copy(alpha = 0.3f) else FeltGreenMedium,
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = opponentEmoji, fontSize = 15.sp)
                        }

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = player.name,
                            color = if (isCurrentTurn) GoldLight else Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )

                        if (!player.isHuman) {
                            Surface(
                                shape = RoundedCornerShape(3.dp),
                                color = FeltGreenDark
                            ) {
                                Text(
                                    text = if (LocalizationManager.currentLanguage.value.isRtl) "ذكاء" else "AI",
                                    color = Color(0xFF81C784),
                                    fontSize = 7.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 3.dp, vertical = 0.5.dp)
                                )
                            }
                        }

                        // شارة الموزع والمشتري
                        if (isDealer) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = GoldDark.copy(alpha = 0.4f)
                            ) {
                                Text(
                                    text = "🎴 ${strings.dealerBadge}",
                                    color = GoldLight,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp)
                                )
                            }
                        }

                        if (isBuyer) {
                            Text(
                                text = strings.buyerBadge,
                                color = AmberAccent,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black
                            )
                        } else if (player.isExemptFromAuction) {
                            Text(
                                text = strings.exemptBadge,
                                color = GoldLight,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                        } else if (player.isEliminated) {
                            Text(
                                text = "💀 ${strings.loserBadge}",
                                color = DangerRed,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                        } else if (player.hasPassedAuction) {
                            Text(
                                text = strings.bidPass,
                                color = DangerRed,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // رصيد الكروت الحمر والسود
                        if (player.redCards > 0 || player.blackCards > 0) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (player.redCards > 0) {
                                    Text(
                                        text = "🟥${player.redCards}",
                                        color = SuitRed,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                if (player.blackCards > 0) {
                                    Text(
                                        text = "⬛${player.blackCards}",
                                        color = Color.White,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        // عدد الأوراق والنقاط المأخوذة
                        Text(
                            text = String.format(strings.cardsCountAndPoints, player.hand.size, player.pointsWon),
                            color = Color.White.copy(alpha = 0.75f),
                            fontSize = 8.sp
                        )
                    }
                }

                // فقاعة التفاعل والمشاعر الاجتماعية العائمة فوق اللاعب
                if (reaction != null) {
                    Surface(
                        shape = CircleShape,
                        color = Color.Black.copy(alpha = 0.85f),
                        border = BorderStroke(1.2.dp, GoldLight),
                        modifier = Modifier
                            .offset(y = (-14).dp)
                            .shadow(6.dp, CircleShape)
                    ) {
                        Text(
                            text = reaction.emoji,
                            fontSize = 18.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * منطقة الميدان (منتصف الطاولة)
 */
@Composable
private fun CenterTableField(
    uiState: GameUIState,
    strings: LocalizedStrings,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        // حلقة طاولة اللعب التجميلية
        Box(
            modifier = Modifier
                .size(240.dp, 160.dp)
                .border(1.5.dp, GoldDark.copy(alpha = 0.3f), RoundedCornerShape(80.dp))
        )

        when (uiState.phase) {
            GamePhase.INITIAL_DEAL, GamePhase.AUCTION -> {
                // عرض الـ 5 ورق غير المكشوفة في الميدان (مقلوبة)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = FeltGreenDark.copy(alpha = 0.85f),
                        border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.6f))
                    ) {
                        Text(
                            text = strings.fieldCardsHiddenTitle,
                            color = GoldLight,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        repeat(5) {
                            CardBackView(
                                width = 54.dp,
                                height = 78.dp
                            )
                        }
                    }
                }
            }

            GamePhase.TRICK_PLAYING -> {
                // عرض أوراق الجولة الحالية (الشولة)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (uiState.currentTrickCards.isEmpty()) {
                        Text(
                            text = String.format(strings.waitingRoundStart, uiState.currentRound),
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 13.sp
                        )
                    } else {
                        // بطاقات اللاعبين الذين لعبوا في هذه الجولة
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            uiState.currentTrickCards.forEach { play ->
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (play.playerId == 0) GoldPrimary else SurfaceDarkNavy,
                                        modifier = Modifier.padding(bottom = 4.dp)
                                    ) {
                                        Text(
                                            text = play.playerName,
                                            color = if (play.playerId == 0) Color.Black else Color.White,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    PlayingCardView(
                                        card = play.card,
                                        width = 54.dp,
                                        height = 78.dp
                                    )
                                }
                            }
                        }
                    }

                    // تنبيه فوز الجولة عند انتهائها
                    if (uiState.showLastTrickSummary && uiState.lastTrickWinnerId != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        val winner = uiState.players.find { it.id == uiState.lastTrickWinnerId }
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = GoldDark,
                            border = BorderStroke(1.5.dp, GoldLight)
                        ) {
                            Text(
                                text = String.format(strings.trickWonMessage, winner?.name ?: "", uiState.lastTrickPoints),
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            else -> {
                // مراحل أخرى
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = strings.gameBannerFivePlayers,
                        color = GoldLight.copy(alpha = 0.4f),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

/**
 * شريط التنبيهات والأحداث المباشرة
 */
@Composable
private fun GameLogTicker(
    uiState: GameUIState,
    strings: LocalizedStrings,
    modifier: Modifier = Modifier
) {
    val lastEntry = uiState.logEntries.lastOrNull()
    val lastMessage = lastEntry?.format(strings, uiState.players)
        ?: uiState.gameLog.lastOrNull()
        ?: strings.welcomeTicker

    Surface(
        modifier = modifier
            .padding(horizontal = 12.dp, vertical = 2.dp),
        shape = RoundedCornerShape(8.dp),
        color = Color.Black.copy(alpha = 0.4f),
        border = BorderStroke(0.8.dp, Color.White.copy(alpha = 0.1f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = lastMessage,
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1
            )

            if (uiState.isAiThinking) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(12.dp),
                        strokeWidth = 1.5.dp,
                        color = GoldLight
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = strings.thinkingTicker,
                        color = GoldLight,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

/**
 * منطقة اللاعب البشري (أنت) وأوراقه
 */
@Composable
private fun HumanPlayerArea(
    uiState: GameUIState,
    onCardClick: (com.example.model.Card) -> Unit,
    strings: LocalizedStrings,
    activeReaction: ActiveReaction? = null,
    modifier: Modifier = Modifier
) {
    val human = uiState.players.find { it.id == uiState.localPlayerSeatId } ?: uiState.humanPlayer ?: return
    val isMyTurn = uiState.currentTurnPlayerId == uiState.localPlayerSeatId && uiState.phase == GamePhase.TRICK_PLAYING
    val isBuyer = uiState.buyerId == uiState.localPlayerSeatId

    val infiniteTransition = rememberInfiniteTransition(label = "human_turn_glow")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(650, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "my_turn_glow"
    )

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // شريط حالة اللاعب البشري
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .border(
                            width = if (isMyTurn) 2.dp else 0.dp,
                            color = if (isMyTurn) GoldPrimary.copy(alpha = glowAlpha) else Color.Transparent,
                            shape = CircleShape
                        )
                        .background(if (isMyTurn) GoldPrimary else FeltGreenMedium, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = if (isMyTurn) Color.Black else Color.White,
                        modifier = Modifier.size(15.dp)
                    )
                }
                if (activeReaction != null) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Surface(
                        shape = CircleShape,
                        color = Color.Black.copy(alpha = 0.85f),
                        border = BorderStroke(1.dp, GoldLight)
                    ) {
                        Text(
                            text = activeReaction.emoji,
                            fontSize = 18.sp,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (uiState.isMultiplayerMode) "${human.name} (${strings.youLabel})" else strings.youLabel,
                    color = GoldLight,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                if (uiState.dealerPlayerId == uiState.localPlayerSeatId) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = GoldDark.copy(alpha = 0.4f)
                    ) {
                        Text(
                            text = "🎴 ${strings.dealerBadge}",
                            color = GoldLight,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
                if (isBuyer) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = GoldPrimary
                    ) {
                        Text(
                            text = "${strings.buyerBadge} (${uiState.winningBid}${strings.pointsBadgeSuffix})",
                            color = Color.Black,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
                if (human.isExemptFromAuction) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = GoldLight.copy(alpha = 0.2f),
                        border = BorderStroke(1.dp, GoldLight)
                    ) {
                        Text(
                            text = strings.exemptBadge,
                            color = GoldLight,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }

                // عرض رصيد كروت اللاعب البشري
                Spacer(modifier = Modifier.width(8.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = SuitRed.copy(alpha = 0.2f),
                        border = BorderStroke(1.dp, SuitRed)
                    ) {
                        Text(
                            text = "🟥 ${human.redCards}/2",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = Color.Black.copy(alpha = 0.4f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.4f))
                    ) {
                        Text(
                            text = "⬛ ${human.blackCards}/2",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
            }

            Text(
                text = String.format(strings.pointsAndTricks, human.pointsWon, human.tricksWon),
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )

            if (isMyTurn) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = SuccessGreen
                ) {
                    Text(
                        text = strings.yourTurnToPlay,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // يد أوراق اللاعب البشري (قابلة للتمرير والضغط)
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("human_hand_row"),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy((-14).dp) // تراكب الورق بشكل احترافي
        ) {
            items(human.hand) { card ->
                val isPlayable = if (uiState.phase == GamePhase.TRICK_PLAYING && isMyTurn) {
                    TirbGameLogic.isCardPlayable(card, human.hand, uiState.leadingSuit)
                } else {
                    true
                }

                PlayingCardView(
                    card = card,
                    width = 62.dp,
                    height = 92.dp,
                    isPlayable = isPlayable,
                    onClick = {
                        if (isMyTurn) {
                            onCardClick(card)
                        }
                    }
                )
            }
        }
    }
}

/**
 * شريط معاينة أوراق اللاعب البشري قبل بدء المزاد
 */
@Composable
private fun InitialDealPreviewBar(
    uiState: GameUIState,
    onStartAuction: () -> Unit,
    strings: LocalizedStrings,
    modifier: Modifier = Modifier
) {
    val human = uiState.humanPlayer
    val handPoints = human?.hand?.sumOf { it.points } ?: 0

    Card(
        modifier = modifier.testTag("initial_deal_preview_bar"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = FeltGreenDark),
        border = BorderStroke(1.5.dp, GoldPrimary),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Visibility,
                        contentDescription = null,
                        tint = GoldLight,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = strings.initialDealInspectCards,
                        color = GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = String.format(strings.initialDealHandSummary, human?.hand?.size ?: 7, handPoints),
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Button(
                onClick = onStartAuction,
                modifier = Modifier
                    .height(38.dp)
                    .testTag("start_auction_button"),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = GoldPrimary,
                    contentColor = Color.Black
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Gavel,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = strings.startAuctionButton,
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp
                )
            }
        }
    }
}

