package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.localization.LocalizationManager
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.FeltGreenDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.SurfaceDarkNavy

@Composable
fun RulesHelpSheet(onDismiss: () -> Unit) {
    val strings by LocalizationManager.strings.collectAsState()

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("rules_help_dialog"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDarkNavy),
            border = BorderStroke(1.5.dp, GoldPrimary),
            elevation = CardDefaults.cardElevation(defaultElevation = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // رأس النافذة
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = strings.rulesDialogTitle,
                            color = GoldLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = strings.closeButton, tint = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // بطاقة التذكير
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = AmberAccent.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, AmberAccent.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = "﴿ ${strings.religiousReminder} ﴾",
                        color = GoldLight,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                RuleSection(
                    title = strings.rule1Title,
                    content = strings.rule1Content
                )

                RuleSection(
                    title = strings.rule2Title,
                    content = strings.rule2Content
                )

                RuleSection(
                    title = strings.rule3Title,
                    content = strings.rule3Content
                )

                RuleSection(
                    title = strings.rule4Title,
                    content = strings.rule4Content
                )

                RuleSection(
                    title = strings.rule5Title,
                    content = strings.rule5Content
                )

                RuleSection(
                    title = strings.rule6Title,
                    content = strings.rule6Content
                )

                RuleSection(
                    title = strings.rule7Title,
                    content = strings.rule7Content
                )

                RuleSection(
                    title = strings.rule8Title,
                    content = strings.rule8Content
                )
            }
        }
    }
}

@Composable
private fun RuleSection(title: String, content: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .background(FeltGreenDark, RoundedCornerShape(10.dp))
            .padding(10.dp)
    ) {
        Text(text = title, color = GoldLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = content, color = Color.White.copy(alpha = 0.9f), fontSize = 11.5.sp, lineHeight = 16.sp)
    }
}

