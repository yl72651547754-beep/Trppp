package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.getDisplayName
import com.example.localization.getLocalizedName
import com.example.localization.LocalizationManager
import com.example.model.GamePhase
import com.example.model.GameUIState
import com.example.model.Suit
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.DangerRed
import com.example.ui.theme.FeltGreenDark
import com.example.ui.theme.FeltGreenMedium
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuitBlack
import com.example.ui.theme.SuitRed
import com.example.ui.theme.SurfaceCardContainer

@Composable
fun ScoreBoardHeader(
    uiState: GameUIState,
    onOpenRules: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenLanguage: () -> Unit,
    onOpenBluetooth: () -> Unit,
    onOpenProfile: () -> Unit = {},
    isSoundEnabled: Boolean = true,
    onToggleSound: () -> Unit = {},
    onOpenSettings: () -> Unit = {},
    onToggleReactions: () -> Unit = {},
    isBluetoothConnected: Boolean = false,
    onOpenQuickChat: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val currentLang by LocalizationManager.currentLanguage.collectAsState()
    val strings by LocalizationManager.strings.collectAsState()
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("scoreboard_header"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCardContainer.copy(alpha = 0.94f)),
        border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.6f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            // الصف العلوي: الجولة، الموزع، نوع الترب، أزرار التحكم
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // عداد الجولات والموزع
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = FeltGreenDark,
                        border = BorderStroke(1.dp, GoldPrimary)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = when (uiState.phase) {
                                    GamePhase.TRICK_PLAYING -> String.format(strings.roundOfEight, uiState.currentRound)
                                    GamePhase.INITIAL_DEAL -> strings.phaseDeal
                                    GamePhase.AUCTION -> strings.auctionTitle
                                    GamePhase.FIELD_DISTRIBUTION -> strings.phaseField
                                    GamePhase.DECLARE_TRUMP -> strings.trumpSuitLabel
                                    GamePhase.GAME_OVER -> strings.phaseResult
                                    else -> strings.trumpSuitLabel
                                },
                                color = GoldLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                modifier = Modifier.testTag("round_counter_text")
                            )
                        }
                    }

                    // شارة الموزع الحالي
                    val dealerName = uiState.dealer?.name ?: "غير محدد"
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = GoldDark.copy(alpha = 0.25f),
                        border = BorderStroke(1.dp, GoldLight.copy(alpha = 0.6f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${strings.dealerLabel}: $dealerName 🎴",
                                color = GoldLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                // نوع الترب المصرح به
                if (uiState.trumpSuit != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = FeltGreenDark,
                        border = BorderStroke(1.dp, GoldPrimary)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${strings.trumpSuitLabel}: ",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 11.sp
                            )
                            Text(
                                text = "${uiState.trumpSuit.getLocalizedName(strings)} ${uiState.trumpSuit.symbol}",
                                color = if (uiState.trumpSuit.isRed) SuitRed else GoldLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                // أزرار التحكم: المتصدرين، الملف الشخصي، الأونلاين، البلوتوث، اللغة، المساعدة، السجل
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(1.dp)
                ) {
                    // زر الملف الشخصي واسم المستخدم والـ ID
                    IconButton(
                        onClick = onOpenProfile,
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Player Profile",
                            tint = GoldLight,
                            modifier = Modifier.size(19.dp)
                        )
                    }

                    // زر تفعيل / كتم المؤثرات الصوتية (Sound Effects Toggle)
                    IconButton(
                        onClick = onToggleSound,
                        modifier = Modifier.size(29.dp).testTag("sound_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (isSoundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                            contentDescription = if (isSoundEnabled) "Mute Sound" else "Enable Sound",
                            tint = if (isSoundEnabled) GoldPrimary else Color(0xFF9E9E9E),
                            modifier = Modifier.size(19.dp)
                        )
                    }

                    // زر المحادثة السريعة للبلوتوث
                    if (onOpenQuickChat != null && uiState.isMultiplayerMode) {
                        IconButton(
                            onClick = onOpenQuickChat,
                            modifier = Modifier.size(29.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Chat,
                                contentDescription = "Quick Chat",
                                tint = AmberAccent,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                    }

                    // زر البلوتوث
                    IconButton(
                        onClick = onOpenBluetooth,
                        modifier = Modifier.size(29.dp)
                    ) {
                        Box(contentAlignment = Alignment.TopEnd) {
                            Icon(
                                imageVector = Icons.Default.Bluetooth,
                                contentDescription = "Bluetooth Multiplayer",
                                tint = if (isBluetoothConnected || uiState.isMultiplayerMode) Color(0xFF64B5F6) else GoldLight,
                                modifier = Modifier.size(18.dp)
                            )
                            if (isBluetoothConnected || uiState.isMultiplayerMode) {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .clip(CircleShape)
                                        .background(SuccessGreen)
                                )
                            }
                        }
                    }

                    // زر اختيار اللغة
                    IconButton(
                        onClick = onOpenLanguage,
                        modifier = Modifier.size(29.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = currentLang.flag, fontSize = 13.sp)
                        }
                    }

                    // زر التعبيرات التفاعلية والمشاعر (In-game Emojis)
                    IconButton(
                        onClick = onToggleReactions,
                        modifier = Modifier.size(29.dp).testTag("emoji_reactions_button")
                    ) {
                        Text(text = "😎", fontSize = 14.sp)
                    }

                    // زر خصائص وإعدادات اللعبة العالمية (Settings ⚙️)
                    IconButton(
                        onClick = onOpenSettings,
                        modifier = Modifier.size(29.dp).testTag("game_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Game Settings",
                            tint = GoldLight,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = onOpenRules,
                        modifier = Modifier.size(29.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.HelpOutline,
                            contentDescription = "قواعد اللعبة",
                            tint = GoldLight,
                            modifier = Modifier.size(17.dp)
                        )
                    }
                    IconButton(
                        onClick = onOpenHistory,
                        modifier = Modifier.size(29.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "سجل المباريات",
                            tint = GoldLight,
                            modifier = Modifier.size(17.dp)
                        )
                    }
                }
            }

            // في مرحلة اللعب: شريط متابعة المعادلة الذهبية
            if (uiState.phase == GamePhase.TRICK_PLAYING || uiState.phase == GamePhase.GAME_OVER) {
                Spacer(modifier = Modifier.height(6.dp))

                val opponentsPts = uiState.opponentsTotalPoints
                val bid = uiState.winningBid
                val totalSum = uiState.goldenSum
                val buyerName = uiState.buyer?.name ?: strings.buyerLabel
                val progress = (totalSum / 187f).coerceIn(0f, 1f)
                val isDanger = totalSum > 187

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${strings.buyerLabel}: $buyerName ($bid نقطة)",
                        color = GoldLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Text(
                        text = "نقاط الخصوم ($opponentsPts) + المزاد ($bid) = $totalSum / 187",
                        color = if (isDanger) DangerRed else SuccessGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = if (isDanger) DangerRed else if (totalSum > 160) AmberAccent else SuccessGreen,
                    trackColor = Color.White.copy(alpha = 0.15f)
                )
            }
        }
    }
}
