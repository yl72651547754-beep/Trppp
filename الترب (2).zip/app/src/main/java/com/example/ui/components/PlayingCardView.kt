package com.example.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.localization.LocalizationManager
import com.example.model.Card
import com.example.model.Rank
import com.example.model.Suit
import androidx.compose.ui.platform.LocalContext
import com.example.settings.CardBackTheme
import com.example.settings.GameSettingsManager
import com.example.ui.theme.CardIvory
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.JokerViolet
import com.example.ui.theme.SuitBlack
import com.example.ui.theme.SuitRed

/**
 * ورقة لعب ذات جودة فائقة وتصميم كازينو ملكي فاخر:
 * - وضوح تام للأرقام ورموز الفئات (♠ ♥ ♦ ♣).
 * - صور واضحة وكبيرة وعالية الدقة للأوراق الملكية:
 *   * الجوكر الملكي (2 كراول - 25 نقطة): رسمة جوكر فينيسية فخمة R.drawable.img_joker_card.
 *   * الشايب (الملك K): صورة ملكية فخمة R.drawable.img_king_card.
 *   * البنت (الملكة Q): صورة ملكية أنيقة R.drawable.img_queen_card.
 *   * الغلام (الجاك J): صورة فارس شاب R.drawable.img_jack_card.
 * - شارات نقاط مميزة وواضحة (25ن، 11ن، 10ن، 4ن).
 */
@Composable
fun PlayingCardView(
    card: Card,
    modifier: Modifier = Modifier,
    isSelected: Boolean = false,
    isPlayable: Boolean = true,
    showPointsBadge: Boolean = true,
    width: Dp = 54.dp,
    height: Dp = 78.dp,
    onClick: (() -> Unit)? = null
) {
    val offsetY by animateDpAsState(
        targetValue = if (isSelected) (-12).dp else 0.dp,
        label = "cardElevation"
    )

    val suitColor = when {
        card.isJoker -> JokerViolet
        card.suit.isRed -> SuitRed
        else -> SuitBlack
    }

    val borderStroke = when {
        isSelected -> BorderStroke(2.5.dp, GoldPrimary)
        card.isJoker -> BorderStroke(2.dp, GoldPrimary)
        isPlayable -> BorderStroke(1.2.dp, GoldLight.copy(alpha = 0.8f))
        else -> BorderStroke(1.dp, Color(0x25000000))
    }

    // صورة الورقة الحاملة للصور: جوكر، شايب (ملك)، بنت (ملكة)، غلام (جاك)
    val cardArtDrawableRes = when {
        card.isJoker || (card.rank == Rank.TWO && card.suit == Suit.CLUBS) || card.rank == Rank.JOKER_BIG || card.rank == Rank.JOKER_SMALL -> R.drawable.img_joker_card
        card.rank == Rank.KING -> R.drawable.img_king_card
        card.rank == Rank.QUEEN -> R.drawable.img_queen_card
        card.rank == Rank.JACK -> R.drawable.img_jack_card
        else -> null
    }

    Card(
        modifier = modifier
            .width(width)
            .height(height)
            .offset(y = offsetY)
            .alpha(if (isPlayable) 1f else 0.45f)
            .shadow(if (isSelected) 10.dp else 4.dp, RoundedCornerShape(9.dp))
            .testTag("card_${card.id}")
            .then(
                if (onClick != null && isPlayable) {
                    Modifier.clickable { onClick() }
                } else {
                    Modifier
                }
            ),
        shape = RoundedCornerShape(9.dp),
        colors = CardDefaults.cardColors(
            containerColor = CardIvory
        ),
        border = borderStroke,
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 8.dp else 3.dp)
    ) {
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            if (cardArtDrawableRes != null) {
                // 1. الصورة الملكية واضحة وكاملة على كامل مساحة الورقة
                Image(
                    painter = painterResource(id = cardArtDrawableRes),
                    contentDescription = card.displayTitleArabic,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(8.dp)),
                    contentScale = ContentScale.Crop
                )

                // 2. إطار داخلي ذهبي فاخر للأوراق المصورة
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(2.dp)
                        .border(
                            BorderStroke(
                                1.dp,
                                if (card.isJoker) GoldPrimary else GoldLight.copy(alpha = 0.70f)
                            ),
                            RoundedCornerShape(7.dp)
                        )
                )

                // 3. ركن علوي أيسر (الرتبة والرمز) داخل شارة حماية عاجية شبه شفافة لضمان الوضوح التام فوق الصورة
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(start = 2.5.dp, top = 2.5.dp),
                    shape = RoundedCornerShape(topStart = 6.dp, bottomEnd = 6.dp),
                    color = Color.White.copy(alpha = 0.90f),
                    shadowElevation = 2.dp
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = card.shortLabel,
                            color = suitColor,
                            fontSize = if (card.shortLabel.length > 1) 11.sp else 13.sp,
                            fontWeight = FontWeight.Black,
                            lineHeight = 13.sp
                        )
                        Text(
                            text = card.suit.symbol,
                            color = suitColor,
                            fontSize = 11.sp,
                            lineHeight = 11.sp
                        )
                    }
                }

                // 4. ركن سفلي أيمن مقلوب 180 درجة لمطابقة أوراق اللعب الاحترافية
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 2.5.dp, bottom = 2.5.dp),
                    shape = RoundedCornerShape(bottomEnd = 6.dp, topStart = 6.dp),
                    color = Color.White.copy(alpha = 0.90f),
                    shadowElevation = 2.dp
                ) {
                    Column(
                        modifier = Modifier
                            .rotate(180f)
                            .padding(horizontal = 3.dp, vertical = 1.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = card.shortLabel,
                            color = suitColor,
                            fontSize = if (card.shortLabel.length > 1) 11.sp else 13.sp,
                            fontWeight = FontWeight.Black,
                            lineHeight = 13.sp
                        )
                        Text(
                            text = card.suit.symbol,
                            color = suitColor,
                            fontSize = 11.sp,
                            lineHeight = 11.sp
                        )
                    }
                }

                // 5. شريط سفلي فاخر بعنوان الورقة المصورة
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 3.dp),
                    shape = RoundedCornerShape(4.dp),
                    color = if (card.isJoker) JokerViolet.copy(alpha = 0.92f) else Color(0xDD1F1B18),
                    border = BorderStroke(0.6.dp, GoldLight.copy(alpha = 0.8f))
                ) {
                    Text(
                        text = when {
                            card.isJoker -> "الجوكر"
                            card.rank == Rank.KING -> "الشايب"
                            card.rank == Rank.QUEEN -> "البنت"
                            card.rank == Rank.JACK -> "الولد"
                            else -> card.shortLabel
                        },
                        color = Color(0xFFFFE082),
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 0.5.dp)
                    )
                }
            } else {
                // الأوراق العادية بدون صورة (A, 10, 9, 8, 7, 6, 2): خلفية عاجية ملكية
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color(0xFFFFFFFF), CardIvory)
                            )
                        )
                )

                // ركن علوي أيسر (الرتبة والرمز)
                Column(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(start = 4.dp, top = 2.5.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = card.shortLabel,
                        color = suitColor,
                        fontSize = if (card.shortLabel.length > 1) 11.5.sp else 13.5.sp,
                        fontWeight = FontWeight.Black,
                        lineHeight = 13.5.sp
                    )
                    Text(
                        text = card.suit.symbol,
                        color = suitColor,
                        fontSize = 11.5.sp,
                        lineHeight = 11.5.sp
                    )
                }

                // وسط الورقة: رمز الفئة واضح وكبير
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(vertical = 1.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size((width.value * 0.55f).dp)
                    ) {
                        Text(
                            text = card.suit.symbol,
                            color = suitColor,
                            fontSize = (width.value * 0.40f).sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // ركن سفلي أيمن مقلوب 180 درجة (لتطابق أوراق اللعب الاحترافية)
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .rotate(180f)
                        .padding(start = 4.dp, top = 2.5.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = card.shortLabel,
                        color = suitColor,
                        fontSize = if (card.shortLabel.length > 1) 11.5.sp else 13.5.sp,
                        fontWeight = FontWeight.Black,
                        lineHeight = 13.5.sp
                    )
                    Text(
                        text = card.suit.symbol,
                        color = suitColor,
                        fontSize = 11.5.sp,
                        lineHeight = 11.5.sp
                    )
                }
            }

            // شارة النقاط في الركن العلوي الأيمن (25ن، 11ن، 10ن، 4ن)
            if (showPointsBadge && card.points > 0) {
                val strings = LocalizationManager.strings.collectAsState().value
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(2.dp),
                    shape = RoundedCornerShape(4.dp),
                    color = when {
                        card.points >= 25 -> JokerViolet
                        card.points >= 10 -> GoldDark
                        else -> GoldDark.copy(alpha = 0.88f)
                    },
                    border = BorderStroke(0.6.dp, GoldLight),
                    shadowElevation = 2.dp
                ) {
                    Text(
                        text = "${card.points}${strings.pointsBadgeSuffix}",
                        color = Color.White,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp)
                    )
                }
            }
        }
    }
}

/**
 * ظهر ورقة اللعب بتصميم أرابيسك ملكي فاخر
 */
@Composable
fun CardBackView(
    modifier: Modifier = Modifier,
    width: Dp = 48.dp,
    height: Dp = 68.dp,
    customTheme: CardBackTheme? = null
) {
    val context = LocalContext.current
    val settingsManager = remember { GameSettingsManager.getInstance(context) }
    val activeCardBack by settingsManager.cardBackTheme.collectAsState()
    val theme = customTheme ?: activeCardBack
    val strings = LocalizationManager.strings.collectAsState().value

    Card(
        modifier = modifier
            .width(width)
            .height(height)
            .shadow(3.dp, RoundedCornerShape(7.dp)),
        shape = RoundedCornerShape(7.dp),
        colors = CardDefaults.cardColors(containerColor = theme.primaryBg),
        border = BorderStroke(1.2.dp, theme.borderColor)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(3.dp)
                .background(
                    Brush.radialGradient(colors = theme.gradientColors),
                    RoundedCornerShape(5.dp)
                )
                .border(BorderStroke(0.6.dp, theme.borderColor.copy(alpha = 0.7f)), RoundedCornerShape(5.dp)),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = strings.faceDownCard,
                    tint = theme.emblemColor,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "ترب",
                    color = theme.emblemColor,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
