package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = Color.Black,
    primaryContainer = GoldDark,
    onPrimaryContainer = GoldLight,
    secondary = FeltGreenLight,
    onSecondary = Color.White,
    secondaryContainer = FeltGreenDark,
    onSecondaryContainer = GoldLight,
    tertiary = AmberAccent,
    background = FeltGreenDark,
    onBackground = Color.White,
    surface = SurfaceDarkNavy,
    onSurface = Color.White,
    surfaceVariant = SurfaceCardContainer,
    onSurfaceVariant = Color(0xFFE0E0E0),
    error = DangerRed
)

private val LightColorScheme = darkColorScheme( // We want a luxurious casino dark felt palette by default
    primary = GoldPrimary,
    onPrimary = Color.Black,
    primaryContainer = GoldLight,
    onPrimaryContainer = Color.Black,
    secondary = FeltGreenMedium,
    onSecondary = Color.White,
    background = FeltGreenDark,
    onBackground = Color.White,
    surface = SurfaceDarkNavy,
    onSurface = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep consistent casino felt styling
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
