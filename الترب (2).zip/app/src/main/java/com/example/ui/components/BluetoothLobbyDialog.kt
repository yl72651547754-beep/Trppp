package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothSearching
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.bluetooth.BluetoothGameManager
import com.example.bluetooth.BluetoothPermissionHelper
import com.example.bluetooth.BluetoothRole
import com.example.bluetooth.ConnectionStatus
import com.example.bluetooth.LobbyPlayer
import com.example.localization.LocalizationManager
import com.example.localization.getDisplayName
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.DangerRed
import com.example.ui.theme.FeltGreenDark
import com.example.ui.theme.FeltGreenMedium
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceDarkNavy

@Composable
fun BluetoothLobbyDialog(
    bluetoothManager: BluetoothGameManager,
    onDismiss: () -> Unit,
    onRequestPermissions: () -> Unit,
    onStartGame: () -> Unit
) {
    val context = LocalContext.current
    val strings = LocalizationManager.strings.collectAsState().value
    val profile by com.example.profile.UserProfileManager.profile.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) }

    LaunchedEffect(profile.username) {
        bluetoothManager.setMyName(profile.username)
    }

    val role by bluetoothManager.role.collectAsState()
    val status by bluetoothManager.status.collectAsState()
    val statusMessage by bluetoothManager.statusMessage.collectAsState()
    val lobbyPlayers by bluetoothManager.lobbyPlayers.collectAsState()
    val discoveredDevices by bluetoothManager.discoveredDevices.collectAsState()
    val isGameStartedByHost by bluetoothManager.isGameStartedByHost.collectAsState()

    LaunchedEffect(isGameStartedByHost) {
        if (isGameStartedByHost) {
            onStartGame()
        }
    }

    val hasPermissions = remember(status) {
        BluetoothPermissionHelper.hasPermissions(context)
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .testTag("bluetooth_lobby_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDarkNavy.copy(alpha = 0.98f)),
            border = BorderStroke(
                width = 1.5.dp,
                brush = Brush.linearGradient(listOf(GoldLight, GoldPrimary, AmberAccent))
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(
                                    brush = Brush.linearGradient(listOf(Color(0xFF1976D2), Color(0xFF0D47A1)))
                                )
                                .border(1.dp, GoldPrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bluetooth,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = strings.bluetoothTitle,
                                color = GoldLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = strings.bluetoothSubHeader,
                                color = AmberAccent.copy(alpha = 0.8f),
                                fontSize = 11.sp
                            )
                        }
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Tabs: Host / Join
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.Black.copy(alpha = 0.3f),
                    contentColor = GoldLight,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = GoldPrimary,
                            height = 3.dp
                        )
                    }
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = {
                            selectedTab = 0
                            if (role != BluetoothRole.HOST) {
                                bluetoothManager.startHosting()
                            }
                        },
                        text = {
                            Text(
                                text = strings.bluetoothHostTab,
                                fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = {
                            selectedTab = 1
                            if (status != ConnectionStatus.SCANNING) {
                                bluetoothManager.scanDevices()
                            }
                        },
                        text = {
                            Text(
                                text = strings.bluetoothJoinTab,
                                fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Permissions Banner if needed
                if (!hasPermissions) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = DangerRed.copy(alpha = 0.18f),
                        border = BorderStroke(1.dp, DangerRed.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.Security, contentDescription = null, tint = DangerRed, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = strings.bluetoothNeedPermission,
                                    color = Color.White,
                                    fontSize = 12.sp
                                )
                            }
                            Button(
                                onClick = onRequestPermissions,
                                colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(strings.bluetoothGrantPermission, fontSize = 11.sp)
                            }
                        }
                    }
                }

                // Status message indicator
                if (statusMessage.isNotEmpty()) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        shape = RoundedCornerShape(10.dp),
                        color = when (status) {
                            ConnectionStatus.CONNECTED -> SuccessGreen.copy(alpha = 0.15f)
                            ConnectionStatus.ERROR -> DangerRed.copy(alpha = 0.15f)
                            else -> AmberAccent.copy(alpha = 0.15f)
                        },
                        border = BorderStroke(
                            1.dp,
                            when (status) {
                                ConnectionStatus.CONNECTED -> SuccessGreen.copy(alpha = 0.4f)
                                ConnectionStatus.ERROR -> DangerRed.copy(alpha = 0.4f)
                                else -> AmberAccent.copy(alpha = 0.4f)
                            }
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (status == ConnectionStatus.CONNECTING || status == ConnectionStatus.SCANNING) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = AmberAccent)
                                Spacer(modifier = Modifier.width(8.dp))
                            } else if (status == ConnectionStatus.CONNECTED) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                            }
                            Text(
                                text = statusMessage,
                                color = Color.White,
                                fontSize = 12.sp,
                                maxLines = 2
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Content for Tab 0: HOST
                if (selectedTab == 0) {
                    HostTabContent(
                        lobbyPlayers = lobbyPlayers,
                        strings = strings,
                        isHost = role == BluetoothRole.HOST,
                        onToggleAi = { seatId -> bluetoothManager.toggleSeatAi(seatId) },
                        onStartGame = onStartGame
                    )
                } else {
                    // Content for Tab 1: JOIN
                    if (role == BluetoothRole.CLIENT && status == ConnectionStatus.CONNECTED) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            shape = RoundedCornerShape(16.dp),
                            color = FeltGreenDark.copy(alpha = 0.5f),
                            border = BorderStroke(1.5.dp, GoldPrimary)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = SuccessGreen,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = strings.bluetoothJoinedLobbyTitle,
                                    color = GoldLight,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = strings.bluetoothWaitingHostDesc,
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 13.sp,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    color = GoldLight,
                                    strokeWidth = 2.5.dp
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                OutlinedButton(
                                    onClick = { bluetoothManager.disconnect() },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed),
                                    border = BorderStroke(1.dp, DangerRed.copy(alpha = 0.6f))
                                ) {
                                    Text(strings.bluetoothLeaveLobbyButton, fontSize = 12.sp)
                                }
                            }
                        }
                    } else {
                        JoinTabContent(
                            discoveredDevices = discoveredDevices,
                            isScanning = status == ConnectionStatus.SCANNING,
                            strings = strings,
                            onScanAgain = { bluetoothManager.scanDevices() },
                            onConnectDevice = { dev -> bluetoothManager.connectToDevice(dev) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HostTabContent(
    lobbyPlayers: List<LobbyPlayer>,
    strings: com.example.localization.LocalizedStrings,
    isHost: Boolean,
    onToggleAi: (Int) -> Unit,
    onStartGame: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = String.format(strings.bluetoothConnectedPlayers, lobbyPlayers.count { !it.isAi || it.isHost }),
                color = GoldLight,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            Text(
                text = strings.fiveSeatsFullGame,
                color = AmberAccent,
                fontSize = 11.sp
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(lobbyPlayers) { player ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = if (player.isHost) FeltGreenDark.copy(alpha = 0.7f) else Color.White.copy(alpha = 0.05f),
                    border = BorderStroke(
                        1.dp,
                        if (player.isHost) GoldPrimary else if (player.isAi) Color.White.copy(alpha = 0.1f) else SuccessGreen.copy(alpha = 0.6f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(if (player.isHost) GoldPrimary else if (player.isAi) Color.Gray else SuccessGreen),
                                contentAlignment = Alignment.Center
                            ) {
                                if (player.isAi) {
                                    Icon(Icons.Default.SmartToy, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                } else {
                                    Icon(Icons.Default.Group, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    val playerName = player.getDisplayName(strings)
                                    Text(
                                        text = String.format(strings.seatNumberAndName, player.seatId + 1, playerName),
                                        color = if (player.isHost) GoldLight else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    if (player.isHost) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = GoldPrimary.copy(alpha = 0.3f)
                                        ) {
                                            Text(
                                                text = strings.hostBadge,
                                                color = GoldLight,
                                                fontSize = 9.sp,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                }
                                Text(
                                    text = if (player.isAi) strings.aiBotPlayer else if (player.isHost) strings.yourCurrentDevice else strings.bluetoothConnectedFriend,
                                    color = Color.White.copy(alpha = 0.6f),
                                    fontSize = 10.sp
                                )
                            }
                        }

                        if (!player.isHost) {
                            OutlinedButton(
                                onClick = { onToggleAi(player.seatId) },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = if (player.isAi) GoldLight else Color.White
                                ),
                                border = BorderStroke(1.dp, if (player.isAi) GoldPrimary.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.3f)),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Text(
                                    text = if (player.isAi) strings.openForFriend else strings.switchToAi,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = onStartGame,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("start_bluetooth_game_button"),
            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color.Black),
            shape = RoundedCornerShape(12.dp),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = strings.bluetoothStartGame,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color.Black
                )
            }
        }
    }
}

@Composable
private fun JoinTabContent(
    discoveredDevices: List<com.example.bluetooth.DiscoveredBluetoothDevice>,
    isScanning: Boolean,
    strings: com.example.localization.LocalizedStrings,
    onScanAgain: () -> Unit,
    onConnectDevice: (com.example.bluetooth.DiscoveredBluetoothDevice) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = strings.bluetoothAvailableDevices,
                color = GoldLight,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            IconButton(
                onClick = onScanAgain,
                modifier = Modifier.size(32.dp),
                enabled = !isScanning
            ) {
                if (isScanning) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = GoldLight)
                } else {
                    Icon(Icons.Default.Refresh, contentDescription = "Scan", tint = GoldLight)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (discoveredDevices.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.BluetoothSearching,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.4f),
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = strings.bluetoothNoDevicesFound,
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = onScanAgain,
                        colors = ButtonDefaults.buttonColors(containerColor = FeltGreenDark),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(strings.bluetoothScanDevices, fontSize = 11.sp, color = GoldLight)
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(discoveredDevices) { dev ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onConnectDevice(dev) },
                        shape = RoundedCornerShape(12.dp),
                        color = Color.White.copy(alpha = 0.06f),
                        border = BorderStroke(1.dp, if (dev.isPaired) GoldPrimary.copy(alpha = 0.4f) else Color.White.copy(alpha = 0.1f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(if (dev.isPaired) Color(0xFF1976D2) else Color.DarkGray),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Bluetooth, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = dev.name,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = if (dev.isPaired) strings.pairedDeviceTapToConnect else dev.address,
                                        color = Color.White.copy(alpha = 0.6f),
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            Button(
                                onClick = { onConnectDevice(dev) },
                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text(strings.connectButton, fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
