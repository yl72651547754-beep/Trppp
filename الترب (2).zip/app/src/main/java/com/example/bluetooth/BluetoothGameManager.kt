package com.example.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.util.Log
import com.example.logic.TirbGameLogic
import com.example.model.Card
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.concurrent.CopyOnWriteArrayList

/**
 * مدير اتصالات البلوتوث المطور للعبة الترب:
 * يدعم الربط المباشر الموثوق بين هواتف اللاعبين دون الحاجة للإنترنت.
 * يتضمن:
 * 1. استكشاف الأجهزة القريبة والمقترنة عبر BroadcastReceiver.
 * 2. اتصال سوكت RFCOMM آمن وغير مقيد (Insecure & Secure Fallback).
 * 3. مصافحة تلقائية لتحديد أسماء ومقاعد اللاعبين (Handshake).
 * 4. مزامنة فورية كاملة للرزمة وتوزيع الأوراق (Deck Synchronization).
 * 5. بث وتبادل حركات اللعب والمحادثات السريعة.
 */
class BluetoothGameManager(private val context: Context) {

    companion object {
        private const val TAG = "BluetoothGameManager"
        private const val SERVICE_NAME = "TirbCardGameRoom"
        // المعرف القياسي للاتصال التسلسلي (SPP UUID) لضمان التوافقية العالية بين مختلف الشركات
        val TIRB_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val bluetoothManager: BluetoothManager? =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

    private val _role = MutableStateFlow(BluetoothRole.NONE)
    val role: StateFlow<BluetoothRole> = _role.asStateFlow()

    private val _status = MutableStateFlow(ConnectionStatus.IDLE)
    val status: StateFlow<ConnectionStatus> = _status.asStateFlow()

    private val _statusMessage = MutableStateFlow("")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private val _mySeatId = MutableStateFlow(0)
    val mySeatId: StateFlow<Int> = _mySeatId.asStateFlow()

    private val _myPlayerName = MutableStateFlow("أنت")
    val myPlayerName: StateFlow<String> = _myPlayerName.asStateFlow()

    private val _lobbyPlayers = MutableStateFlow<List<LobbyPlayer>>(emptyList())
    val lobbyPlayers: StateFlow<List<LobbyPlayer>> = _lobbyPlayers.asStateFlow()

    private val _discoveredDevices = MutableStateFlow<List<DiscoveredBluetoothDevice>>(emptyList())
    val discoveredDevices: StateFlow<List<DiscoveredBluetoothDevice>> = _discoveredDevices.asStateFlow()

    private val _quickChatMessages = MutableStateFlow<List<QuickChatMessage>>(emptyList())
    val quickChatMessages: StateFlow<List<QuickChatMessage>> = _quickChatMessages.asStateFlow()

    private val _isSimulationMode = MutableStateFlow(false)
    val isSimulationMode: StateFlow<Boolean> = _isSimulationMode.asStateFlow()

    private val _isGameStartedByHost = MutableStateFlow(false)
    val isGameStartedByHost: StateFlow<Boolean> = _isGameStartedByHost.asStateFlow()

    // Host variables
    private var serverSocket: BluetoothServerSocket? = null
    private val clientSockets = CopyOnWriteArrayList<BluetoothSocket>()
    private var hostAcceptJob: Job? = null

    // Client variables
    private var clientSocket: BluetoothSocket? = null
    private var clientListenJob: Job? = null

    // Callbacks
    var onPacketReceived: ((BluetoothPacket) -> Unit)? = null
    var onGameStartedWithDeck: ((dealerId: Int, deck: List<Card>) -> Unit)? = null

    private var isReceiverRegistered = false

    private val discoveryReceiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(c: Context?, intent: Intent?) {
            when (intent?.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    }

                    if (device != null) {
                        val name = try { device.name?.ifBlank { null } ?: "جهاز بلوتوث" } catch (e: Exception) { "جهاز بلوتوث" }
                        val address = device.address ?: ""
                        val isPaired = device.bondState == BluetoothDevice.BOND_BONDED

                        _discoveredDevices.update { currentList ->
                            if (currentList.none { it.address.equals(address, ignoreCase = true) }) {
                                currentList + DiscoveredBluetoothDevice(
                                    name = name,
                                    address = address,
                                    isPaired = isPaired,
                                    device = device
                                )
                            } else {
                                currentList
                            }
                        }
                    }
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    if (_status.value == ConnectionStatus.SCANNING) {
                        _status.value = ConnectionStatus.IDLE
                        _statusMessage.value = "اكتمل البحث عن الأجهزة"
                    }
                }
            }
        }
    }

    val isBluetoothSupported: Boolean
        get() = bluetoothAdapter != null

    val isBluetoothEnabled: Boolean
        get() = bluetoothAdapter?.isEnabled == true

    val deviceName: String
        @SuppressLint("MissingPermission")
        get() = try {
            bluetoothAdapter?.name?.ifBlank { null } ?: "جهاز الترب"
        } catch (e: Exception) {
            "جهاز الترب"
        }

    init {
        resetLobby(asHost = true, hostName = "المستضيف (أنت)")
        registerReceiverSafe()
    }

    private fun registerReceiverSafe() {
        if (!isReceiverRegistered) {
            try {
                val filter = IntentFilter().apply {
                    addAction(BluetoothDevice.ACTION_FOUND)
                    addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
                }
                context.registerReceiver(discoveryReceiver, filter)
                isReceiverRegistered = true
            } catch (e: Exception) {
                Log.w(TAG, "Failed to register discovery receiver: ${e.message}")
            }
        }
    }

    private fun unregisterReceiverSafe() {
        if (isReceiverRegistered) {
            try {
                context.unregisterReceiver(discoveryReceiver)
                isReceiverRegistered = false
            } catch (e: Exception) {
                Log.w(TAG, "Failed to unregister discovery receiver: ${e.message}")
            }
        }
    }

    fun setMyName(name: String) {
        _myPlayerName.value = name
    }

    /**
     * تجهيز اللوبي بـ 5 مقاعد: المستضيف + مقاعد الأصدقاء والذكاء الاصطناعي
     */
    fun resetLobby(asHost: Boolean, hostName: String) {
        if (asHost) {
            _mySeatId.value = 0
            _lobbyPlayers.value = listOf(
                LobbyPlayer(seatId = 0, name = hostName, isHost = true, isAi = false, isReady = true, deviceName = deviceName),
                LobbyPlayer(seatId = 1, name = "سارة", isHost = false, isAi = true, isReady = true),
                LobbyPlayer(seatId = 2, name = "فهد", isHost = false, isAi = true, isReady = true),
                LobbyPlayer(seatId = 3, name = "نورة", isHost = false, isAi = true, isReady = true),
                LobbyPlayer(seatId = 4, name = "عمر", isHost = false, isAi = true, isReady = true)
            )
        }
    }

    /**
     * تبديل مقعد بين صديق عبر البلوتوث ولاعب آلي (AI)
     */
    fun toggleSeatAi(seatId: Int) {
        if (_role.value != BluetoothRole.HOST && !_isSimulationMode.value) return
        _lobbyPlayers.update { list ->
            list.map { player ->
                if (player.seatId == seatId && !player.isHost) {
                    val nowAi = !player.isAi
                    val defaultNames = listOf("أنت", "سارة", "فهد", "نورة", "عمر")
                    val newName = if (nowAi) defaultNames.getOrElse(seatId) { "لاعب $seatId" } else "بانتظار صديق..."
                    player.copy(isAi = nowAi, name = newName, isReady = nowAi)
                } else player
            }
        }
        broadcastLobbyUpdate()
    }

    /**
     * بدء استضافة طاولة البلوتوث (Host Server Mode)
     */
    @SuppressLint("MissingPermission")
    fun startHosting(roomName: String = deviceName) {
        disconnect()
        _role.value = BluetoothRole.HOST
        _mySeatId.value = 0
        _status.value = ConnectionStatus.CONNECTING
        _statusMessage.value = "جاري فتح طاولة البلوتوث واستقبال الأصدقاء..."
        resetLobby(asHost = true, hostName = _myPlayerName.value.ifEmpty { "المستضيف (أنت)" })

        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled) {
            _status.value = ConnectionStatus.CONNECTED
            _statusMessage.value = "طاولة الاستضافة مفتوحة (في وضع الاستعداد)"
            return
        }

        hostAcceptJob = scope.launch(Dispatchers.IO) {
            try {
                // إيقاف أي بحث جارٍ لتفريغ النطاق الترددي للاتصال
                if (bluetoothAdapter.isDiscovering) {
                    bluetoothAdapter.cancelDiscovery()
                }

                // تجربة السوكت غير المقيد (Insecure) لضمان نجاح الاتصال بدون تعليق
                serverSocket = try {
                    bluetoothAdapter.listenUsingInsecureRfcommWithServiceRecord(SERVICE_NAME, TIRB_UUID)
                } catch (e: Exception) {
                    Log.w(TAG, "Insecure listen failed, falling back to secure RFCOMM", e)
                    bluetoothAdapter.listenUsingRfcommWithServiceRecord(SERVICE_NAME, TIRB_UUID)
                }

                withContext(Dispatchers.Main) {
                    _status.value = ConnectionStatus.CONNECTED
                    _statusMessage.value = "الطاولة جاهزة! بانتظار اتصال أصدقائك..."
                }

                while (isActive && clientSockets.size < 4) {
                    try {
                        val socket = serverSocket?.accept() ?: break
                        clientSockets.add(socket)

                        // بدء الاستماع لبيانات هذا العميل
                        launch(Dispatchers.IO) {
                            listenToSocket(socket, seatId = -1)
                        }

                        // إرسال التزامن الأولي لبيانات الطاولة إلى العميل الجديد
                        val syncPacket = createLobbySyncPacket()
                        sendPacketToSocket(socket, syncPacket)

                    } catch (e: Exception) {
                        Log.e(TAG, "Error accepting client socket", e)
                        break
                    }
                }
            } catch (e: SecurityException) {
                withContext(Dispatchers.Main) {
                    _status.value = ConnectionStatus.ERROR
                    _statusMessage.value = "يرجى منح أذونات البلوتوث للبدء"
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _status.value = ConnectionStatus.ERROR
                    _statusMessage.value = "تعذر بدء السيرفر: ${e.message}"
                }
            }
        }
    }

    private fun findNextAvailableSeat(): Int? {
        val current = _lobbyPlayers.value
        val seat = current.firstOrNull { it.seatId != 0 && (it.isAi || it.name.startsWith("بانتظار")) }
        return seat?.seatId
    }

    private fun updateSeatWithClient(seatId: Int, clientName: String, address: String) {
        _lobbyPlayers.update { list ->
            list.map { player ->
                if (player.seatId == seatId) {
                    player.copy(name = clientName, isHost = false, isAi = false, isReady = true, deviceName = address)
                } else player
            }
        }
    }

    /**
     * البحث عن الأجهزة القريبة والمقترنة عبر البلوتوث
     */
    @SuppressLint("MissingPermission")
    fun scanDevices() {
        registerReceiverSafe()
        _status.value = ConnectionStatus.SCANNING
        _statusMessage.value = "جاري البحث عن أجهزة البلوتوث وطاولات اللعب..."

        val list = mutableListOf<DiscoveredBluetoothDevice>()

        // 1. إضافة الأجهزة المقترنة مسبقاً
        try {
            bluetoothAdapter?.bondedDevices?.forEach { device ->
                val name = device.name?.ifBlank { null } ?: "جهاز مقترن"
                list.add(
                    DiscoveredBluetoothDevice(
                        name = name,
                        address = device.address,
                        isPaired = true,
                        device = device
                    )
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error reading bonded devices", e)
        }

        _discoveredDevices.value = list

        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled) {
            _status.value = ConnectionStatus.IDLE
            _statusMessage.value = "البلوتوث غير مفعل. قم بتفعيله للاتصال بأصدقائك"
            return
        }

        // 2. بدء استكشاف الأجهزة الجديدة عبر الراديو
        try {
            if (bluetoothAdapter.isDiscovering) {
                bluetoothAdapter.cancelDiscovery()
            }
            bluetoothAdapter.startDiscovery()
            scope.launch {
                delay(12000)
                if (_status.value == ConnectionStatus.SCANNING) {
                    _status.value = ConnectionStatus.IDLE
                    _statusMessage.value = "اكتمل البحث عن الأجهزة"
                }
            }
        } catch (e: Exception) {
            _status.value = ConnectionStatus.IDLE
        }
    }

    /**
     * الاتصال بطاولة المستضيف (Client Mode)
     */
    @SuppressLint("MissingPermission")
    fun connectToDevice(deviceItem: DiscoveredBluetoothDevice) {
        disconnect()
        _role.value = BluetoothRole.CLIENT
        _status.value = ConnectionStatus.CONNECTING
        _statusMessage.value = "جاري الاتصال بالطاولة: ${deviceItem.name}..."

        clientListenJob = scope.launch(Dispatchers.IO) {
            try {
                val device = deviceItem.device ?: bluetoothAdapter?.getRemoteDevice(deviceItem.address)
                if (device == null) {
                    withContext(Dispatchers.Main) {
                        _status.value = ConnectionStatus.ERROR
                        _statusMessage.value = "الجهاز غير موجود"
                    }
                    return@launch
                }

                // إلغاء الاستكشاف فوراً قبل بدء الاتصال لتحرير المودم
                if (bluetoothAdapter?.isDiscovering == true) {
                    bluetoothAdapter.cancelDiscovery()
                }
                delay(100)

                // تجربة الاتصال عبر المنافذ الآمنة وغير المقيدة
                var connectedSocket: BluetoothSocket? = null

                // المحاولة الأولى: Insecure RFCOMM
                try {
                    val s = device.createInsecureRfcommSocketToServiceRecord(TIRB_UUID)
                    s.connect()
                    connectedSocket = s
                } catch (e1: Exception) {
                    Log.w(TAG, "Insecure connect failed, trying secure RFCOMM...", e1)
                }

                // المحاولة الثانية: Secure RFCOMM
                if (connectedSocket == null) {
                    try {
                        val s = device.createRfcommSocketToServiceRecord(TIRB_UUID)
                        s.connect()
                        connectedSocket = s
                    } catch (e2: Exception) {
                        Log.w(TAG, "Secure connect failed, trying reflection socket channel 1...", e2)
                    }
                }

                // المحاولة الثالثة: Reflection على القناة 1 (Channel 1 RFCOMM)
                if (connectedSocket == null) {
                    try {
                        val method = device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                        val s = method.invoke(device, 1) as BluetoothSocket
                        s.connect()
                        connectedSocket = s
                    } catch (e3: Exception) {
                        Log.e(TAG, "Reflection connect failed", e3)
                        throw e3
                    }
                }

                val socket = connectedSocket ?: throw IllegalStateException("فشل فتح منفذ اتصال بالبلوتوث")
                clientSocket = socket

                withContext(Dispatchers.Main) {
                    _status.value = ConnectionStatus.CONNECTED
                    _statusMessage.value = "متصل بنجاح! جاري الانضمام لمقعدك..."
                }

                // إرسال طلب حجز مقعد وتزويد المستضيف باسم اللاعب الحقيقي
                val joinRequest = BluetoothPacket(
                    type = BluetoothPacket.PacketType.REQUEST_SEAT,
                    senderSeatId = -1,
                    senderName = _myPlayerName.value,
                    payload = _myPlayerName.value
                )
                sendRawData(socket, joinRequest.serialize())

                // الاستماع للحزم الواردة من المستضيف
                listenToSocket(socket, seatId = -1)

            } catch (e: Exception) {
                Log.e(TAG, "Connection failed", e)
                withContext(Dispatchers.Main) {
                    _status.value = ConnectionStatus.ERROR
                    _statusMessage.value = "تعذر الاتصال بالطاولة: ${e.localizedMessage ?: "تأكد من فتح الطاولة في هاتف المستضيف"}"
                }
            }
        }
    }

    /**
     * بدء اللعبة من جانب المستضيف وتوزيع نفس الأوراق لجميع الهواتف المتصلة
     */
    fun startHostingGame(): List<Card> {
        val fullDeck = TirbGameLogic.createDeck().shuffled()
        val deckCardIds = fullDeck.joinToString(",") { it.id }
        val startPacket = BluetoothPacket(
            type = BluetoothPacket.PacketType.GAME_START,
            senderSeatId = 0,
            senderName = _myPlayerName.value,
            payload = "0|$deckCardIds"
        )
        broadcastPacket(startPacket)
        _isGameStartedByHost.value = true
        onGameStartedWithDeck?.invoke(0, fullDeck)
        return fullDeck
    }

    /**
     * تفعيل وضع المحاكاة التجريبي (Bluetooth Simulation)
     */
    fun enableSimulationMode() {
        _isSimulationMode.value = true
        _role.value = BluetoothRole.HOST
        _status.value = ConnectionStatus.CONNECTED
        _statusMessage.value = "وضع محاكاة البلوتوث نشط (جاهز للعب)"
        _lobbyPlayers.value = listOf(
            LobbyPlayer(seatId = 0, name = _myPlayerName.value.ifEmpty { "المستضيف (أنت)" }, isHost = true, isAi = false, isReady = true),
            LobbyPlayer(seatId = 1, name = "صديق (بلوتوث)", isHost = false, isAi = false, isReady = true, deviceName = "Galaxy S24"),
            LobbyPlayer(seatId = 2, name = "سارة", isHost = false, isAi = true, isReady = true),
            LobbyPlayer(seatId = 3, name = "فهد", isHost = false, isAi = true, isReady = true),
            LobbyPlayer(seatId = 4, name = "نورة", isHost = false, isAi = true, isReady = true)
        )
    }

    /**
     * قراءة الحزم والبيانات من السوكت
     */
    private suspend fun listenToSocket(socket: BluetoothSocket, seatId: Int) {
        withContext(Dispatchers.IO) {
            try {
                val reader = BufferedReader(InputStreamReader(socket.inputStream, StandardCharsets.UTF_8))
                while (isActive && socket.isConnected) {
                    val line = reader.readLine() ?: break
                    val packet = BluetoothPacket.deserialize(line)
                    if (packet != null) {
                        withContext(Dispatchers.Main) {
                            handleIncomingPacket(socket, packet)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Socket closed or read error: ${e.message}")
            } finally {
                withContext(Dispatchers.Main) {
                    if (_role.value == BluetoothRole.CLIENT) {
                        _status.value = ConnectionStatus.IDLE
                        _statusMessage.value = "تم قطع الاتصال بالطاولة"
                    }
                }
            }
        }
    }

    private fun handleIncomingPacket(socket: BluetoothSocket?, packet: BluetoothPacket) {
        when (packet.type) {
            BluetoothPacket.PacketType.REQUEST_SEAT -> {
                // المستضيف يعالج طلب انضمام صديق
                if (_role.value == BluetoothRole.HOST) {
                    val clientName = packet.senderName.ifBlank { packet.payload }.ifBlank { "صديق" }
                    val assignedSeat = findNextAvailableSeat()
                    if (assignedSeat != null && socket != null) {
                        val deviceAddress = try { socket.remoteDevice.address } catch (e: Exception) { "" }
                        updateSeatWithClient(assignedSeat, clientName, deviceAddress)

                        // إرسال تأكيد المقعد لهذا العميل
                        sendPacketToSocket(
                            socket,
                            BluetoothPacket(
                                type = BluetoothPacket.PacketType.ASSIGN_SEAT,
                                senderSeatId = 0,
                                senderName = _myPlayerName.value,
                                payload = "$assignedSeat|${_myPlayerName.value}"
                            )
                        )
                        // بث تحديث اللوبي للجميع
                        broadcastLobbyUpdate()
                    }
                }
            }

            BluetoothPacket.PacketType.ASSIGN_SEAT -> {
                // العميل يستقبل المقعد المخصص له
                val parts = packet.payload.split("|")
                if (parts.isNotEmpty()) {
                    val assignedSeat = parts[0].toIntOrNull() ?: 1
                    _mySeatId.value = assignedSeat
                    _status.value = ConnectionStatus.CONNECTED
                    _statusMessage.value = "تم حجز المقعد رقم $assignedSeat لك في الطاولة بنجاح!"
                }
            }

            BluetoothPacket.PacketType.LOBBY_SYNC -> {
                // مزامنة حالة مقاعد اللوبي
                val items = packet.payload.split(";")
                val updatedList = items.mapNotNull { itemStr ->
                    val p = itemStr.split(",")
                    if (p.size >= 5) {
                        LobbyPlayer(
                            seatId = p[0].toIntOrNull() ?: 0,
                            name = p[1],
                            isHost = p[2].toBoolean(),
                            isAi = p[3].toBoolean(),
                            isReady = p[4].toBoolean()
                        )
                    } else null
                }
                if (updatedList.isNotEmpty()) {
                    _lobbyPlayers.value = updatedList
                }
            }

            BluetoothPacket.PacketType.GAME_START -> {
                // انطلاق المباراة واستلام رزمة الأوراق الموزعة من المستضيف
                val parts = packet.payload.split("|", limit = 2)
                val dealerId = parts.getOrNull(0)?.toIntOrNull() ?: 0
                val cardIds = parts.getOrNull(1)?.split(",") ?: emptyList()
                val syncedDeck = cardIds.mapNotNull { TirbGameLogic.getCardById(it) }

                _isGameStartedByHost.value = true
                if (syncedDeck.size >= 40) {
                    onGameStartedWithDeck?.invoke(dealerId, syncedDeck)
                }
                onPacketReceived?.invoke(packet)
            }

            BluetoothPacket.PacketType.QUICK_CHAT -> {
                val parts = packet.payload.split("|")
                if (parts.size >= 2) {
                    addQuickChatMessage(packet.senderName, parts[0], parts[1])
                }
                if (_role.value == BluetoothRole.HOST) {
                    broadcastPacket(packet)
                }
            }

            else -> {
                // تمرير حركات اللعبة (مزايدة، باص، توزيع، اختيار ترب، لعب ورقة)
                if (_role.value == BluetoothRole.HOST) {
                    // إعادة البث لباقي الأجهزة المتصلة
                    broadcastPacket(packet)
                }
                onPacketReceived?.invoke(packet)
            }
        }
    }

    /**
     * إرسال رسالة محادثة سريعة
     */
    fun sendQuickChat(text: String, emoji: String) {
        val myName = _myPlayerName.value
        addQuickChatMessage(myName, text, emoji)
        val packet = BluetoothPacket(
            type = BluetoothPacket.PacketType.QUICK_CHAT,
            senderSeatId = _mySeatId.value,
            senderName = myName,
            payload = "$text|$emoji"
        )
        broadcastPacket(packet)
    }

    private fun addQuickChatMessage(senderName: String, text: String, emoji: String) {
        _quickChatMessages.update { current ->
            (current + QuickChatMessage(senderName, text, emoji)).takeLast(10)
        }
    }

    /**
     * بث حزمة لكل الأجهزة المتصلة
     */
    fun broadcastPacket(packet: BluetoothPacket) {
        scope.launch(Dispatchers.IO) {
            val data = packet.serialize()
            if (_role.value == BluetoothRole.HOST) {
                clientSockets.forEach { socket ->
                    sendRawData(socket, data)
                }
            } else if (_role.value == BluetoothRole.CLIENT) {
                clientSocket?.let { sendRawData(it, data) }
            }
        }
    }

    private fun createLobbySyncPacket(): BluetoothPacket {
        val payload = _lobbyPlayers.value.joinToString(";") {
            "${it.seatId},${it.name},${it.isHost},${it.isAi},${it.isReady}"
        }
        return BluetoothPacket(
            type = BluetoothPacket.PacketType.LOBBY_SYNC,
            senderSeatId = 0,
            senderName = _myPlayerName.value,
            payload = payload
        )
    }

    private fun broadcastLobbyUpdate() {
        broadcastPacket(createLobbySyncPacket())
    }

    private fun sendPacketToSocket(socket: BluetoothSocket, packet: BluetoothPacket) {
        scope.launch(Dispatchers.IO) {
            sendRawData(socket, packet.serialize())
        }
    }

    private fun sendRawData(socket: BluetoothSocket, data: String) {
        try {
            if (socket.isConnected) {
                val writer = OutputStreamWriter(socket.outputStream, StandardCharsets.UTF_8)
                writer.write(data)
                writer.flush()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to send data: ${e.message}")
        }
    }

    fun stopAll() = disconnect()

    /**
     * إغلاق كافة الاتصالات والعودة للوضع الفردي
     */
    fun disconnect() {
        hostAcceptJob?.cancel()
        clientListenJob?.cancel()

        try {
            if (bluetoothAdapter?.isDiscovering == true) {
                bluetoothAdapter.cancelDiscovery()
            }
        } catch (e: Exception) { /* ignore */ }

        try {
            clientSockets.forEach { it.close() }
            clientSockets.clear()
        } catch (e: Exception) { /* ignore */ }

        try {
            serverSocket?.close()
            serverSocket = null
        } catch (e: Exception) { /* ignore */ }

        try {
            clientSocket?.close()
            clientSocket = null
        } catch (e: Exception) { /* ignore */ }

        _role.value = BluetoothRole.NONE
        _status.value = ConnectionStatus.IDLE
        _statusMessage.value = ""
        _isSimulationMode.value = false
        _isGameStartedByHost.value = false
    }

    fun release() {
        disconnect()
        unregisterReceiverSafe()
    }
}
