package com.example.bluetooth

import android.bluetooth.BluetoothDevice

enum class BluetoothRole {
    NONE,
    HOST,
    CLIENT
}

enum class ConnectionStatus {
    IDLE,
    SCANNING,
    CONNECTING,
    CONNECTED,
    ERROR
}

data class DiscoveredBluetoothDevice(
    val name: String,
    val address: String,
    val isPaired: Boolean,
    val device: BluetoothDevice? = null
)

data class LobbyPlayer(
    val seatId: Int, // 0..4
    val name: String,
    val isHost: Boolean,
    val isAi: Boolean,
    val isReady: Boolean = true,
    val deviceName: String = ""
)

/**
 * حزم البيانات المتبادلة عبر البلوتوث بين الأجهزة:
 */
data class BluetoothPacket(
    val type: PacketType,
    val senderSeatId: Int,
    val senderName: String,
    val payload: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    enum class PacketType {
        LOBBY_SYNC,
        REQUEST_SEAT,
        ASSIGN_SEAT,
        GAME_START,
        SYNC_GAME_STATE,
        ACTION_START_AUCTION,
        ACTION_BID,
        ACTION_PASS,
        ACTION_DISTRIBUTE_FIELD,
        ACTION_DECLARE_TRUMP,
        ACTION_PLAY_CARD,
        QUICK_CHAT,
        HEARTBEAT,
        PLAYER_DISCONNECTED
    }

    fun serialize(): String {
        val safeName = senderName.replace("|", "^PIPE^").replace("\n", "^NL^")
        val safePayload = payload.replace("|", "^PIPE^").replace("\n", "^NL^")
        return "${type.name}|$senderSeatId|$safeName|$safePayload|$timestamp\n"
    }

    companion object {
        fun deserialize(raw: String): BluetoothPacket? {
            return try {
                val parts = raw.trim().split("|", limit = 5)
                if (parts.size >= 5) {
                    val type = PacketType.valueOf(parts[0])
                    val seatId = parts[1].toInt()
                    val senderName = parts[2].replace("^PIPE^", "|").replace("^NL^", "\n")
                    val payload = parts[3].replace("^PIPE^", "|").replace("^NL^", "\n")
                    val timestamp = parts[4].toLong()
                    BluetoothPacket(type, seatId, senderName, payload, timestamp)
                } else null
            } catch (e: Exception) {
                null
            }
        }
    }
}

data class QuickChatMessage(
    val senderName: String,
    val text: String,
    val emoji: String,
    val timestamp: Long = System.currentTimeMillis()
)
