package com.example.reaction

import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

data class ActiveReaction(
    val id: String = UUID.randomUUID().toString(),
    val playerId: Int,
    val emoji: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class ReactionOption(
    val emoji: String,
    val labelArabic: String,
    val labelEnglish: String
)

object ReactionManager {
    val availableReactions = listOf(
        ReactionOption("😎", "واثق", "Cool"),
        ReactionOption("🔥", "حماس", "Fire"),
        ReactionOption("🏆", "نصر", "Victory"),
        ReactionOption("👏", "تحية", "Clap"),
        ReactionOption("😱", "صدمة", "Shock"),
        ReactionOption("☕", "روقان", "Coffee"),
        ReactionOption("🃏", "الجوكر", "Joker"),
        ReactionOption("💣", "قنبلة", "Bomb"),
        ReactionOption("💎", "ألماس", "Diamond"),
        ReactionOption("❤️", "حب", "Love")
    )

    private val _activeReactions = MutableStateFlow<List<ActiveReaction>>(emptyList())
    val activeReactions: StateFlow<List<ActiveReaction>> = _activeReactions.asStateFlow()

    fun triggerReaction(playerId: Int, emoji: String) {
        val newReaction = ActiveReaction(playerId = playerId, emoji = emoji)
        _activeReactions.value = _activeReactions.value.filter {
            System.currentTimeMillis() - it.timestamp < 3000
        } + newReaction
    }

    fun clearExpired() {
        val now = System.currentTimeMillis()
        _activeReactions.value = _activeReactions.value.filter { now - it.timestamp < 3200 }
    }
}
