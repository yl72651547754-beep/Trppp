package com.example.settings

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * سمات الطاولة العالمية (World-class Casino Felts)
 */
enum class TableTheme(
    val titleArabic: String,
    val titleEnglish: String,
    val primaryColor: Color,
    val gradientColors: List<Color>,
    val rimColor: Color,
    val accentColor: Color
) {
    EMERALD(
        titleArabic = "الزمرد الملكي الكلاسيكي",
        titleEnglish = "Royal Emerald Felt",
        primaryColor = Color(0xFF0F4D2A),
        gradientColors = listOf(Color(0xFF165B34), Color(0xFF0C381E), Color(0xFF062312)),
        rimColor = Color(0xFFD4AF37),
        accentColor = Color(0xFFFFD700)
    ),
    SAPPHIRE(
        titleArabic = "الياقوت الأزرق الليلي",
        titleEnglish = "Midnight Sapphire",
        primaryColor = Color(0xFF0D2847),
        gradientColors = listOf(Color(0xFF123660), Color(0xFF0B213C), Color(0xFF051120)),
        rimColor = Color(0xFF4FC3F7),
        accentColor = Color(0xFF81D4FA)
    ),
    BURGUNDY(
        titleArabic = "المخمل القرمزي البورغندي",
        titleEnglish = "Burgundy Velvet",
        primaryColor = Color(0xFF4A0E17),
        gradientColors = listOf(Color(0xFF6B1522), Color(0xFF3F0B13), Color(0xFF240409)),
        rimColor = Color(0xFFFFB300),
        accentColor = Color(0xFFFFCC80)
    ),
    OBSIDIAN(
        titleArabic = "الأوبسيديان الفحمي الذهبي",
        titleEnglish = "Obsidian Gold VIP",
        primaryColor = Color(0xFF141416),
        gradientColors = listOf(Color(0xFF232526), Color(0xFF161718), Color(0xFF0B0C0C)),
        rimColor = Color(0xFFFFD700),
        accentColor = Color(0xFFFFE082)
    ),
    WALNUT(
        titleArabic = "خشب الجوز الملكي",
        titleEnglish = "Luxury Walnut Table",
        primaryColor = Color(0xFF3D2314),
        gradientColors = listOf(Color(0xFF54301B), Color(0xFF381F11), Color(0xFF1E0E06)),
        rimColor = Color(0xFFE0A96D),
        accentColor = Color(0xFFFFD180)
    )
}

/**
 * تصميم وألوان ظهر الورقة (Card Back Styles)
 */
enum class CardBackTheme(
    val titleArabic: String,
    val titleEnglish: String,
    val primaryBg: Color,
    val gradientColors: List<Color>,
    val borderColor: Color,
    val emblemColor: Color
) {
    CLASSIC_NAVY(
        titleArabic = "الترب الكحلي المذهب",
        titleEnglish = "Royal Navy Gold",
        primaryBg = Color(0xFF132F3D),
        gradientColors = listOf(Color(0xFF1E4B61), Color(0xFF0C1F2A)),
        borderColor = Color(0xFFD4AF37),
        emblemColor = Color(0xFFFFD700)
    ),
    ROYAL_RUBY(
        titleArabic = "القرمزي الملكي الفاخر",
        titleEnglish = "Imperial Ruby Red",
        primaryBg = Color(0xFF5C101B),
        gradientColors = listOf(Color(0xFF7A1826), Color(0xFF3D0810)),
        borderColor = Color(0xFFFFC107),
        emblemColor = Color(0xFFFFD54F)
    ),
    EMERALD_ARABESQUE(
        titleArabic = "الأرابيسك الزمردي",
        titleEnglish = "Emerald Arabesque",
        primaryBg = Color(0xFF0F432A),
        gradientColors = listOf(Color(0xFF175E3C), Color(0xFF0A2C1B)),
        borderColor = Color(0xFF81C784),
        emblemColor = Color(0xFFA5D6A7)
    ),
    OBSIDIAN_DIAMOND(
        titleArabic = "الألماس الأسود الفاخر",
        titleEnglish = "Obsidian Diamond VIP",
        primaryBg = Color(0xFF1E1E24),
        gradientColors = listOf(Color(0xFF2E2E36), Color(0xFF121216)),
        borderColor = Color(0xFFFFD700),
        emblemColor = Color(0xFFE0E0E0)
    )
}

/**
 * سرعة وتيرة اللعب (Game Speed)
 */
enum class GameSpeed(
    val titleArabic: String,
    val titleEnglish: String,
    val botDelayMs: Long,
    val speedMultiplier: String
) {
    NORMAL("عادي (تكتيكي)", "Normal (1.0x)", 1100L, "1.0x"),
    FAST("سريع (حماسي)", "Fast (1.5x)", 600L, "1.5x"),
    TURBO("تيربو نفاث", "Turbo (2.0x)", 280L, "2.0x")
}

/**
 * مدير إعدادات وخصائص اللعبة العالمية (GameSettingsManager)
 */
class GameSettingsManager private constructor(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _tableTheme = MutableStateFlow(
        TableTheme.entries.getOrElse(prefs.getInt(KEY_TABLE_THEME, 0)) { TableTheme.EMERALD }
    )
    val tableTheme: StateFlow<TableTheme> = _tableTheme.asStateFlow()

    private val _cardBackTheme = MutableStateFlow(
        CardBackTheme.entries.getOrElse(prefs.getInt(KEY_CARD_BACK, 0)) { CardBackTheme.CLASSIC_NAVY }
    )
    val cardBackTheme: StateFlow<CardBackTheme> = _cardBackTheme.asStateFlow()

    private val _gameSpeed = MutableStateFlow(
        GameSpeed.entries.getOrElse(prefs.getInt(KEY_GAME_SPEED, 0)) { GameSpeed.NORMAL }
    )
    val gameSpeed: StateFlow<GameSpeed> = _gameSpeed.asStateFlow()

    private val _hapticEnabled = MutableStateFlow(prefs.getBoolean(KEY_HAPTIC, true))
    val hapticEnabled: StateFlow<Boolean> = _hapticEnabled.asStateFlow()

    private val _cardGlowHighlight = MutableStateFlow(prefs.getBoolean(KEY_CARD_GLOW, true))
    val cardGlowHighlight: StateFlow<Boolean> = _cardGlowHighlight.asStateFlow()

    private val _autoPlaySingleLegal = MutableStateFlow(prefs.getBoolean(KEY_AUTO_PLAY_SINGLE, true))
    val autoPlaySingleLegal: StateFlow<Boolean> = _autoPlaySingleLegal.asStateFlow()

    private val _turnTimerSeconds = MutableStateFlow(prefs.getInt(KEY_TURN_TIMER, 15))
    val turnTimerSeconds: StateFlow<Int> = _turnTimerSeconds.asStateFlow()

    private val _sfxVolume = MutableStateFlow(prefs.getFloat(KEY_SFX_VOLUME, 1.0f))
    val sfxVolume: StateFlow<Float> = _sfxVolume.asStateFlow()

    fun setTableTheme(theme: TableTheme) {
        _tableTheme.value = theme
        prefs.edit().putInt(KEY_TABLE_THEME, theme.ordinal).apply()
    }

    fun setCardBackTheme(theme: CardBackTheme) {
        _cardBackTheme.value = theme
        prefs.edit().putInt(KEY_CARD_BACK, theme.ordinal).apply()
    }

    fun setGameSpeed(speed: GameSpeed) {
        _gameSpeed.value = speed
        prefs.edit().putInt(KEY_GAME_SPEED, speed.ordinal).apply()
    }

    fun setHapticEnabled(enabled: Boolean) {
        _hapticEnabled.value = enabled
        prefs.edit().putBoolean(KEY_HAPTIC, enabled).apply()
    }

    fun setCardGlowHighlight(enabled: Boolean) {
        _cardGlowHighlight.value = enabled
        prefs.edit().putBoolean(KEY_CARD_GLOW, enabled).apply()
    }

    fun setAutoPlaySingleLegal(enabled: Boolean) {
        _autoPlaySingleLegal.value = enabled
        prefs.edit().putBoolean(KEY_AUTO_PLAY_SINGLE, enabled).apply()
    }

    fun setTurnTimerSeconds(seconds: Int) {
        val clamped = seconds.coerceIn(5, 30)
        _turnTimerSeconds.value = clamped
        prefs.edit().putInt(KEY_TURN_TIMER, clamped).apply()
    }

    fun setSfxVolume(volume: Float) {
        val clamped = volume.coerceIn(0.0f, 1.0f)
        _sfxVolume.value = clamped
        prefs.edit().putFloat(KEY_SFX_VOLUME, clamped).apply()
    }

    companion object {
        private const val PREFS_NAME = "tirb_world_settings"
        private const val KEY_TABLE_THEME = "table_theme"
        private const val KEY_CARD_BACK = "card_back_theme"
        private const val KEY_GAME_SPEED = "game_speed"
        private const val KEY_HAPTIC = "haptic_enabled"
        private const val KEY_CARD_GLOW = "card_glow_highlight"
        private const val KEY_AUTO_PLAY_SINGLE = "auto_play_single"
        private const val KEY_TURN_TIMER = "turn_timer_seconds"
        private const val KEY_SFX_VOLUME = "sfx_volume"

        @Volatile
        private var instance: GameSettingsManager? = null

        fun getInstance(context: Context): GameSettingsManager {
            return instance ?: synchronized(this) {
                instance ?: GameSettingsManager(context.applicationContext).also { instance = it }
            }
        }
    }
}
