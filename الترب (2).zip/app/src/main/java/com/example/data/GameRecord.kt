package com.example.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "game_history")
data class GameRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val timestamp: Long = System.currentTimeMillis(),
    val buyerName: String,
    val isBuyerHuman: Boolean,
    val bid: Int,
    val trumpSuitName: String,
    val opponentsPoints: Int,
    val buyerPoints: Int,
    val totalSum: Int,
    val isBuyerWon: Boolean
)

@Dao
interface GameHistoryDao {
    @Query("SELECT * FROM game_history ORDER BY timestamp DESC")
    fun getAllRecords(): Flow<List<GameRecord>>

    @Insert
    suspend fun insertRecord(record: GameRecord)

    @Query("DELETE FROM game_history")
    suspend fun clearHistory()
}
