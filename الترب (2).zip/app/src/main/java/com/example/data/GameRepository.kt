package com.example.data

import kotlinx.coroutines.flow.Flow

class GameRepository(private val dao: GameHistoryDao) {
    val allRecords: Flow<List<GameRecord>> = dao.getAllRecords()

    suspend fun insertRecord(record: GameRecord) {
        dao.insertRecord(record)
    }

    suspend fun clearHistory() {
        dao.clearHistory()
    }
}
