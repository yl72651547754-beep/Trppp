package com.example.online

import com.example.logic.TirbGameLogic
import com.example.model.Card
import com.example.model.GamePhase
import com.example.model.Rank
import com.example.model.Suit
import com.example.model.TrickPlay
import kotlin.random.Random

/**
 * نموذج اللاعب المعتمد في الخادم الحاكم
 */
data class AuthoritativePlayer(
    val uid: String,
    val seatId: Int, // 0 to 4
    val username: String,
    val avatarEmoji: String,
    val avatarId: Int = 0,
    val hand: List<String> = emptyList(), // Card IDs (e.g. "CLUBS_TWO")
    val currentBid: Int = 0,
    val hasPassed: Boolean = false,
    val pointsWon: Int = 0,
    val tricksWon: Int = 0,
    val redCards: Int = 0,
    val blackCards: Int = 0,
    val isExemptFromAuction: Boolean = false,
    val isConnected: Boolean = true,
    val isReady: Boolean = false,
    val isHost: Boolean = false
)

/**
 * حالة اللعبة الحاكمة المعتمدة من الخادم (Canonical Server State)
 */
data class AuthoritativeGameState(
    val matchId: String = "",
    val phase: String = "LOBBY", // LOBBY, DEALING, AUCTION, FIELD_DISTRIBUTION, TRUMP_DECLARATION, PLAYING, ROUND_OVER, MATCH_OVER
    val matchRoundNumber: Int = 1,
    val dealerSeatId: Int = 0,
    val currentTurnSeatId: Int = 0,
    val starterSeatId: Int = 0,
    val currentAuctionBid: Int = 0,
    val winningBid: Int = 0,
    val buyerSeatId: Int? = null,
    val trumpSuit: String? = null, // SPADES, HEARTS, DIAMONDS, CLUBS
    val fieldCards: List<String> = emptyList(),
    val currentTrickPlays: List<AuthoritativeTrickPlay> = emptyList(),
    val lastTrickPlays: List<AuthoritativeTrickPlay> = emptyList(),
    val lastTrickWinnerSeatId: Int? = null,
    val currentTrickNumber: Int = 1,
    val players: List<AuthoritativePlayer> = emptyList(),
    val serverTimestamp: Long = System.currentTimeMillis(),
    val lastActionLog: String = "تم بدء الجلسة في الخادم"
)

data class AuthoritativeTrickPlay(
    val seatId: Int,
    val cardId: String,
    val playerName: String
)

/**
 * أوامر وحركات اللاعب المرسلة للخادم الحاكم
 */
sealed class AuthoritativePlayerAction {
    data class JoinLobby(val uid: String, val name: String, val avatar: String, val avatarId: Int) : AuthoritativePlayerAction()
    data class SetReady(val uid: String, val isReady: Boolean) : AuthoritativePlayerAction()
    data class StartMatch(val hostUid: String) : AuthoritativePlayerAction()
    data class PlaceBid(val uid: String, val bidAmount: Int) : AuthoritativePlayerAction()
    data class PassBid(val uid: String) : AuthoritativePlayerAction()
    data class DistributeFieldCards(
        val buyerUid: String,
        val keptCardIds: List<String>,
        val assignments: Map<Int, String> // SeatId -> CardId
    ) : AuthoritativePlayerAction()
    data class DeclareTrump(val buyerUid: String, val suit: Suit) : AuthoritativePlayerAction()
    data class PlayCard(val uid: String, val cardId: String) : AuthoritativePlayerAction()
    data class Reconnect(val uid: String) : AuthoritativePlayerAction()
    data class Disconnect(val uid: String) : AuthoritativePlayerAction()
}

/**
 * الخادم الحاكم الوحيد (Authoritative Server Engine)
 * يتحقق من صحة القواعد، يمنع التلاعب، ويحسب جميع النتائج بدقة 100%
 */
object AuthoritativeGameEngine {

    /**
     * معالجة حركة لاعب وتطبيقها على حالة اللعبة مع التحقق الصارم
     */
    fun processAction(
        currentState: AuthoritativeGameState,
        action: AuthoritativePlayerAction
    ): Result<AuthoritativeGameState> {
        return try {
            when (action) {
                is AuthoritativePlayerAction.JoinLobby -> handleJoinLobby(currentState, action)
                is AuthoritativePlayerAction.SetReady -> handleSetReady(currentState, action)
                is AuthoritativePlayerAction.StartMatch -> handleStartMatch(currentState, action)
                is AuthoritativePlayerAction.PlaceBid -> handlePlaceBid(currentState, action)
                is AuthoritativePlayerAction.PassBid -> handlePassBid(currentState, action)
                is AuthoritativePlayerAction.DistributeFieldCards -> handleDistributeFieldCards(currentState, action)
                is AuthoritativePlayerAction.DeclareTrump -> handleDeclareTrump(currentState, action)
                is AuthoritativePlayerAction.PlayCard -> handlePlayCard(currentState, action)
                is AuthoritativePlayerAction.Reconnect -> handleReconnect(currentState, action)
                is AuthoritativePlayerAction.Disconnect -> handleDisconnect(currentState, action)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun handleJoinLobby(
        state: AuthoritativeGameState,
        action: AuthoritativePlayerAction.JoinLobby
    ): Result<AuthoritativeGameState> {
        if (state.players.size >= 5 && state.players.none { it.uid == action.uid }) {
            return Result.failure(IllegalStateException("الغرفة ممتلئة (الحد الأقصى 5 لاعبين)"))
        }

        val existingIndex = state.players.indexOfFirst { it.uid == action.uid }
        val updatedPlayers = if (existingIndex >= 0) {
            state.players.mapIndexed { index, p ->
                if (index == existingIndex) p.copy(isConnected = true, username = action.name, avatarEmoji = action.avatar)
                else p
            }
        } else {
            val nextSeat = (0..4).firstOrNull { seat -> state.players.none { it.seatId == seat } }
                ?: return Result.failure(IllegalStateException("لا توجد مقاعد شاغرة"))
            state.players + AuthoritativePlayer(
                uid = action.uid,
                seatId = nextSeat,
                username = action.name,
                avatarEmoji = action.avatar,
                avatarId = action.avatarId,
                isHost = state.players.isEmpty(),
                isConnected = true,
                isReady = false
            )
        }

        return Result.success(
            state.copy(
                players = updatedPlayers.sortedBy { it.seatId },
                serverTimestamp = System.currentTimeMillis(),
                lastActionLog = "انضم ${action.name} إلى الطاولة"
            )
        )
    }

    private fun handleSetReady(
        state: AuthoritativeGameState,
        action: AuthoritativePlayerAction.SetReady
    ): Result<AuthoritativeGameState> {
        val player = state.players.find { it.uid == action.uid }
            ?: return Result.failure(IllegalArgumentException("اللاعب غير موجود"))

        val updated = state.players.map {
            if (it.uid == action.uid) it.copy(isReady = action.isReady) else it
        }
        return Result.success(
            state.copy(
                players = updated,
                serverTimestamp = System.currentTimeMillis()
            )
        )
    }

    private fun handleStartMatch(
        state: AuthoritativeGameState,
        action: AuthoritativePlayerAction.StartMatch
    ): Result<AuthoritativeGameState> {
        val host = state.players.find { it.isHost }
            ?: return Result.failure(IllegalStateException("المستضيف غير معروف"))
        if (host.uid != action.hostUid) {
            return Result.failure(IllegalStateException("فقط مستضيف الغرفة يمكنه بدء المباراة"))
        }
        if (state.players.size < 5) {
            return Result.failure(IllegalStateException("يجب اكتمال 5 لاعبين لبدء لعبة الترب"))
        }

        return Result.success(dealNewRound(state, dealerSeat = 0, preserveCardScores = false))
    }

    /**
     * توزيع جولة جديدة بشكل حتمي وعادل من الخادم
     */
    fun dealNewRound(
        state: AuthoritativeGameState,
        dealerSeat: Int,
        preserveCardScores: Boolean
    ): AuthoritativeGameState {
        val fullDeck = TirbGameLogic.createDeck().shuffled(Random(System.currentTimeMillis()))
        var cardIndex = 0

        val updatedPlayers = state.players.map { player ->
            val playerHand = fullDeck.subList(cardIndex, cardIndex + 7).map { it.id }
            cardIndex += 7
            val isExempt = if (preserveCardScores) player.redCards >= 2 else false
            player.copy(
                hand = playerHand,
                currentBid = 0,
                hasPassed = isExempt,
                pointsWon = 0,
                tricksWon = 0,
                isExemptFromAuction = isExempt
            )
        }

        val field = fullDeck.subList(cardIndex, cardIndex + 5).map { it.id }

        var starter = (dealerSeat + 1) % 5
        while (updatedPlayers.find { it.seatId == starter }?.isExemptFromAuction == true) {
            starter = (starter + 1) % 5
        }

        return state.copy(
            phase = "AUCTION",
            dealerSeatId = dealerSeat,
            starterSeatId = starter,
            currentTurnSeatId = starter,
            currentAuctionBid = 0,
            winningBid = 0,
            buyerSeatId = null,
            trumpSuit = null,
            fieldCards = field,
            currentTrickPlays = emptyList(),
            lastTrickPlays = emptyList(),
            currentTrickNumber = 1,
            players = updatedPlayers,
            serverTimestamp = System.currentTimeMillis(),
            lastActionLog = "قام الخادم بتوزيع 7 كروت لكل لاعب و5 كروت في الميدان. بدأ المزاد!"
        )
    }

    private fun handlePlaceBid(
        state: AuthoritativeGameState,
        action: AuthoritativePlayerAction.PlaceBid
    ): Result<AuthoritativeGameState> {
        if (state.phase != "AUCTION") {
            return Result.failure(IllegalStateException("المباراة ليست في طور المزاد"))
        }
        val currentP = state.players.find { it.seatId == state.currentTurnSeatId }
            ?: return Result.failure(IllegalStateException("اللاعب الحالي غير معروف"))
        if (currentP.uid != action.uid) {
            return Result.failure(IllegalStateException("ليس دورك في المزايدة الآن"))
        }
        if (action.bidAmount <= state.currentAuctionBid || action.bidAmount < 100 || action.bidAmount > 187) {
            return Result.failure(IllegalArgumentException("قيمة المزايدة غير مقبولة (يجب أن تكون بين ${maxOf(100, state.currentAuctionBid + 1)} و 187)"))
        }

        val updatedPlayers = state.players.map {
            if (it.seatId == currentP.seatId) it.copy(currentBid = action.bidAmount) else it
        }

        if (action.bidAmount >= 187) {
            // الحد الأقصى للمزاد (187) - يحسم المزاد فوراً
            return Result.success(
                state.copy(
                    phase = "FIELD_DISTRIBUTION",
                    currentAuctionBid = 187,
                    winningBid = 187,
                    buyerSeatId = currentP.seatId,
                    currentTurnSeatId = currentP.seatId,
                    players = updatedPlayers,
                    serverTimestamp = System.currentTimeMillis(),
                    lastActionLog = "${currentP.username} وصل للحد الأقصى (187) وفاز بالمزاد!"
                )
            )
        }

        // الانتقال للاعب التالي في المزاد
        val nextSeat = getNextActiveAuctionSeat(updatedPlayers, state.currentTurnSeatId)
        return Result.success(
            state.copy(
                currentAuctionBid = action.bidAmount,
                winningBid = action.bidAmount,
                buyerSeatId = currentP.seatId,
                currentTurnSeatId = nextSeat,
                players = updatedPlayers,
                serverTimestamp = System.currentTimeMillis(),
                lastActionLog = "${currentP.username} زاد المزاد إلى ${action.bidAmount}"
            )
        )
    }

    private fun handlePassBid(
        state: AuthoritativeGameState,
        action: AuthoritativePlayerAction.PassBid
    ): Result<AuthoritativeGameState> {
        if (state.phase != "AUCTION") {
            return Result.failure(IllegalStateException("المباراة ليست في طور المزاد"))
        }
        val currentP = state.players.find { it.seatId == state.currentTurnSeatId }
            ?: return Result.failure(IllegalStateException("اللاعب غير موجود"))
        if (currentP.uid != action.uid) {
            return Result.failure(IllegalStateException("ليس دورك الآن"))
        }

        val updatedPlayers = state.players.map {
            if (it.seatId == currentP.seatId) it.copy(hasPassed = true) else it
        }

        val active = updatedPlayers.filter { !it.hasPassed && !it.isExemptFromAuction }
        if (active.size <= 1) {
            val winner = active.firstOrNull()
                ?: state.buyerSeatId?.let { seat -> updatedPlayers.find { it.seatId == seat } }
                ?: updatedPlayers.first()
            val finalBid = maxOf(100, state.currentAuctionBid)

            return Result.success(
                state.copy(
                    phase = "FIELD_DISTRIBUTION",
                    buyerSeatId = winner.seatId,
                    winningBid = finalBid,
                    currentTurnSeatId = winner.seatId,
                    players = updatedPlayers,
                    serverTimestamp = System.currentTimeMillis(),
                    lastActionLog = "فاز ${winner.username} بالمزاد بـ $finalBid نقطة ويقوم بتوزيع كروت الميدان!"
                )
            )
        }

        val nextSeat = getNextActiveAuctionSeat(updatedPlayers, state.currentTurnSeatId)
        return Result.success(
            state.copy(
                currentTurnSeatId = nextSeat,
                players = updatedPlayers,
                serverTimestamp = System.currentTimeMillis(),
                lastActionLog = "قال ${currentP.username} باص في المزاد"
            )
        )
    }

    private fun getNextActiveAuctionSeat(players: List<AuthoritativePlayer>, currentSeat: Int): Int {
        var next = (currentSeat + 1) % 5
        while (players.find { it.seatId == next }?.hasPassed == true) {
            next = (next + 1) % 5
        }
        return next
    }

    private fun handleDistributeFieldCards(
        state: AuthoritativeGameState,
        action: AuthoritativePlayerAction.DistributeFieldCards
    ): Result<AuthoritativeGameState> {
        if (state.phase != "FIELD_DISTRIBUTION") {
            return Result.failure(IllegalStateException("المباراة ليست في طور توزيع الميدان"))
        }
        val buyer = state.players.find { it.seatId == state.buyerSeatId }
            ?: return Result.failure(IllegalStateException("المشتري غير محدد"))
        if (buyer.uid != action.buyerUid) {
            return Result.failure(IllegalStateException("فقط مشتري المزاد يقوم بتوزيع الكروت"))
        }

        val combinedCards = buyer.hand + state.fieldCards
        val allAssigned = action.keptCardIds + action.assignments.values
        if (allAssigned.size != 12 || !allAssigned.containsAll(combinedCards)) {
            return Result.failure(IllegalArgumentException("توزيع الكروت غير متطابق مع كروت اليد والميدان"))
        }

        val updatedPlayers = state.players.map { player ->
            if (player.seatId == buyer.seatId) {
                player.copy(hand = action.keptCardIds)
            } else {
                val assignedCard = action.assignments[player.seatId]
                if (assignedCard != null) {
                    player.copy(hand = player.hand + assignedCard)
                } else player
            }
        }

        return Result.success(
            state.copy(
                phase = "TRUMP_DECLARATION",
                fieldCards = emptyList(),
                players = updatedPlayers,
                serverTimestamp = System.currentTimeMillis(),
                lastActionLog = "وزع ${buyer.username} كروت الميدان وينتظر إعلان الترب!"
            )
        )
    }

    private fun handleDeclareTrump(
        state: AuthoritativeGameState,
        action: AuthoritativePlayerAction.DeclareTrump
    ): Result<AuthoritativeGameState> {
        if (state.phase != "TRUMP_DECLARATION") {
            return Result.failure(IllegalStateException("المباراة ليست في طور إعلان الترب"))
        }
        val buyer = state.players.find { it.seatId == state.buyerSeatId }
            ?: return Result.failure(IllegalStateException("المشتري غير موجود"))
        if (buyer.uid != action.buyerUid) {
            return Result.failure(IllegalStateException("فقط المشتري يعلن الترب"))
        }

        val starter = state.starterSeatId
        return Result.success(
            state.copy(
                phase = "PLAYING",
                trumpSuit = action.suit.name,
                currentTurnSeatId = starter,
                serverTimestamp = System.currentTimeMillis(),
                lastActionLog = "أعلن ${buyer.username} الترب (${action.suit.arabicName})! تبدأ الأكلات."
            )
        )
    }

    private fun handlePlayCard(
        state: AuthoritativeGameState,
        action: AuthoritativePlayerAction.PlayCard
    ): Result<AuthoritativeGameState> {
        if (state.phase != "PLAYING") {
            return Result.failure(IllegalStateException("المباراة ليست في طور اللعب"))
        }
        val currentP = state.players.find { it.seatId == state.currentTurnSeatId }
            ?: return Result.failure(IllegalStateException("اللاعب الحالي غير معروف"))
        if (currentP.uid != action.uid) {
            return Result.failure(IllegalStateException("ليس دورك في اللعب الآن"))
        }
        if (!currentP.hand.contains(action.cardId)) {
            return Result.failure(IllegalArgumentException("الكرت غير موجود في يدك"))
        }

        val deck = TirbGameLogic.createDeck()
        val playedCard = deck.find { it.id == action.cardId }
            ?: return Result.failure(IllegalArgumentException("الكرت غير معروف"))

        // التحقق من قاعدة الإلزام (Leading suit rule)
        if (state.currentTrickPlays.isNotEmpty()) {
            val firstCardId = state.currentTrickPlays.first().cardId
            val leadingCard = deck.find { it.id == firstCardId }
            val leadingSuit = leadingCard?.suit

            val playerHandCards = currentP.hand.mapNotNull { hid -> deck.find { it.id == hid } }
            val hasLeadingSuit = leadingSuit != null && playerHandCards.any { it.suit == leadingSuit }

            if (hasLeadingSuit && playedCard.suit != leadingSuit) {
                return Result.failure(IllegalArgumentException("يجب أن تلعب من نفس فئة البداية (${leadingSuit?.arabicName})!"))
            }
        }

        // خصم الكرت من يد اللاعب
        val updatedHand = currentP.hand.filter { it != action.cardId }
        val newTrickPlay = AuthoritativeTrickPlay(currentP.seatId, action.cardId, currentP.username)
        val updatedTrickPlays = state.currentTrickPlays + newTrickPlay

        val playersWithUpdatedHand = state.players.map {
            if (it.seatId == currentP.seatId) it.copy(hand = updatedHand) else it
        }

        // إذا اكتملت الأكلة (5 لاعبين رموا كروت)
        if (updatedTrickPlays.size == 5) {
            return Result.success(resolveCompletedTrick(state, playersWithUpdatedHand, updatedTrickPlays))
        }

        // الانتقال للاعب التالي في الأكلة
        val nextSeat = (state.currentTurnSeatId + 1) % 5
        return Result.success(
            state.copy(
                players = playersWithUpdatedHand,
                currentTrickPlays = updatedTrickPlays,
                currentTurnSeatId = nextSeat,
                serverTimestamp = System.currentTimeMillis(),
                lastActionLog = "لعب ${currentP.username} كرت ${playedCard.suit.symbol} ${playedCard.rank.arabicName}"
            )
        )
    }

    private fun resolveCompletedTrick(
        state: AuthoritativeGameState,
        players: List<AuthoritativePlayer>,
        trickPlays: List<AuthoritativeTrickPlay>
    ): AuthoritativeGameState {
        val deck = TirbGameLogic.createDeck()
        val trumpSuit = state.trumpSuit?.let { runCatching { Suit.valueOf(it) }.getOrNull() } ?: Suit.CLUBS
        val leadingSuit = deck.find { it.id == trickPlays.firstOrNull()?.cardId }?.suit ?: Suit.CLUBS

        val playsWithCards = trickPlays.map { tp ->
            val card = deck.find { it.id == tp.cardId } ?: Card(tp.cardId, Suit.SPADES, Rank.SIX, 0)
            TrickPlay(tp.seatId, tp.playerName, card)
        }

        val winningPlay = TirbGameLogic.determineTrickWinner(playsWithCards, leadingSuit, trumpSuit)
        val trickPoints = playsWithCards.sumOf { it.card.points }

        val updatedPlayers = players.map { p ->
            if (p.seatId == winningPlay.playerId) {
                p.copy(
                    pointsWon = p.pointsWon + trickPoints,
                    tricksWon = p.tricksWon + 1
                )
            } else p
        }

        // هل انتهت الـ 7 أكلات للجولة الحالية؟
        if (state.currentTrickNumber >= 7) {
            return resolveCompletedRound(state, updatedPlayers, trickPlays, winningPlay.playerId)
        }

        // بدء أكلة جديدة
        return state.copy(
            players = updatedPlayers,
            currentTrickPlays = emptyList(),
            lastTrickPlays = trickPlays,
            lastTrickWinnerSeatId = winningPlay.playerId,
            currentTurnSeatId = winningPlay.playerId,
            starterSeatId = winningPlay.playerId,
            currentTrickNumber = state.currentTrickNumber + 1,
            serverTimestamp = System.currentTimeMillis(),
            lastActionLog = "أكل ${winningPlay.playerName} الأكلة ونال $trickPoints نقطة! يقود الأكلة التالية."
        )
    }

    private fun resolveCompletedRound(
        state: AuthoritativeGameState,
        players: List<AuthoritativePlayer>,
        lastTrick: List<AuthoritativeTrickPlay>,
        lastWinnerSeat: Int
    ): AuthoritativeGameState {
        val buyerSeat = state.buyerSeatId ?: 0
        val buyer = players.find { it.seatId == buyerSeat } ?: players.first()
        val isBuyerWon = buyer.pointsWon >= state.winningBid

        val finalPlayers = players.map { p ->
            if (p.seatId == buyerSeat) {
                if (isBuyerWon) p.copy(redCards = p.redCards + 1)
                else p.copy(blackCards = p.blackCards + 1)
            } else p
        }

        val tournamentWinner = finalPlayers.find { it.redCards >= 2 }
        val nextDealer = (state.dealerSeatId + 1) % 5

        return if (tournamentWinner != null) {
            state.copy(
                phase = "MATCH_OVER",
                players = finalPlayers,
                lastTrickPlays = lastTrick,
                lastTrickWinnerSeatId = lastWinnerSeat,
                serverTimestamp = System.currentTimeMillis(),
                lastActionLog = "👑 فاز ${tournamentWinner.username} بالبطولة لحصوله على كرتين حمر!"
            )
        } else {
            val resultMsg = if (isBuyerWon) {
                "فاز المشتري ${buyer.username} بحصوله على ${buyer.pointsWon}/${state.winningBid} ونال كرت أحمر 🟥!"
            } else {
                "سقط المشتري ${buyer.username} بـ ${buyer.pointsWon}/${state.winningBid} ونال كرت أسود ⬛!"
            }

            state.copy(
                phase = "ROUND_OVER",
                players = finalPlayers,
                lastTrickPlays = lastTrick,
                lastTrickWinnerSeatId = lastWinnerSeat,
                dealerSeatId = nextDealer,
                serverTimestamp = System.currentTimeMillis(),
                lastActionLog = resultMsg
            )
        }
    }

    private fun handleReconnect(
        state: AuthoritativeGameState,
        action: AuthoritativePlayerAction.Reconnect
    ): Result<AuthoritativeGameState> {
        val updated = state.players.map {
            if (it.uid == action.uid) it.copy(isConnected = true) else it
        }
        val p = updated.find { it.uid == action.uid }
        return Result.success(
            state.copy(
                players = updated,
                serverTimestamp = System.currentTimeMillis(),
                lastActionLog = "استعاد ${p?.username ?: "لاعب"} الاتصال بالطاولة 🟢"
            )
        )
    }

    private fun handleDisconnect(
        state: AuthoritativeGameState,
        action: AuthoritativePlayerAction.Disconnect
    ): Result<AuthoritativeGameState> {
        val updated = state.players.map {
            if (it.uid == action.uid) it.copy(isConnected = false) else it
        }
        val p = updated.find { it.uid == action.uid }
        return Result.success(
            state.copy(
                players = updated,
                serverTimestamp = System.currentTimeMillis(),
                lastActionLog = "انقطع اتصال ${p?.username ?: "لاعب"} ⚪ بانتظار عودته"
            )
        )
    }
}
