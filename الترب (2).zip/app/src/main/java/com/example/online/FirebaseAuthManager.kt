package com.example.online

import android.content.Context
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.GetCredentialException
import com.example.profile.UserProfileManager
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.security.MessageDigest
import java.util.UUID

/**
 * حالة مصادقة اللاعب عبر Firebase Auth
 */
data class AuthState(
    val isLoggedIn: Boolean = false,
    val isAnonymous: Boolean = true,
    val uid: String = "",
    val displayName: String = "لاعب_الترب",
    val email: String? = null,
    val photoUrl: String? = null,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val isFirebaseAvailable: Boolean = true
)

/**
 * مدير المصادقة الموحد عبر Firebase Authentication (Google ومجهول)
 * متوافق بنسبة 100% مع Credential Manager وإمكانية العمل دون اتصال
 */
object FirebaseAuthManager {

    private const val TAG = "FirebaseAuthManager"

    private val _authState = MutableStateFlow(AuthState())
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private var firebaseAuth: FirebaseAuth? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    fun init(context: Context) {
        try {
            if (FirebaseApp.getApps(context).isNotEmpty()) {
                val auth = FirebaseAuth.getInstance()
                firebaseAuth = auth
                auth.addAuthStateListener { fa ->
                    val user = fa.currentUser
                    updateStateFromUser(user)
                }
                updateStateFromUser(auth.currentUser)
            } else {
                Log.w(TAG, "FirebaseApp is not initialized yet. Using local guest auth mode.")
                _authState.value = _authState.value.copy(
                    isFirebaseAvailable = false,
                    isLoggedIn = true,
                    isAnonymous = true,
                    uid = UserProfileManager.profile.value.playerId,
                    displayName = UserProfileManager.profile.value.username
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Firebase Auth init failed, fallback to local guest session", e)
            _authState.value = _authState.value.copy(
                isFirebaseAvailable = false,
                isLoggedIn = true,
                isAnonymous = true,
                uid = UserProfileManager.profile.value.playerId,
                displayName = UserProfileManager.profile.value.username
            )
        }
    }

    private fun updateStateFromUser(user: FirebaseUser?) {
        if (user != null) {
            val name = user.displayName?.ifBlank { null }
                ?: if (user.isAnonymous) "ضيف_الترب_${user.uid.takeLast(4)}" else "لاعب_الترب"
            _authState.value = AuthState(
                isLoggedIn = true,
                isAnonymous = user.isAnonymous,
                uid = user.uid,
                displayName = name,
                email = user.email,
                photoUrl = user.photoUrl?.toString(),
                isLoading = false,
                errorMessage = null,
                isFirebaseAvailable = true
            )
            // مزامنة الاسم والمعرف مع الملف الشخصي للمستخدم
            UserProfileManager.updateUsernameFromAuth(name, "#TRB-${user.uid.take(4).uppercase()}")
        } else {
            val fallbackUid = UserProfileManager.profile.value.playerId
            val fallbackName = UserProfileManager.profile.value.username
            _authState.value = AuthState(
                isLoggedIn = false,
                isAnonymous = true,
                uid = fallbackUid,
                displayName = fallbackName,
                isLoading = false,
                isFirebaseAvailable = firebaseAuth != null
            )
        }
    }

    /**
     * تسجيل دخول مجهول (Anonymous / Guest)
     */
    fun signInAnonymously(onComplete: (Boolean, String?) -> Unit = { _, _ -> }) {
        _authState.value = _authState.value.copy(isLoading = true, errorMessage = null)
        val auth = firebaseAuth
        if (auth == null) {
            // جلسة ضيف محلية
            _authState.value = _authState.value.copy(
                isLoggedIn = true,
                isAnonymous = true,
                isLoading = false,
                uid = UserProfileManager.profile.value.playerId,
                displayName = UserProfileManager.profile.value.username
            )
            onComplete(true, "تم الدخول كضيف محلياً بنجاح")
            return
        }

        scope.launch {
            try {
                val result = auth.signInAnonymously().await()
                updateStateFromUser(result.user)
                onComplete(true, null)
            } catch (e: Exception) {
                Log.e(TAG, "Anonymous sign-in error", e)
                _authState.value = _authState.value.copy(
                    isLoading = false,
                    errorMessage = e.localizedMessage ?: "فشل تسجيل الدخول كضيف"
                )
                onComplete(false, e.localizedMessage)
            }
        }
    }

    /**
     * تسجيل الدخول عبر حساب Google باستخدام Credential Manager
     */
    fun signInWithGoogle(context: Context, serverClientId: String = "", onComplete: (Boolean, String?) -> Unit = { _, _ -> }) {
        _authState.value = _authState.value.copy(isLoading = true, errorMessage = null)
        val auth = firebaseAuth

        if (auth == null || serverClientId.isBlank()) {
            // إذا لم يتم توفير serverClientId أو غاب تكوين Firebase، نعتمد جلسة الضيف الآمنة
            Log.w(TAG, "Server client ID empty or Firebase unavailable. Fallback to guest.")
            signInAnonymously(onComplete)
            return
        }

        scope.launch {
            try {
                val credentialManager = CredentialManager.create(context)
                val rawNonce = UUID.randomUUID().toString()
                val bytes = rawNonce.toByteArray()
                val md = MessageDigest.getInstance("SHA-256")
                val digest = md.digest(bytes)
                val hashedNonce = digest.fold("") { str, it -> str + "%02x".format(it) }

                val googleIdOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(serverClientId)
                    .setAutoSelectEnabled(false)
                    .setNonce(hashedNonce)
                    .build()

                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(googleIdOption)
                    .build()

                val result: GetCredentialResponse = credentialManager.getCredential(
                    request = request,
                    context = context
                )

                val credential = result.credential
                if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                    val idToken = googleIdTokenCredential.idToken

                    val firebaseCredential = GoogleAuthProvider.getCredential(idToken, null)
                    val authResult = auth.signInWithCredential(firebaseCredential).await()
                    updateStateFromUser(authResult.user)
                    onComplete(true, "تم تسجيل الدخول بنجاح بحساب Google")
                } else {
                    _authState.value = _authState.value.copy(isLoading = false, errorMessage = "نوع الاعتماد غير مدعوم")
                    onComplete(false, "نوع الاعتماد غير مدعوم")
                }
            } catch (e: GetCredentialException) {
                Log.e(TAG, "Credential Manager error", e)
                _authState.value = _authState.value.copy(isLoading = false, errorMessage = e.localizedMessage)
                onComplete(false, e.localizedMessage)
            } catch (e: Exception) {
                Log.e(TAG, "Google sign in error", e)
                _authState.value = _authState.value.copy(isLoading = false, errorMessage = e.localizedMessage)
                onComplete(false, e.localizedMessage)
            }
        }
    }

    /**
     * تسجيل الخروج
     */
    fun signOut() {
        try {
            firebaseAuth?.signOut()
        } catch (e: Exception) {
            Log.e(TAG, "Sign out error", e)
        }
        updateStateFromUser(null)
    }
}
