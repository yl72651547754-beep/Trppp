package com.example.online

import android.content.Context
import android.util.Log
import com.example.model.Card
import com.example.model.Suit
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlin.random.Random

/**
 * بيانات غرفة اللعب المتعدد التنافسي
 */
data class CompetitiveOnlineRoom(
    val roomId: String = "",
    val roomCode: String = "",
    val roomName: String = "",
    val hostUid: String = "",
    val hostName: String = "",
    val inviteLink: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val isGameStarted: Boolean = false,
    val connectedPlayersCount: Int = 0,
    val gameState: AuthoritativeGameState = AuthoritativeGameState()
)

/**
 * سجل نتيجة مباراة تنافسية في لوحة الصدارة
 */
data class CompetitiveMatchRecord(
    val id: String = "",
    val matchId: String = "",
    val winnerUid: String = "",
    val winnerName: String = "",
    val redCards: Int = 2,
    val winningBid: Int = 100,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * خدمة المطابقة (Matchmaking) والربط مع Firestore والخادم الحاكم
 */
object FirestoreMatchmakingService {

    private const val TAG = "FirestoreMatchmaking"
    private const val COLLECTION_ROOMS = "rooms"
    private const val COLLECTION_LEADERBOARD = "leaderboard"

    private val _currentRoom = MutableStateFlow<CompetitiveOnlineRoom?>(null)
    val currentRoom: StateFlow<CompetitiveOnlineRoom?> = _currentRoom.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _statusMessage = MutableStateFlow("")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private val _activePublicRooms = MutableStateFlow<List<CompetitiveOnlineRoom>>(emptyList())
    val activePublicRooms: StateFlow<List<CompetitiveOnlineRoom>> = _activePublicRooms.asStateFlow()

    private val _competitiveLeaderboard = MutableStateFlow<List<CompetitiveMatchRecord>>(emptyList())
    val competitiveLeaderboard: StateFlow<List<CompetitiveMatchRecord>> = _competitiveLeaderboard.asStateFlow()

    private var firestore: FirebaseFirestore? = null
    private var roomListener: ListenerRegistration? = null
    private var publicRoomsListener: ListenerRegistration? = null
    private var leaderboardListener: ListenerRegistration? = null
    private var heartbeatJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    fun init(context: Context) {
        try {
            if (FirebaseApp.getApps(context).isNotEmpty()) {
                firestore = FirebaseFirestore.getInstance()
                listenToActiveRooms()
                listenToLeaderboard()
            } else {
                Log.w(TAG, "FirebaseApp not initialized, using Authoritative Local Host Engine")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Firestore init failed, using Authoritative Local Host fallback", e)
        }
    }

    /**
     * الاستماع لسجل نتائج المباريات في لوحة الصدارة بالسيرفر
     */
    fun listenToLeaderboard() {
        val fs = firestore ?: return
        leaderboardListener?.remove()
        leaderboardListener = fs.collection(COLLECTION_LEADERBOARD)
            .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .limit(30)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Listen leaderboard error", error)
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val records = snapshot.documents.mapNotNull { doc ->
                        try {
                            CompetitiveMatchRecord(
                                id = doc.id,
                                matchId = doc.getString("matchId") ?: "",
                                winnerUid = doc.getString("winnerUid") ?: "",
                                winnerName = doc.getString("winnerName") ?: "بطل_الترب",
                                redCards = doc.getLong("redCards")?.toInt() ?: 2,
                                winningBid = doc.getLong("winningBid")?.toInt() ?: 100,
                                timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis()
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    _competitiveLeaderboard.value = records
                }
            }
    }

    /**
     * الاستماع للغرف المتاحة على السيرفر
     */
    private fun listenToActiveRooms() {
        val fs = firestore ?: return
        publicRoomsListener?.remove()
        publicRoomsListener = fs.collection(COLLECTION_ROOMS)
            .whereEqualTo("isGameStarted", false)
            .limit(20)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Listen active rooms error", error)
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val rooms = snapshot.documents.mapNotNull { doc ->
                        try {
                            docToCompetitiveRoom(doc)
                        } catch (e: Exception) {
                            null
                        }
                    }
                    _activePublicRooms.value = rooms
                }
            }
    }

    /**
     * إنشاء مباراة جديدة وتوليد رمز دعوة قصير ورابط فريد
     */
    fun createMatch(
        roomName: String,
        hostUid: String,
        hostName: String,
        avatarEmoji: String,
        avatarId: Int,
        onResult: (Boolean, String) -> Unit
    ) {
        _isLoading.value = true
        _statusMessage.value = "جاري إنشاء الغرفة على السيرفر..."

        val randomCode = generateShortRoomCode()
        val uniqueInviteLink = "https://tirb-game.web.app/join/$randomCode"

        val initialEngineState = AuthoritativeGameState(
            matchId = randomCode,
            phase = "LOBBY",
            players = listOf(
                AuthoritativePlayer(
                    uid = hostUid,
                    seatId = 0,
                    username = hostName,
                    avatarEmoji = avatarEmoji,
                    avatarId = avatarId,
                    isHost = true,
                    isConnected = true,
                    isReady = true
                )
            ),
            lastActionLog = "تم إنشاء الغرفة بواسطة $hostName"
        )

        val roomData = CompetitiveOnlineRoom(
            roomId = randomCode,
            roomCode = randomCode,
            roomName = roomName.ifBlank { "طاولة التحدي $randomCode" },
            hostUid = hostUid,
            hostName = hostName,
            inviteLink = uniqueInviteLink,
            createdAt = System.currentTimeMillis(),
            isGameStarted = false,
            connectedPlayersCount = 1,
            gameState = initialEngineState
        )

        val fs = firestore
        if (fs == null) {
            // محلياً عبر المحرك الحاكم الداخلي
            _currentRoom.value = roomData
            _isLoading.value = false
            _statusMessage.value = "تم إنشاء الغرفة بنجاح! رمز الدعوة: $randomCode"
            startHeartbeat(randomCode, hostUid)
            onResult(true, randomCode)
            return
        }

        scope.launch {
            try {
                val docMap = roomToMap(roomData)
                fs.collection(COLLECTION_ROOMS).document(randomCode).set(docMap).await()
                _currentRoom.value = roomData
                listenToRoom(randomCode)
                startHeartbeat(randomCode, hostUid)
                _isLoading.value = false
                _statusMessage.value = "تم إنشاء الغرفة برمز: $randomCode"
                onResult(true, randomCode)
            } catch (e: Exception) {
                Log.e(TAG, "Error creating room in Firestore", e)
                // Fallback to local authoritative room
                _currentRoom.value = roomData
                _isLoading.value = false
                _statusMessage.value = "تم إنشاء الغرفة محلياً! الرمز: $randomCode"
                onResult(true, randomCode)
            }
        }
    }

    /**
     * الانضمام لغرفة عبر رمز الدعوة
     */
    fun joinMatch(
        inputCode: String,
        userUid: String,
        userName: String,
        avatarEmoji: String,
        avatarId: Int,
        onResult: (Boolean, String) -> Unit
    ) {
        val cleanCode = inputCode.trim().uppercase()
            .removePrefix("#")
            .let { if (it.all { c -> c.isDigit() }) "TRB-$it" else it }

        if (cleanCode.isBlank()) {
            onResult(false, "يرجى إدخال رمز الدعوة")
            return
        }

        _isLoading.value = true
        _statusMessage.value = "جاري التحقق من رمز الغرفة $cleanCode..."

        val fs = firestore
        if (fs == null) {
            val localRoom = _currentRoom.value
            if (localRoom != null && (localRoom.roomCode == cleanCode || localRoom.roomId == cleanCode)) {
                val action = AuthoritativePlayerAction.JoinLobby(userUid, userName, avatarEmoji, avatarId)
                val newEngineResult = AuthoritativeGameEngine.processAction(localRoom.gameState, action)
                if (newEngineResult.isSuccess) {
                    val updatedState = newEngineResult.getOrThrow()
                    _currentRoom.value = localRoom.copy(
                        gameState = updatedState,
                        connectedPlayersCount = updatedState.players.count { it.isConnected }
                    )
                    startHeartbeat(cleanCode, userUid)
                    _isLoading.value = false
                    onResult(true, "تم الانضمام للغرفة بنجاح")
                } else {
                    _isLoading.value = false
                    onResult(false, newEngineResult.exceptionOrNull()?.message ?: "تعذر الانضمام")
                }
            } else {
                _isLoading.value = false
                onResult(false, "الغرفة $cleanCode غير موجودة أو انتهت")
            }
            return
        }

        scope.launch {
            try {
                val doc = fs.collection(COLLECTION_ROOMS).document(cleanCode).get().await()
                if (!doc.exists()) {
                    _isLoading.value = false
                    _statusMessage.value = "الغرفة غير موجودة"
                    onResult(false, "لم يتم العثور على غرفة بالرمز: $cleanCode")
                    return@launch
                }

                val currentRoomObj = docToCompetitiveRoom(doc)
                if (currentRoomObj == null) {
                    _isLoading.value = false
                    onResult(false, "تعذر قراءة بيانات الغرفة")
                    return@launch
                }

                val action = AuthoritativePlayerAction.JoinLobby(userUid, userName, avatarEmoji, avatarId)
                val newEngineResult = AuthoritativeGameEngine.processAction(currentRoomObj.gameState, action)
                if (newEngineResult.isFailure) {
                    _isLoading.value = false
                    onResult(false, newEngineResult.exceptionOrNull()?.message ?: "الغرفة ممتلئة")
                    return@launch
                }

                val updatedEngine = newEngineResult.getOrThrow()
                val updatedRoom = currentRoomObj.copy(
                    gameState = updatedEngine,
                    connectedPlayersCount = updatedEngine.players.count { it.isConnected }
                )

                fs.collection(COLLECTION_ROOMS).document(cleanCode).set(roomToMap(updatedRoom), SetOptions.merge()).await()
                _currentRoom.value = updatedRoom
                listenToRoom(cleanCode)
                startHeartbeat(cleanCode, userUid)
                _isLoading.value = false
                _statusMessage.value = "تم الانضمام للغرفة $cleanCode"
                onResult(true, "تم الانضمام بنجاح")
            } catch (e: Exception) {
                Log.e(TAG, "Join room error", e)
                _isLoading.value = false
                _statusMessage.value = "فشل الاتصال بالسيرفر"
                onResult(false, e.localizedMessage ?: "فشل الانضمام للغرفة")
            }
        }
    }

    /**
     * إرسال حركة لاعب إلى الخادم الحاكم لتنفيذها والتحقق منها
     */
    fun dispatchAction(action: AuthoritativePlayerAction, onResult: (Boolean, String?) -> Unit = { _, _ -> }) {
        val room = _currentRoom.value
        if (room == null) {
            onResult(false, "لا توجد غرفة نشطة")
            return
        }

        val result = AuthoritativeGameEngine.processAction(room.gameState, action)
        if (result.isFailure) {
            val err = result.exceptionOrNull()?.message ?: "حركة غير مقبولة"
            _statusMessage.value = err
            onResult(false, err)
            return
        }

        val updatedState = result.getOrThrow()
        val updatedRoom = room.copy(
            gameState = updatedState,
            isGameStarted = updatedState.phase != "LOBBY",
            connectedPlayersCount = updatedState.players.count { it.isConnected }
        )
        _currentRoom.value = updatedRoom

        // إذا انتهت المباراة، نقوم بحفظ النتيجة في لوحة الصدارة
        if (updatedState.phase == "MATCH_OVER") {
            saveMatchResultToLeaderboard(updatedRoom)
        }

        val fs = firestore
        if (fs != null) {
            scope.launch {
                try {
                    fs.collection(COLLECTION_ROOMS).document(room.roomId)
                        .set(roomToMap(updatedRoom), SetOptions.merge())
                    onResult(true, null)
                } catch (e: Exception) {
                    Log.e(TAG, "Sync action to firestore failed", e)
                    onResult(true, null) // يعمل محلياً في حالة فقد الاتصال
                }
            }
        } else {
            onResult(true, null)
        }
    }

    /**
     * الاستماع لتحديثات الغرفة اللحظية في Firestore
     */
    private fun listenToRoom(roomId: String) {
        val fs = firestore ?: return
        roomListener?.remove()
        roomListener = fs.collection(COLLECTION_ROOMS).document(roomId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Room listener error", error)
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    val updated = docToCompetitiveRoom(snapshot)
                    if (updated != null) {
                        _currentRoom.value = updated
                    }
                }
            }
    }

    /**
     * نظام استشعار نبض الاتصال (Heartbeat) ومعالجة انقطاع الاتصال وإعادة الاتصال
     */
    private fun startHeartbeat(roomId: String, uid: String) {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            while (isActive) {
                delay(8000) // كل 8 ثوانٍ
                val fs = firestore
                if (fs != null) {
                    try {
                        val updateMap = mapOf(
                            "lastSeen_${uid}" to System.currentTimeMillis()
                        )
                        fs.collection(COLLECTION_ROOMS).document(roomId).set(updateMap, SetOptions.merge())
                    } catch (e: Exception) {
                        Log.w(TAG, "Heartbeat failed", e)
                    }
                }
            }
        }
    }

    /**
     * مغادرة الغرفة الحالية
     */
    fun leaveCurrentRoom(userUid: String) {
        heartbeatJob?.cancel()
        roomListener?.remove()
        val room = _currentRoom.value ?: return

        dispatchAction(AuthoritativePlayerAction.Disconnect(userUid))
        _currentRoom.value = null
        _statusMessage.value = "تمت مغادرة الغرفة"
    }

    /**
     * حفظ نتائج المباراة في لوحة الصدارة بالسيرفر
     */
    private fun saveMatchResultToLeaderboard(room: CompetitiveOnlineRoom) {
        val winner = room.gameState.players.find { it.redCards >= 2 } ?: return
        val newRecord = CompetitiveMatchRecord(
            id = "local_${System.currentTimeMillis()}",
            matchId = room.roomId,
            winnerUid = winner.uid,
            winnerName = winner.username,
            redCards = winner.redCards,
            winningBid = room.gameState.winningBid,
            timestamp = System.currentTimeMillis()
        )
        _competitiveLeaderboard.value = listOf(newRecord) + _competitiveLeaderboard.value.take(29)

        val fs = firestore ?: return
        scope.launch {
            try {
                val record = mapOf(
                    "matchId" to room.roomId,
                    "winnerUid" to winner.uid,
                    "winnerName" to winner.username,
                    "redCards" to winner.redCards,
                    "winningBid" to room.gameState.winningBid,
                    "timestamp" to System.currentTimeMillis(),
                    "players" to room.gameState.players.map {
                        mapOf(
                            "uid" to it.uid,
                            "name" to it.username,
                            "redCards" to it.redCards,
                            "blackCards" to it.blackCards,
                            "pointsWon" to it.pointsWon
                        )
                    }
                )
                fs.collection(COLLECTION_LEADERBOARD).add(record)
            } catch (e: Exception) {
                Log.e(TAG, "Save leaderboard record error", e)
            }
        }
    }

    private fun generateShortRoomCode(): String {
        return "TRB-${Random.nextInt(1000, 9999)}"
    }

    private fun roomToMap(room: CompetitiveOnlineRoom): Map<String, Any?> {
        val gs = room.gameState
        return mapOf(
            "roomId" to room.roomId,
            "roomCode" to room.roomCode,
            "roomName" to room.roomName,
            "hostUid" to room.hostUid,
            "hostName" to room.hostName,
            "inviteLink" to room.inviteLink,
            "createdAt" to room.createdAt,
            "isGameStarted" to room.isGameStarted,
            "connectedPlayersCount" to room.connectedPlayersCount,
            "gameState" to mapOf(
                "matchId" to gs.matchId,
                "phase" to gs.phase,
                "matchRoundNumber" to gs.matchRoundNumber,
                "dealerSeatId" to gs.dealerSeatId,
                "currentTurnSeatId" to gs.currentTurnSeatId,
                "starterSeatId" to gs.starterSeatId,
                "currentAuctionBid" to gs.currentAuctionBid,
                "winningBid" to gs.winningBid,
                "buyerSeatId" to gs.buyerSeatId,
                "trumpSuit" to gs.trumpSuit,
                "fieldCards" to gs.fieldCards,
                "currentTrickPlays" to gs.currentTrickPlays.map {
                    mapOf("seatId" to it.seatId, "cardId" to it.cardId, "playerName" to it.playerName)
                },
                "lastTrickPlays" to gs.lastTrickPlays.map {
                    mapOf("seatId" to it.seatId, "cardId" to it.cardId, "playerName" to it.playerName)
                },
                "lastTrickWinnerSeatId" to gs.lastTrickWinnerSeatId,
                "currentTrickNumber" to gs.currentTrickNumber,
                "lastActionLog" to gs.lastActionLog,
                "serverTimestamp" to gs.serverTimestamp,
                "players" to gs.players.map { p ->
                    mapOf(
                        "uid" to p.uid,
                        "seatId" to p.seatId,
                        "username" to p.username,
                        "avatarEmoji" to p.avatarEmoji,
                        "avatarId" to p.avatarId,
                        "hand" to p.hand,
                        "currentBid" to p.currentBid,
                        "hasPassed" to p.hasPassed,
                        "pointsWon" to p.pointsWon,
                        "tricksWon" to p.tricksWon,
                        "redCards" to p.redCards,
                        "blackCards" to p.blackCards,
                        "isExemptFromAuction" to p.isExemptFromAuction,
                        "isConnected" to p.isConnected,
                        "isReady" to p.isReady,
                        "isHost" to p.isHost
                    )
                }
            )
        )
    }

    @Suppress("UNCHECKED_CAST")
    private fun docToCompetitiveRoom(doc: com.google.firebase.firestore.DocumentSnapshot): CompetitiveOnlineRoom? {
        return try {
            val roomId = doc.getString("roomId") ?: doc.id
            val roomCode = doc.getString("roomCode") ?: roomId
            val roomName = doc.getString("roomName") ?: "طاولة الترب"
            val hostUid = doc.getString("hostUid") ?: ""
            val hostName = doc.getString("hostName") ?: "المستضيف"
            val inviteLink = doc.getString("inviteLink") ?: ""
            val createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis()
            val isGameStarted = doc.getBoolean("isGameStarted") ?: false
            val connectedCount = doc.getLong("connectedPlayersCount")?.toInt() ?: 1

            val gsMap = doc.get("gameState") as? Map<String, Any?> ?: emptyMap()
            val phase = gsMap["phase"] as? String ?: "LOBBY"
            val roundNum = (gsMap["matchRoundNumber"] as? Long)?.toInt() ?: 1
            val dealerSeat = (gsMap["dealerSeatId"] as? Long)?.toInt() ?: 0
            val currentTurn = (gsMap["currentTurnSeatId"] as? Long)?.toInt() ?: 0
            val starterSeat = (gsMap["starterSeatId"] as? Long)?.toInt() ?: 0
            val currentAuctionBid = (gsMap["currentAuctionBid"] as? Long)?.toInt() ?: 0
            val winningBid = (gsMap["winningBid"] as? Long)?.toInt() ?: 0
            val buyerSeat = (gsMap["buyerSeatId"] as? Long)?.toInt()
            val trumpSuit = gsMap["trumpSuit"] as? String
            val fieldCards = (gsMap["fieldCards"] as? List<String>) ?: emptyList()
            val trickNum = (gsMap["currentTrickNumber"] as? Long)?.toInt() ?: 1
            val log = gsMap["lastActionLog"] as? String ?: ""
            val lastWinner = (gsMap["lastTrickWinnerSeatId"] as? Long)?.toInt()

            val rawCurrentTricks = (gsMap["currentTrickPlays"] as? List<Map<String, Any?>>) ?: emptyList()
            val currentTricks = rawCurrentTricks.map {
                AuthoritativeTrickPlay(
                    seatId = (it["seatId"] as? Long)?.toInt() ?: 0,
                    cardId = it["cardId"] as? String ?: "",
                    playerName = it["playerName"] as? String ?: ""
                )
            }

            val rawLastTricks = (gsMap["lastTrickPlays"] as? List<Map<String, Any?>>) ?: emptyList()
            val lastTricks = rawLastTricks.map {
                AuthoritativeTrickPlay(
                    seatId = (it["seatId"] as? Long)?.toInt() ?: 0,
                    cardId = it["cardId"] as? String ?: "",
                    playerName = it["playerName"] as? String ?: ""
                )
            }

            val rawPlayers = (gsMap["players"] as? List<Map<String, Any?>>) ?: emptyList()
            val playersList = rawPlayers.map { pMap ->
                AuthoritativePlayer(
                    uid = pMap["uid"] as? String ?: "",
                    seatId = (pMap["seatId"] as? Long)?.toInt() ?: 0,
                    username = pMap["username"] as? String ?: "لاعب",
                    avatarEmoji = pMap["avatarEmoji"] as? String ?: "🎴",
                    avatarId = (pMap["avatarId"] as? Long)?.toInt() ?: 0,
                    hand = (pMap["hand"] as? List<String>) ?: emptyList(),
                    currentBid = (pMap["currentBid"] as? Long)?.toInt() ?: 0,
                    hasPassed = pMap["hasPassed"] as? Boolean ?: false,
                    pointsWon = (pMap["pointsWon"] as? Long)?.toInt() ?: 0,
                    tricksWon = (pMap["tricksWon"] as? Long)?.toInt() ?: 0,
                    redCards = (pMap["redCards"] as? Long)?.toInt() ?: 0,
                    blackCards = (pMap["blackCards"] as? Long)?.toInt() ?: 0,
                    isExemptFromAuction = pMap["isExemptFromAuction"] as? Boolean ?: false,
                    isConnected = pMap["isConnected"] as? Boolean ?: true,
                    isReady = pMap["isReady"] as? Boolean ?: false,
                    isHost = pMap["isHost"] as? Boolean ?: false
                )
            }

            val engineState = AuthoritativeGameState(
                matchId = roomId,
                phase = phase,
                matchRoundNumber = roundNum,
                dealerSeatId = dealerSeat,
                currentTurnSeatId = currentTurn,
                starterSeatId = starterSeat,
                currentAuctionBid = currentAuctionBid,
                winningBid = winningBid,
                buyerSeatId = buyerSeat,
                trumpSuit = trumpSuit,
                fieldCards = fieldCards,
                currentTrickPlays = currentTricks,
                lastTrickPlays = lastTricks,
                lastTrickWinnerSeatId = lastWinner,
                currentTrickNumber = trickNum,
                players = playersList,
                serverTimestamp = (gsMap["serverTimestamp"] as? Long) ?: System.currentTimeMillis(),
                lastActionLog = log
            )

            CompetitiveOnlineRoom(
                roomId = roomId,
                roomCode = roomCode,
                roomName = roomName,
                hostUid = hostUid,
                hostName = hostName,
                inviteLink = inviteLink,
                createdAt = createdAt,
                isGameStarted = isGameStarted,
                connectedPlayersCount = connectedCount,
                gameState = engineState
            )
        } catch (e: Exception) {
            Log.e(TAG, "docToCompetitiveRoom parse error", e)
            null
        }
    }
}
