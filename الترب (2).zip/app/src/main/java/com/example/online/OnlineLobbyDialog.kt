package com.example.online

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.friends.FriendInviteStatus
import com.example.friends.PlayerDirectoryService
import com.example.friends.PlayerSearchResult
import com.example.friends.SearchedPlayerProfile
import com.example.localization.LocalizationManager
import com.example.profile.UserProfile
import com.example.profile.UserProfileManager
import com.example.online.FirebaseAuthManager
import com.example.online.FirestoreMatchmakingService
import com.example.online.CompetitiveOnlineRoom
import com.example.online.AuthoritativePlayerAction
import com.example.online.AuthoritativePlayer
import android.content.Intent
import com.example.ui.theme.DangerRed
import com.example.ui.theme.FeltGreenDark
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceCardContainer
import com.example.ui.theme.SurfaceDarkNavy

/**
 * نافذة اللعب عبر الإنترنت ونظام السيرفرات المخصصة
 * تشمل:
 * 1. اللعب التنافسي المعتمد والمطابقة الحاكمة عبر Firebase و Cloud Run.
 * 2. سيرفرات اللعبة (إقليمية، سحابية، وسيرفر مخصص على الهاتف).
 * 3. الغرف والرومات أونلاين (إنشاء بكود، انضمام بكود، ومطابقة سريعة).
 * 4. الأصدقاء الحقيقيون والأونلاين.
 * 5. إضافة اللاعبين بالـ ID أو الاسم.
 */
@Composable
fun OnlineLobbyDialog(
    onDismiss: () -> Unit,
    onStartGame: (OnlineRoom) -> Unit,
    onStartCompetitiveMatch: (CompetitiveOnlineRoom) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val profile by UserProfileManager.profile.collectAsState()
    val authState by FirebaseAuthManager.authState.collectAsState()
    val competitiveRoom by FirestoreMatchmakingService.currentRoom.collectAsState()
    val matchmakingLoading by FirestoreMatchmakingService.isLoading.collectAsState()
    val matchmakingStatus by FirestoreMatchmakingService.statusMessage.collectAsState()
    val activeCompetitiveRooms by FirestoreMatchmakingService.activePublicRooms.collectAsState()

    val currentRoom by OnlineMultiplayerManager.currentRoom.collectAsState()
    val availableServers by OnlineMultiplayerManager.availableServers.collectAsState()
    val selectedServer by OnlineMultiplayerManager.selectedServer.collectAsState()
    val friendsList by OnlineMultiplayerManager.friendsList.collectAsState()
    val availableFriends by PlayerDirectoryService.availableFriendsToInvite.collectAsState()
    val publicRooms by OnlineMultiplayerManager.publicRooms.collectAsState()
    val connectionStatus by OnlineMultiplayerManager.connectionStatus.collectAsState()
    val isRtl = LocalizationManager.currentLanguage.collectAsState().value.isRtl

    var selectedTab by remember { mutableIntStateOf(0) } // 0: التنافس والمطابقة (Firebase), 1: السيرفرات, 2: الغرف, 3: الأصدقاء, 4: إضافة بالـ ID

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDarkNavy),
            border = BorderStroke(2.dp, GoldPrimary),
            elevation = CardDefaults.cardElevation(defaultElevation = 14.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Bar with Server Badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = FeltGreenDark,
                            border = BorderStroke(1.dp, GoldPrimary),
                            modifier = Modifier.size(34.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Public,
                                    contentDescription = "Online Multiplayer",
                                    tint = GoldLight,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = if (isRtl) "اللعب عبر الإنترنت والسيرفرات" else "Online Servers & Multiplayer",
                                color = GoldLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(SuccessGreen)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${selectedServer.flagEmoji} ${selectedServer.nameArabic} • ${selectedServer.pingMs}ms",
                                    color = SuccessGreen,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = GoldLight
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // حالة الغرفة النشطة: إن كان اللاعب داخل غرفة، نعرض ردهة المباراة
                if (currentRoom != null) {
                    RealActiveRoomLobbyView(
                        room = currentRoom!!,
                        currentUser = profile,
                        onAddBot = { OnlineMultiplayerManager.addBotToRoom() },
                        onRemovePlayer = { seatId -> OnlineMultiplayerManager.removePlayer(seatId) },
                        onToggleReady = { seatId -> OnlineMultiplayerManager.toggleReady(seatId) },
                        onSendMessage = { text -> OnlineMultiplayerManager.sendLobbyMessage(profile.username, text) },
                        onLeaveRoom = { OnlineMultiplayerManager.leaveRoom() },
                        onStartGame = {
                            OnlineMultiplayerManager.startGame()
                            currentRoom?.let { onStartGame(it) }
                            onDismiss()
                        },
                        isRtl = isRtl,
                        context = context
                    )
                } else {
                    // شريط هوية اللاعب والـ ID
                    RealPlayerIdentityBanner(profile = profile, isRtl = isRtl, context = context)

                    Spacer(modifier = Modifier.height(8.dp))

                    // تبويبات النظام الخمسة
                    TabRow(
                        selectedTabIndex = selectedTab,
                        containerColor = FeltGreenDark,
                        contentColor = GoldLight,
                        indicator = { tabPositions ->
                            TabRowDefaults.SecondaryIndicator(
                                modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                                color = GoldPrimary,
                                height = 3.dp
                            )
                        }
                    ) {
                        Tab(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            text = {
                                Text(
                                    text = if (isRtl) "🏆 التنافس" else "Compete",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        )
                        Tab(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            text = {
                                Text(
                                    text = if (isRtl) "🖥️ السيرفرات" else "Servers",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        )
                        Tab(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            text = {
                                Text(
                                    text = if (isRtl) "🌐 الغرف (${publicRooms.size})" else "Rooms",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        )
                        Tab(
                            selected = selectedTab == 3,
                            onClick = { selectedTab = 3 },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = if (isRtl) "👥 الأصدقاء" else "Friends",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    val availCount = availableFriends.count { it.inviteStatus == FriendInviteStatus.AVAILABLE }
                                    if (availCount > 0) {
                                        Spacer(modifier = Modifier.width(2.dp))
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = SuccessGreen
                                        ) {
                                            Text(
                                                text = "$availCount",
                                                color = Color.Black,
                                                fontSize = 7.sp,
                                                fontWeight = FontWeight.Black,
                                                modifier = Modifier.padding(horizontal = 3.dp, vertical = 0.5.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        )
                        Tab(
                            selected = selectedTab == 4,
                            onClick = { selectedTab = 4 },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Search, contentDescription = null, tint = GoldLight, modifier = Modifier.size(11.dp))
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text(
                                        text = if (isRtl) "بحث ID" else "Search",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    when (selectedTab) {
                        0 -> CompetitiveMatchmakingTab(
                            authState = authState,
                            competitiveRoom = competitiveRoom,
                            activeRooms = activeCompetitiveRooms,
                            isLoading = matchmakingLoading,
                            statusMessage = matchmakingStatus,
                            currentUser = profile,
                            onStartMatch = { compRoom ->
                                onStartCompetitiveMatch(compRoom)
                                onDismiss()
                            },
                            isRtl = isRtl,
                            context = context
                        )
                        1 -> GameServersTab(
                            servers = availableServers,
                            selectedServer = selectedServer,
                            onSelectServer = { OnlineMultiplayerManager.selectServer(it) },
                            onTestPing = { srv ->
                                OnlineMultiplayerManager.testServerPing(srv) { ms ->
                                    Toast.makeText(context, if (isRtl) "زمن الاستجابة: $ms مللي ثانية" else "Ping: ${ms}ms", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onAddCustomServer = { name, host, port ->
                                OnlineMultiplayerManager.addCustomServer(name, host, port)
                            },
                            isRtl = isRtl,
                            context = context
                        )
                        2 -> OnlineRoomsTab(
                            publicRooms = publicRooms,
                            currentUser = profile,
                            selectedServer = selectedServer,
                            connectionStatus = connectionStatus,
                            onCreateRoom = { name, isPrivate, customCode ->
                                OnlineMultiplayerManager.createRoom(name, isPrivate, profile, customCode)
                            },
                            onJoinRoom = { ipOrCode ->
                                OnlineMultiplayerManager.joinRoomByIpOrCode(ipOrCode, profile) { success, msg ->
                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                }
                            },
                            onQuickMatchmaking = {
                                OnlineMultiplayerManager.quickJoinMatchmaking(profile) { success, msg ->
                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                }
                            },
                            isRtl = isRtl,
                            context = context
                        )
                        3 -> RealFriendsTab(
                            availableFriends = availableFriends,
                            isRtl = isRtl,
                            currentRoom = currentRoom,
                            onInviteFriend = { friend ->
                                val roomCode = currentRoom?.roomId ?: ""
                                PlayerDirectoryService.inviteFriendToRound(friend.playerId, roomCode)
                                Toast.makeText(
                                    context,
                                    if (isRtl) "تم إرسال دعوة للجولة للصديق ${friend.username}! 📨" else "Invited ${friend.username} to match!",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            onInviteAll = {
                                val roomCode = currentRoom?.roomId ?: ""
                                val count = PlayerDirectoryService.inviteAllAvailableFriends(roomCode)
                                if (count > 0) {
                                    Toast.makeText(
                                        context,
                                        if (isRtl) "تم إرسال دعوة الجولة إلى جميع الأصدقاء المتاحين ($count) بنجاح! 🚀" else "Invited all $count available friends!",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                } else {
                                    Toast.makeText(
                                        context,
                                        if (isRtl) "تمت دعوة جميع الأصدقاء المتاحين مسبقاً" else "All available friends already invited",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            },
                            onRemoveFriend = { friend ->
                                PlayerDirectoryService.removeFriendFromDirectory(friend.playerId)
                                Toast.makeText(
                                    context,
                                    if (isRtl) "تمت إزالة ${friend.username} من قائمة الأصدقاء" else "Removed ${friend.username}",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            onSwitchToSearchTab = { selectedTab = 4 },
                            context = context
                        )
                        4 -> RealAddFriendByIdTab(
                            currentUser = profile,
                            currentRoom = currentRoom,
                            isRtl = isRtl,
                            onFriendAdded = { friend ->
                                Toast.makeText(
                                    context,
                                    if (isRtl) "تمت إضافة ${friend.username} كصديق بنجاح! 🎉" else "Added ${friend.username} as friend!",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            context = context
                        )
                    }
                }
            }
        }
    }
}

/**
 * تبويب السيرفرات المخصصة وخوادم اللعبة الإقليمية
 */
@Composable
private fun GameServersTab(
    servers: List<GameServer>,
    selectedServer: GameServer,
    onSelectServer: (GameServer) -> Unit,
    onTestPing: (GameServer) -> Unit,
    onAddCustomServer: (String, String, Int) -> Unit,
    isRtl: Boolean,
    context: Context
) {
    val isHostServerRunning by OnlineMultiplayerManager.isDedicatedServerRunning.collectAsState()
    val serverLogs by OnlineMultiplayerManager.dedicatedServerLogs.collectAsState()
    val connectedClients by OnlineMultiplayerManager.dedicatedServerClients.collectAsState()
    val isTestingPing by OnlineMultiplayerManager.isTestingPing.collectAsState()
    var showAddCustomDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 310.dp)
    ) {
        // بطاقة تشغيل سيرفر مخصص على الهاتف
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            color = if (isHostServerRunning) Color(0xFF0D251A) else SurfaceCardContainer,
            border = BorderStroke(1.dp, if (isHostServerRunning) SuccessGreen else GoldLight.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "🖥️", fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = if (isRtl) "تشغيل هاتفك كسيرفر مخصص (Dedicated Server)" else "Run this Phone as Dedicated Server",
                                color = GoldLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                            Text(
                                text = if (isHostServerRunning)
                                    "🟢 السيرفر شغال ويستقبل اتصالات اللاعبين (منفذ 8988)"
                                else
                                    if (isRtl) "استضافة رومات وبطولات مستقلة من جهازك" else "Host dedicated rooms & tournaments",
                                color = if (isHostServerRunning) SuccessGreen else Color.White.copy(alpha = 0.65f),
                                fontSize = 9.sp
                            )
                        }
                    }

                    Button(
                        onClick = {
                            if (isHostServerRunning) {
                                OnlineMultiplayerManager.stopDedicatedHostServer()
                                Toast.makeText(context, if (isRtl) "تم إيقاف السيرفر المخصص" else "Stopped Server", Toast.LENGTH_SHORT).show()
                            } else {
                                val ok = OnlineMultiplayerManager.startDedicatedHostServer(OnlineMultiplayerManager.DEFAULT_PORT)
                                if (ok) {
                                    Toast.makeText(context, if (isRtl) "تم تشغيل السيرفر المخصص بنجاح!" else "Server Started!", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        modifier = Modifier.height(30.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isHostServerRunning) DangerRed else SuccessGreen
                        ),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.PowerSettingsNew,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isHostServerRunning) (if (isRtl) "إيقاف" else "Stop") else (if (isRtl) "تشغيل السيرفر" else "Start"),
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }

                // تفاصيل السيرفر المخصص عند تشغيله
                AnimatedVisibility(visible = isHostServerRunning) {
                    val localIp = remember { OnlineMultiplayerManager.getDeviceLocalIp() }
                    Column(modifier = Modifier.padding(top = 8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "📡 IP الخادم: $localIp:8988",
                                color = SuccessGreen,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Button(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Server IP", "$localIp:8988"))
                                    Toast.makeText(context, if (isRtl) "تم نسخ عنوان السيرفر: $localIp:8988" else "Copied Server Address", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.height(24.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(text = if (isRtl) "نسخ بيانات السيرفر 📋" else "Copy IP", color = Color.Black, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // شريط السجل المباشر
                        if (serverLogs.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(42.dp),
                                shape = RoundedCornerShape(4.dp),
                                color = Color.Black.copy(alpha = 0.6f)
                            ) {
                                LazyColumn(modifier = Modifier.padding(4.dp)) {
                                    items(serverLogs.take(2)) { log ->
                                        Text(text = log, color = Color(0xFF81C784), fontSize = 8.5.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // رأس قائمة السيرفرات وزر إضافة سيرفر مخصص
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isRtl) "خوادم اللعبة الإقليمية والسحابية:" else "Regional Game Servers:",
                color = GoldLight,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Button(
                onClick = { showAddCustomDialog = true },
                modifier = Modifier.height(26.dp),
                colors = ButtonDefaults.buttonColors(containerColor = FeltGreenDark),
                border = BorderStroke(1.dp, GoldLight),
                shape = RoundedCornerShape(6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = GoldLight, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(text = if (isRtl) "سيرفر خاص VPS" else "Add Custom", color = GoldLight, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // قائمة السيرفرات المتاحة
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(servers) { server ->
                val isSelected = server.id == selectedServer.id
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectServer(server) },
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) Color(0xFF132A3A) else SurfaceCardContainer,
                    border = BorderStroke(if (isSelected) 1.5.dp else 1.dp, if (isSelected) GoldPrimary else Color.White.copy(alpha = 0.15f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = server.flagEmoji, fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = server.nameArabic,
                                        color = if (isSelected) GoldLight else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.5.sp
                                    )
                                    if (isSelected) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = GoldPrimary
                                        ) {
                                            Text(
                                                text = if (isRtl) "نشط" else "Active",
                                                color = Color.Black,
                                                fontSize = 7.5.sp,
                                                fontWeight = FontWeight.Black,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                }
                                Text(
                                    text = "${server.hostAddress}:${server.port} • ${server.activeRoomsCount} غرف نشطة",
                                    color = Color.White.copy(alpha = 0.65f),
                                    fontSize = 9.sp
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // مؤشر البينغ مع زر الفحص
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = when {
                                    server.pingMs < 40 -> SuccessGreen.copy(alpha = 0.2f)
                                    server.pingMs < 90 -> Color(0xFFFFB300).copy(alpha = 0.2f)
                                    else -> DangerRed.copy(alpha = 0.2f)
                                },
                                border = BorderStroke(0.6.dp, when {
                                    server.pingMs < 40 -> SuccessGreen
                                    server.pingMs < 90 -> Color(0xFFFFB300)
                                    else -> DangerRed
                                })
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${server.pingMs}ms",
                                        color = when {
                                            server.pingMs < 40 -> SuccessGreen
                                            server.pingMs < 90 -> Color(0xFFFFB300)
                                            else -> DangerRed
                                        },
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 9.5.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            IconButton(
                                onClick = { onTestPing(server) },
                                modifier = Modifier.size(26.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Test Ping",
                                    tint = GoldLight,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // نافذة إضافة سيرفر خاص
    if (showAddCustomDialog) {
        Dialog(onDismissRequest = { showAddCustomDialog = false }) {
            var serverName by remember { mutableStateOf("") }
            var serverHost by remember { mutableStateOf("") }
            var serverPort by remember { mutableStateOf("8988") }

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDarkNavy),
                border = BorderStroke(1.5.dp, GoldPrimary),
                modifier = Modifier.fillMaxWidth(0.92f)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (isRtl) "🌐 إضافة سيرفر سحابي خاص (VPS)" else "Add Custom Dedicated Server",
                        color = GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isRtl) "أدخل عنوان IP أو نطاق الخادم المخصص الخاص بك أو بمنظم البطولة" else "Enter VPS IP or Domain with game port",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 9.5.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = serverName,
                        onValueChange = { serverName = it },
                        label = { Text(if (isRtl) "اسم السيرفر" else "Server Name", fontSize = 10.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = serverHost,
                        onValueChange = { serverHost = it },
                        label = { Text(if (isRtl) "عنوان IP أو الدومين (مثال: 159.65.120.44)" else "IP or Domain", fontSize = 10.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = serverPort,
                        onValueChange = { serverPort = it },
                        label = { Text(if (isRtl) "المنفذ (الافتراضي 8988)" else "Port (Default 8988)", fontSize = 10.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { showAddCustomDialog = false },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)
                        ) {
                            Text(if (isRtl) "إلغاء" else "Cancel", fontSize = 10.sp)
                        }
                        Button(
                            onClick = {
                                if (serverHost.isNotBlank()) {
                                    val portInt = serverPort.toIntOrNull() ?: OnlineMultiplayerManager.DEFAULT_PORT
                                    onAddCustomServer(serverName, serverHost, portInt)
                                    showAddCustomDialog = false
                                    Toast.makeText(context, if (isRtl) "تمت إضافة السيرفر واختياره بنجاح!" else "Server added!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
                        ) {
                            Text(if (isRtl) "حفظ وتعيين 🚀" else "Save & Set", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

/**
 * تبويب الغرف واللعب أونلاين
 */
@Composable
private fun OnlineRoomsTab(
    publicRooms: List<OnlineRoom>,
    currentUser: UserProfile,
    selectedServer: GameServer,
    connectionStatus: String,
    onCreateRoom: (String, Boolean, String) -> Unit,
    onJoinRoom: (String) -> Unit,
    onQuickMatchmaking: () -> Unit,
    isRtl: Boolean,
    context: Context
) {
    var roomCodeInput by remember { mutableStateOf("") }
    var showCreateDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 310.dp)
    ) {
        // صف الأزرار الرئيسية: مطابقة سريعة + إنشاء غرفة
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onQuickMatchmaking,
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00C853)),
                shape = RoundedCornerShape(10.dp),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isRtl) "مطابقة سريعة ⚡" else "Quick Play",
                        color = Color.Black,
                        fontWeight = FontWeight.Black,
                        fontSize = 11.5.sp
                    )
                }
            }

            Button(
                onClick = { showCreateDialog = true },
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp),
                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                shape = RoundedCornerShape(10.dp),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "👑", fontSize = 15.sp)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isRtl) "إنشاء غرفة أونلاين" else "Create Room",
                        color = Color.Black,
                        fontWeight = FontWeight.Black,
                        fontSize = 11.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // حقل الانضمام برمز الغرفة (مثل ببجي والألعاب العالمية)
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = roomCodeInput,
                onValueChange = { roomCodeInput = it.uppercase() },
                placeholder = {
                    Text(
                        text = if (isRtl) "أدخل كود الغرفة (مثال: TRB-9104)" else "Enter Room Code (e.g. TRB-9104)",
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldPrimary,
                    unfocusedBorderColor = GoldDark.copy(alpha = 0.6f),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
            Spacer(modifier = Modifier.width(6.dp))
            Button(
                onClick = {
                    if (roomCodeInput.isNotBlank()) {
                        onJoinRoom(roomCodeInput)
                    }
                },
                modifier = Modifier.height(44.dp),
                colors = ButtonDefaults.buttonColors(containerColor = FeltGreenDark),
                border = BorderStroke(1.dp, GoldPrimary),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = if (isRtl) "انضمام 🚀" else "Join",
                    color = GoldLight,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        if (connectionStatus.isNotBlank()) {
            Text(
                text = connectionStatus,
                color = if (connectionStatus.contains("فشل") || connectionStatus.contains("ممتلئة")) DangerRed else SuccessGreen,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // قائمة الغرف المتاحة على السيرفر
        Text(
            text = if (isRtl) "الغرف النشطة على ${selectedServer.nameArabic}:" else "Active Rooms on Server:",
            color = GoldLight,
            fontSize = 10.5.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(4.dp))

        if (publicRooms.isEmpty()) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                shape = RoundedCornerShape(10.dp),
                color = SurfaceCardContainer,
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f))
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = "🎴", fontSize = 22.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isRtl) "لا توجد غرف مفتوحة حالياً على هذا السيرفر" else "No open rooms on this server",
                        color = GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.5.sp
                    )
                    Text(
                        text = if (isRtl) "كن الأول واضغط 'إنشاء غرفة أونلاين' لمشاركة الكود مع أصدقائك واللعب معاً!" else "Create a room and share the code with friends!",
                        color = Color.White.copy(alpha = 0.65f),
                        fontSize = 9.5.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(publicRooms) { room ->
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = SurfaceCardContainer,
                        border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.8f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = room.roomName,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.5.sp
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = Color(0xFF1565C0)
                                    ) {
                                        Text(
                                            text = room.roomId,
                                            color = Color.White,
                                            fontSize = 8.5.sp,
                                            fontWeight = FontWeight.Black,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "المستضيف: ${room.hostName} • المقاعد: ${room.playersCount}/5",
                                    color = GoldLight,
                                    fontSize = 9.5.sp
                                )
                            }

                            Button(
                                onClick = { onJoinRoom(room.roomId) },
                                modifier = Modifier.height(30.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = if (isRtl) "دخول" else "Join",
                                    color = Color.Black,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // نافذة إنشاء غرفة أونلاين جديدة
    if (showCreateDialog) {
        Dialog(onDismissRequest = { showCreateDialog = false }) {
            var roomName by remember { mutableStateOf("طاولة ${currentUser.username}") }
            var customCode by remember { mutableStateOf("") }
            var isPrivate by remember { mutableStateOf(false) }

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDarkNavy),
                border = BorderStroke(1.5.dp, GoldPrimary),
                modifier = Modifier.fillMaxWidth(0.92f)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (isRtl) "👑 إنشاء غرفة لعب أونلاين" else "Create Online Room",
                        color = GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "السيرفر: ${selectedServer.flagEmoji} ${selectedServer.nameArabic}",
                        color = SuccessGreen,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = roomName,
                        onValueChange = { roomName = it },
                        label = { Text(if (isRtl) "اسم الغرفة / الطاولة" else "Room Name", fontSize = 10.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = customCode,
                        onValueChange = { customCode = it.uppercase() },
                        label = { Text(if (isRtl) "كود مخصص للغرفة (اختياري)" else "Custom Code (Optional)", fontSize = 10.sp) },
                        placeholder = { Text("مثال: TRB-7788", fontSize = 10.sp, color = Color.Gray) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { showCreateDialog = false },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)
                        ) {
                            Text(if (isRtl) "إلغاء" else "Cancel", fontSize = 10.sp)
                        }
                        Button(
                            onClick = {
                                onCreateRoom(roomName, isPrivate, customCode)
                                showCreateDialog = false
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
                        ) {
                            Text(if (isRtl) "إنشاء ومشاركة 🚀" else "Create & Share", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

/**
 * شريط هوية اللاعب
 */
@Composable
private fun RealPlayerIdentityBanner(
    profile: UserProfile,
    isRtl: Boolean,
    context: Context
) {
    val currentAvatar = UserProfileManager.availableAvatars.getOrNull(profile.avatarId)?.emoji ?: "👑"

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        color = FeltGreenDark,
        border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.7f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = CircleShape,
                    color = GoldDark.copy(alpha = 0.4f),
                    border = BorderStroke(1.dp, GoldPrimary),
                    modifier = Modifier.size(32.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(text = currentAvatar, fontSize = 18.sp)
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = profile.username,
                            color = GoldLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = GoldDark.copy(alpha = 0.4f)
                        ) {
                            Text(
                                text = "${if (isRtl) "مستوى" else "Lvl"} ${profile.level}",
                                color = GoldLight,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                    Text(
                        text = "معرفك: ${profile.playerId}",
                        color = Color.White.copy(alpha = 0.75f),
                        fontSize = 9.5.sp
                    )
                }
            }

            Button(
                onClick = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Player ID", profile.playerId))
                    Toast.makeText(context, if (isRtl) "تم نسخ المعرف: ${profile.playerId}" else "Copied ID", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.height(26.dp),
                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(text = if (isRtl) "نسخ الـ ID 📋" else "Copy ID", color = Color.Black, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/**
 * تبويب قائمة الأصدقاء المتاحين لدعوتهم للجولات
 */
@Composable
private fun RealFriendsTab(
    availableFriends: List<SearchedPlayerProfile>,
    isRtl: Boolean,
    currentRoom: OnlineRoom?,
    onInviteFriend: (SearchedPlayerProfile) -> Unit,
    onInviteAll: () -> Unit,
    onRemoveFriend: (SearchedPlayerProfile) -> Unit,
    onSwitchToSearchTab: () -> Unit,
    context: Context
) {
    var filterStatus by remember { mutableIntStateOf(0) } // 0: الكل، 1: متاح، 2: في جولة، 3: غير متصل

    val filteredFriends = remember(availableFriends, filterStatus) {
        when (filterStatus) {
            1 -> availableFriends.filter { it.inviteStatus == FriendInviteStatus.AVAILABLE }
            2 -> availableFriends.filter { it.inviteStatus == FriendInviteStatus.IN_ROUND }
            3 -> availableFriends.filter { it.inviteStatus == FriendInviteStatus.OFFLINE }
            else -> availableFriends
        }
    }

    val availableCount = availableFriends.count { it.inviteStatus == FriendInviteStatus.AVAILABLE && !it.isInvited }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 340.dp)
    ) {
        // شريط زر "دعوة الكل" مع إحصائيات التوافر
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (isRtl) "الأصدقاء المتاحون للدعوة:" else "Available Friends to Invite:",
                    color = GoldLight,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
                if (currentRoom != null) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = Color(0xFF1565C0)
                    ) {
                        Text(
                            text = currentRoom.roomId,
                            color = Color.White,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
            }

            Button(
                onClick = onInviteAll,
                enabled = availableCount > 0,
                modifier = Modifier.height(28.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (availableCount > 0) Color(0xFF00C853) else Color.Gray
                ),
                shape = RoundedCornerShape(6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Mail,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = if (isRtl) "دعوة الكل 🚀 ($availableCount)" else "Invite All ($availableCount)",
                        color = Color.Black,
                        fontSize = 8.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // فلاتر التوافر السريعة
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val filters = listOf(
                Pair(if (isRtl) "الكل (${availableFriends.size})" else "All (${availableFriends.size})", 0),
                Pair(if (isRtl) "متاح 🟢 (${availableFriends.count { it.inviteStatus == FriendInviteStatus.AVAILABLE }})" else "Available 🟢", 1),
                Pair(if (isRtl) "في جولة 🟡" else "In Round 🟡", 2),
                Pair(if (isRtl) "غير متصل ⚪" else "Offline ⚪", 3)
            )

            filters.forEach { (title, idx) ->
                val isSelected = filterStatus == idx
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isSelected) GoldPrimary else SurfaceCardContainer,
                    border = BorderStroke(1.dp, if (isSelected) GoldLight else Color.White.copy(alpha = 0.2f)),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { filterStatus = idx }
                ) {
                    Text(
                        text = title,
                        color = if (isSelected) Color.Black else Color.White,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 8.5.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        if (filteredFriends.isEmpty()) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                shape = RoundedCornerShape(10.dp),
                color = SurfaceCardContainer,
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = "👥", fontSize = 26.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (availableFriends.isEmpty()) {
                            if (isRtl) "قائمة الأصدقاء فارغة حالياً" else "No friends in your list yet"
                        } else {
                            if (isRtl) "لا يوجد أصدقاء في هذا التصنيف حالياً" else "No friends in this category"
                        },
                        color = GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.5.sp
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = if (availableFriends.isEmpty()) {
                            if (isRtl) "اللعبة مخصصة للاعبين الحقيقيين فقط بدون أي أسماء وهمية. شارك معرّفك مع أصدقائك الذين حملوا اللعبة على جوالاتهم أو ابحث عنهم بالـ ID لإضافتهم ودعوتهم للجولات!"
                            else "Only real players who installed the game on their phones. Share your ID or search friends by ID to add & invite them!"
                        } else {
                            if (isRtl) "يمكنك البحث عن لاعبين حقيقيين وإضافتهم عبر الـ ID الخاص بهم لدعوتهم للجولات فوراً!"
                            else "Search real players by ID to add & invite them to matches!"
                        },
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 9.5.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onSwitchToSearchTab,
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Search, contentDescription = null, tint = Color.Black, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = if (isRtl) "البحث عن لاعبين بالـ ID 🔍" else "Search Players by ID", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(filteredFriends) { friend ->
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = SurfaceCardContainer,
                        border = BorderStroke(
                            1.dp,
                            when {
                                friend.isInvited -> SuccessGreen
                                friend.inviteStatus == FriendInviteStatus.AVAILABLE -> GoldLight.copy(alpha = 0.6f)
                                else -> Color.White.copy(alpha = 0.15f)
                            }
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Surface(
                                    shape = CircleShape,
                                    color = FeltGreenDark,
                                    border = BorderStroke(1.dp, GoldLight),
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(text = friend.avatarEmoji, fontSize = 18.sp)
                                    }
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = friend.username,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.5.sp
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = GoldDark.copy(alpha = 0.5f)
                                        ) {
                                            Text(
                                                text = "Lvl ${friend.level}",
                                                color = GoldLight,
                                                fontSize = 7.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 3.dp, vertical = 0.5.dp)
                                            )
                                        }
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    when (friend.inviteStatus) {
                                                        FriendInviteStatus.AVAILABLE -> SuccessGreen
                                                        FriendInviteStatus.IN_ROUND -> Color(0xFFFFB300)
                                                        FriendInviteStatus.OFFLINE -> Color.Gray
                                                    }
                                                )
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "${friend.playerId} • ${friend.inviteStatus.titleArabic}",
                                            color = when (friend.inviteStatus) {
                                                FriendInviteStatus.AVAILABLE -> SuccessGreen
                                                FriendInviteStatus.IN_ROUND -> Color(0xFFFFB300)
                                                FriendInviteStatus.OFFLINE -> Color.Gray
                                            },
                                            fontSize = 9.sp
                                        )
                                    }
                                    Text(
                                        text = "${if (isRtl) "الفوز:" else "Wins:"} ${friend.wins} • ${if (isRtl) "النسبة:" else "Rate:"} ${friend.winRate}%",
                                        color = Color.White.copy(alpha = 0.6f),
                                        fontSize = 8.sp
                                    )
                                }
                            }

                            // أزرار الإجراء
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // زر نسخ المعرف
                                IconButton(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("Friend ID", friend.playerId))
                                        Toast.makeText(context, if (isRtl) "تم نسخ المعرف: ${friend.playerId}" else "Copied ID", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy ID", tint = GoldLight, modifier = Modifier.size(13.dp))
                                }

                                Spacer(modifier = Modifier.width(2.dp))

                                // زر حذف الصديق
                                IconButton(
                                    onClick = { onRemoveFriend(friend) },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Remove Friend", tint = DangerRed.copy(alpha = 0.8f), modifier = Modifier.size(13.dp))
                                }

                                Spacer(modifier = Modifier.width(4.dp))

                                // زر دعوة للجولة
                                Button(
                                    onClick = { onInviteFriend(friend) },
                                    enabled = !friend.isInvited && friend.inviteStatus == FriendInviteStatus.AVAILABLE,
                                    modifier = Modifier.height(28.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = when {
                                            friend.isInvited -> Color(0xFF1B5E20)
                                            friend.inviteStatus == FriendInviteStatus.AVAILABLE -> GoldPrimary
                                            else -> Color.DarkGray
                                        }
                                    ),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (friend.isInvited) {
                                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(11.dp))
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text(text = if (isRtl) "تمت الدعوة ✓" else "Invited ✓", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                        } else {
                                            Icon(Icons.Default.Send, contentDescription = null, tint = Color.Black, modifier = Modifier.size(11.dp))
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text(
                                                text = when (friend.inviteStatus) {
                                                    FriendInviteStatus.AVAILABLE -> if (isRtl) "دعوة للجولة 📨" else "Invite"
                                                    FriendInviteStatus.IN_ROUND -> if (isRtl) "في جولة" else "In Round"
                                                    FriendInviteStatus.OFFLINE -> if (isRtl) "غير متصل" else "Offline"
                                                },
                                                color = if (friend.inviteStatus == FriendInviteStatus.AVAILABLE) Color.Black else Color.LightGray,
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * تبويب واجهة البحث عن لاعبين عبر الـ ID وإضافتهم كأصدقاء
 */
@Composable
private fun RealAddFriendByIdTab(
    currentUser: UserProfile,
    currentRoom: OnlineRoom?,
    isRtl: Boolean,
    onFriendAdded: (SearchedPlayerProfile) -> Unit,
    context: Context
) {
    var searchInput by remember { mutableStateOf("") }
    var searchResult by remember { mutableStateOf<PlayerSearchResult?>(null) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 340.dp)
    ) {
        Text(
            text = if (isRtl) "واجهة البحث عن اللاعبين عبر الـ ID وإضافتهم كأصدقاء:" else "Search players by ID and add as friends:",
            color = GoldLight,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(6.dp))

        // حقل إدخال الـ ID وزر البحث
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchInput,
                onValueChange = { searchInput = it },
                placeholder = {
                    Text(
                        text = if (isRtl) "أدخل معرف اللاعب (مثال: #TRB-9104)" else "Enter Player ID (e.g. #TRB-9104)",
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp),
                singleLine = true,
                trailingIcon = {
                    if (searchInput.isNotEmpty()) {
                        IconButton(onClick = { searchInput = "" }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Clear", tint = Color.Gray, modifier = Modifier.size(14.dp))
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldPrimary,
                    unfocusedBorderColor = GoldDark.copy(alpha = 0.6f),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
            Spacer(modifier = Modifier.width(6.dp))
            Button(
                onClick = {
                    if (searchInput.isNotBlank()) {
                        searchResult = PlayerDirectoryService.searchPlayerById(searchInput, currentUser)
                    }
                },
                modifier = Modifier.height(44.dp),
                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Search, contentDescription = null, tint = Color.Black, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(text = if (isRtl) "بحث 🔍" else "Search", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.5.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // شريط معرف اللاعب الشخصي وزر النسخ واللصق
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = FeltGreenDark,
            border = BorderStroke(1.dp, GoldLight.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "🆔", fontSize = 13.sp)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${if (isRtl) "معرفك للمشاركة:" else "Your ID:"} ${currentUser.playerId}",
                        color = GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("My ID", currentUser.playerId))
                            Toast.makeText(context, if (isRtl) "تم نسخ معرفك لمشاركته مع أصدقائك!" else "ID copied!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.height(26.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(text = if (isRtl) "نسخ معرفي 📋" else "Copy My ID", color = Color.Black, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    Button(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clipText = clipboard.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
                            if (clipText.isNotBlank()) {
                                searchInput = clipText.trim()
                                searchResult = PlayerDirectoryService.searchPlayerById(clipText.trim(), currentUser)
                            }
                        },
                        modifier = Modifier.height(26.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceCardContainer),
                        border = BorderStroke(0.8.dp, GoldLight),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(text = if (isRtl) "لصق ID 📥" else "Paste ID", color = GoldLight, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // عرض بطاقة نتيجة البحث أو التوجيهات
        when (val res = searchResult) {
            null -> {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = SurfaceCardContainer,
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f))
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "📱", fontSize = 24.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isRtl) "قائمة اللاعبين الحقيقيين فقط" else "Real Players Only",
                            color = GoldLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = if (isRtl) "اطلب من صديقك الذي حمّل اللعبة على هاتفه مشاركة الـ ID الخاص به، ثم الصقه بالأعلى للبحث عنه وإضافته فوراً لدعوته في الجولات الحقيقية!" else "Ask your friend who installed the app on their phone for their ID, paste it above to add and invite them to real matches!",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 9.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            is PlayerSearchResult.IsSelf -> {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = FeltGreenDark,
                    border = BorderStroke(1.dp, GoldPrimary)
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "👑", fontSize = 20.sp)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (isRtl) "هذا هو المعرف الخاص بك (${currentUser.playerId})!" else "This is your own Player ID!",
                            color = GoldLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                        Text(
                            text = if (isRtl) "شاركه مع أصدقائك ليقوموا بإضافتك ودعوتك للجولات!" else "Share it with friends so they can add you!",
                            color = Color.White.copy(alpha = 0.75f),
                            fontSize = 9.sp
                        )
                    }
                }
            }

            is PlayerSearchResult.NotFound -> {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = DangerRed.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, DangerRed)
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "❌", fontSize = 18.sp)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (isRtl) "لم يتم العثور على لاعب بالمعرف: ${res.searchedId}" else "Player not found for ID: ${res.searchedId}",
                            color = DangerRed,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.5.sp
                        )
                        Text(
                            text = if (isRtl) "تأكد من صيغة المعرف (مثل #TRB-9104)" else "Make sure to enter valid ID like #TRB-9104",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 8.5.sp
                        )
                    }
                }
            }

            is PlayerSearchResult.Error -> {
                Text(text = res.message, color = DangerRed, fontSize = 10.sp)
            }

            is PlayerSearchResult.Success, is PlayerSearchResult.AlreadyFriend -> {
                val player = if (res is PlayerSearchResult.Success) res.player else (res as PlayerSearchResult.AlreadyFriend).player
                val isFriend = res is PlayerSearchResult.AlreadyFriend || player.isAlreadyFriend

                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = SurfaceCardContainer,
                    border = BorderStroke(1.5.dp, GoldPrimary)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = FeltGreenDark,
                                    border = BorderStroke(1.dp, GoldPrimary),
                                    modifier = Modifier.size(38.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(text = player.avatarEmoji, fontSize = 20.sp)
                                    }
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = player.username,
                                            color = GoldLight,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = GoldDark.copy(alpha = 0.5f)
                                        ) {
                                            Text(
                                                text = "Lvl ${player.level}",
                                                color = GoldLight,
                                                fontSize = 7.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 3.dp, vertical = 0.5.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = "${player.playerId} • ${player.title}",
                                        color = Color.White.copy(alpha = 0.8f),
                                        fontSize = 9.5.sp
                                    )
                                    Text(
                                        text = "${if (isRtl) "الفوز:" else "Wins:"} ${player.wins} • ${if (isRtl) "النسبة:" else "Winrate:"} ${player.winRate}%",
                                        color = SuccessGreen,
                                        fontSize = 8.5.sp
                                    )
                                }
                            }

                            // شارة التوافر
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = when (player.inviteStatus) {
                                    FriendInviteStatus.AVAILABLE -> SuccessGreen.copy(alpha = 0.2f)
                                    FriendInviteStatus.IN_ROUND -> Color(0xFFFFB300).copy(alpha = 0.2f)
                                    FriendInviteStatus.OFFLINE -> Color.Gray.copy(alpha = 0.2f)
                                },
                                border = BorderStroke(0.6.dp, when (player.inviteStatus) {
                                    FriendInviteStatus.AVAILABLE -> SuccessGreen
                                    FriendInviteStatus.IN_ROUND -> Color(0xFFFFB300)
                                    FriendInviteStatus.OFFLINE -> Color.Gray
                                })
                            ) {
                                Text(
                                    text = player.inviteStatus.titleArabic,
                                    color = when (player.inviteStatus) {
                                        FriendInviteStatus.AVAILABLE -> SuccessGreen
                                        FriendInviteStatus.IN_ROUND -> Color(0xFFFFB300)
                                        FriendInviteStatus.OFFLINE -> Color.Gray
                                    },
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.5.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // أزرار الإجراء
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (!isFriend) {
                                Button(
                                    onClick = {
                                        val ok = PlayerDirectoryService.addSearchedPlayerAsFriend(player)
                                        if (ok) {
                                            searchResult = PlayerSearchResult.AlreadyFriend(player.copy(isAlreadyFriend = true))
                                            onFriendAdded(player)
                                        }
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(32.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.PersonAdd, contentDescription = null, tint = Color.Black, modifier = Modifier.size(13.dp))
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text(text = if (isRtl) "إضافة كصديق ➕" else "Add Friend", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 9.sp)
                                    }
                                }
                            } else {
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(32.dp),
                                    shape = RoundedCornerShape(6.dp),
                                    color = FeltGreenDark,
                                    border = BorderStroke(1.dp, SuccessGreen)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(text = if (isRtl) "صديق مضاف بالفعل ✓" else "Already Friends ✓", color = SuccessGreen, fontWeight = FontWeight.Bold, fontSize = 8.5.sp)
                                    }
                                }
                            }

                            Button(
                                onClick = {
                                    val roomCode = currentRoom?.roomId ?: ""
                                    PlayerDirectoryService.inviteFriendToRound(player.playerId, roomCode)
                                    searchResult = if (res is PlayerSearchResult.Success) {
                                        PlayerSearchResult.Success(player.copy(isInvited = true))
                                    } else {
                                        PlayerSearchResult.AlreadyFriend(player.copy(isInvited = true))
                                    }
                                    Toast.makeText(
                                        context,
                                        if (isRtl) "تم إرسال دعوة الجولة إلى ${player.username}! 📨" else "Invited ${player.username}!",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                },
                                enabled = !player.isInvited,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(32.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (player.isInvited) Color(0xFF1B5E20) else Color(0xFF0288D1)
                                ),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (player.isInvited) Icons.Default.Check else Icons.Default.Send,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = if (player.isInvited) (if (isRtl) "تمت الدعوة ✓" else "Invited") else (if (isRtl) "دعوة للجولة 📨" else "Invite to Match"),
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 8.5.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * ردهة الغرفة النشطة الحقيقية
 */
@Composable
private fun RealActiveRoomLobbyView(
    room: OnlineRoom,
    currentUser: UserProfile,
    onAddBot: () -> Unit,
    onRemovePlayer: (Int) -> Unit,
    onToggleReady: (Int) -> Unit,
    onSendMessage: (String) -> Unit,
    onLeaveRoom: () -> Unit,
    onStartGame: () -> Unit,
    isRtl: Boolean,
    context: Context
) {
    val isHost = room.hostId == currentUser.playerId
    val mySeat = room.players.find { it.playerId == currentUser.playerId }
    val isMeReady = mySeat?.isReady == true
    val chatMessages by OnlineMultiplayerManager.lobbyChat.collectAsState()
    var chatInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 480.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // رأس الردهة: كود الغرفة والسيرفر
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            color = FeltGreenDark,
            border = BorderStroke(1.dp, GoldPrimary)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "👑 ${room.roomName}",
                            color = GoldLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Color(0xFF1565C0)
                        ) {
                            Text(
                                text = room.roomId,
                                color = Color.White,
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                    Text(
                        text = "السيرفر: ${room.serverRegion}",
                        color = SuccessGreen,
                        fontSize = 9.sp
                    )
                }

                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Room Code", room.roomId))
                        Toast.makeText(context, if (isRtl) "تم نسخ كود الغرفة: ${room.roomId}" else "Copied Room Code", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.height(26.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(text = if (isRtl) "نسخ الكود 📋" else "Copy Code", color = Color.Black, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        var showInviteDialogInLobby by remember { mutableStateOf(false) }

        Spacer(modifier = Modifier.height(6.dp))

        // زر دعوة الأصدقاء المتاحين للجولة
        Button(
            onClick = { showInviteDialogInLobby = true },
            modifier = Modifier
                .fillMaxWidth()
                .height(34.dp),
            colors = ButtonDefaults.buttonColors(containerColor = FeltGreenDark),
            border = BorderStroke(1.dp, GoldPrimary),
            shape = RoundedCornerShape(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.PersonAdd,
                    contentDescription = null,
                    tint = GoldPrimary,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isRtl) "دعوة الأصدقاء المتاحين للجولة عبر الـ ID 📨" else "Invite Available Friends by ID",
                    color = GoldLight,
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        if (showInviteDialogInLobby) {
            com.example.friends.FriendsInviteDialog(
                onDismiss = { showInviteDialogInLobby = false },
                roomCode = room.roomId
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // المقاعد الخمسة في الغرفة
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            for (seat in 0..4) {
                val player = room.players.find { it.seatId == seat }
                RealLobbySeatCard(
                    seatId = seat,
                    player = player,
                    isHostViewer = isHost,
                    onAddBot = onAddBot,
                    onKick = { onRemovePlayer(seat) },
                    modifier = Modifier.weight(1f),
                    isRtl = isRtl
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // شات ورسائل الردهة الحية
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(95.dp),
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFF0A1218),
            border = BorderStroke(1.dp, GoldDark.copy(alpha = 0.3f))
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(6.dp),
                verticalArrangement = Arrangement.spacedBy(2.5.dp)
            ) {
                items(chatMessages) { msg ->
                    Row {
                        Text(
                            text = "${msg.senderName}: ",
                            color = if (msg.isSystem) GoldPrimary else GoldLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.5.sp
                        )
                        Text(
                            text = msg.text,
                            color = if (msg.isSystem) Color.White else Color(0xFFE0E0E0),
                            fontSize = 9.5.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // أزرار الرسائل السريعة
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val quickMsgs = listOf("👋 مرحباً!", "جاهزون للعب؟", "بالتوفيق يا شباب!", "سأشتري الترب 🔥")
            quickMsgs.forEach { msg ->
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = FeltGreenDark,
                    border = BorderStroke(0.6.dp, GoldLight.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onSendMessage(msg) }
                ) {
                    Text(
                        text = msg,
                        color = GoldLight,
                        fontSize = 8.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(vertical = 3.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // إدخال رسالة وإرسالها
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = chatInput,
                onValueChange = { chatInput = it },
                placeholder = { Text(if (isRtl) "اكتب رسالة للردهة..." else "Lobby chat...", fontSize = 9.5.sp, color = Color.Gray) },
                modifier = Modifier
                    .weight(1f)
                    .height(38.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldPrimary,
                    unfocusedBorderColor = Color.Gray,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
            Spacer(modifier = Modifier.width(4.dp))
            IconButton(
                onClick = {
                    if (chatInput.isNotBlank()) {
                        onSendMessage(chatInput)
                        chatInput = ""
                    }
                },
                modifier = Modifier.size(38.dp)
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send", tint = GoldPrimary, modifier = Modifier.size(18.dp))
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // أزرار التحكم بالردهة: مغادرة، جاهز، وبدء اللعبة
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onLeaveRoom,
                modifier = Modifier
                    .weight(1f)
                    .height(40.dp),
                colors = ButtonDefaults.buttonColors(containerColor = DangerRed.copy(alpha = 0.85f)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(text = if (isRtl) "مغادرة 🚪" else "Leave", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp)
            }

            if (!isHost) {
                Button(
                    onClick = { mySeat?.let { onToggleReady(it.seatId) } },
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isMeReady) SuccessGreen else GoldDark
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = if (isMeReady) (if (isRtl) "جاهز ✓" else "Ready ✓") else (if (isRtl) "اضغط جاهز" else "Set Ready"),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                }
            }

            if (isHost) {
                Button(
                    onClick = onStartGame,
                    modifier = Modifier
                        .weight(1.5f)
                        .height(40.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = if (isRtl) "بدء المباراة أونلاين 🚀" else "Start Match 🚀",
                        color = Color.Black,
                        fontWeight = FontWeight.Black,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

/**
 * بطاقة مقعد اللاعب في الردهة
 */
@Composable
private fun RealLobbySeatCard(
    seatId: Int,
    player: OnlinePlayer?,
    isHostViewer: Boolean,
    onAddBot: () -> Unit,
    onKick: () -> Unit,
    modifier: Modifier = Modifier,
    isRtl: Boolean
) {
    Surface(
        modifier = modifier.height(105.dp),
        shape = RoundedCornerShape(8.dp),
        color = if (player != null) SurfaceCardContainer else Color(0xFF0C161D),
        border = BorderStroke(
            1.dp,
            when {
                player?.isHost == true -> GoldPrimary
                player?.isReady == true -> SuccessGreen
                player != null -> GoldDark.copy(alpha = 0.6f)
                else -> Color.White.copy(alpha = 0.12f)
            }
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(3.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // شارة المقعد
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${seatId + 1}",
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold
                )

                if (player != null && !player.isHost && isHostViewer) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Remove",
                        tint = DangerRed,
                        modifier = Modifier
                            .size(12.dp)
                            .clickable { onKick() }
                    )
                }
            }

            if (player != null) {
                // صورة ومعلومات اللاعب
                Text(text = player.avatarEmoji, fontSize = 18.sp)
                Text(
                    text = player.username,
                    color = if (player.isHost) GoldLight else Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 8.5.sp,
                    maxLines = 1
                )
                // شارة الحالة
                Surface(
                    shape = RoundedCornerShape(3.dp),
                    color = when {
                        player.isHost -> GoldPrimary
                        player.isReady -> SuccessGreen
                        player.isAiBot -> Color(0xFF7E57C2)
                        else -> Color.Gray
                    }
                ) {
                    Text(
                        text = when {
                            player.isHost -> "المستضيف"
                            player.isReady -> "جاهز ✓"
                            player.isAiBot -> "AI 🤖"
                            else -> "ينتظر..."
                        },
                        color = if (player.isHost) Color.Black else Color.White,
                        fontSize = 7.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 3.dp, vertical = 0.5.dp)
                    )
                }
            } else {
                // مقعد فارغ
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "🪑", fontSize = 15.sp)
                    Text(
                        text = if (isRtl) "شاغر" else "Empty",
                        color = Color.Gray,
                        fontSize = 8.sp
                    )
                }
                if (isHostViewer) {
                    Button(
                        onClick = onAddBot,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(20.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = FeltGreenDark),
                        shape = RoundedCornerShape(3.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                    ) {
                        Text(text = "+ AI 🤖", color = GoldLight, fontSize = 7.5.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Spacer(modifier = Modifier.height(2.dp))
                }
            }
        }
    }
}

/**
 * تبويب اللعب التنافسي ونظام المطابقة الحاكم المعتمد عبر Firebase
 */
@Composable
private fun CompetitiveMatchmakingTab(
    authState: com.example.online.AuthState,
    competitiveRoom: CompetitiveOnlineRoom?,
    activeRooms: List<CompetitiveOnlineRoom>,
    isLoading: Boolean,
    statusMessage: String,
    currentUser: UserProfile,
    onStartMatch: (CompetitiveOnlineRoom) -> Unit,
    isRtl: Boolean,
    context: Context
) {
    var newRoomName by remember { mutableStateOf("") }
    var joinRoomCodeInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 380.dp)
    ) {
        // بطاقة حالة المصادقة (Firebase Auth)
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = SurfaceCardContainer,
            border = BorderStroke(1.dp, if (authState.isLoggedIn) GoldPrimary else Color.White.copy(alpha = 0.2f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = if (authState.isAnonymous) "👤" else "🇬", fontSize = 18.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = authState.displayName,
                                color = GoldLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (authState.isAnonymous) Color.Gray.copy(alpha = 0.4f) else SuccessGreen.copy(alpha = 0.3f)
                            ) {
                                Text(
                                    text = if (authState.isAnonymous) (if (isRtl) "ضيف (مجهول)" else "Guest") else (if (isRtl) "حساب موثق ✅" else "Verified"),
                                    color = if (authState.isAnonymous) Color.LightGray else SuccessGreen,
                                    fontSize = 7.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Text(
                            text = "UID: ${authState.uid.take(12)}...",
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 8.5.sp
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (authState.isAnonymous) {
                        Button(
                            onClick = {
                                FirebaseAuthManager.signInWithGoogle(context) { ok, msg ->
                                    Toast.makeText(context, msg ?: (if (ok) "تم الدخول بنجاح" else "فشل الدخول"), Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.height(28.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(text = if (isRtl) "Google 🇬" else "Google", color = Color.Black, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        IconButton(
                            onClick = {
                                FirebaseAuthManager.signOut()
                                Toast.makeText(context, if (isRtl) "تم تسجيل الخروج" else "Signed out", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Sign out", tint = Color.Gray, modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        if (statusMessage.isNotBlank()) {
            Text(
                text = statusMessage,
                color = if (statusMessage.contains("فشل") || statusMessage.contains("خطأ")) DangerRed else GoldLight,
                fontSize = 9.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
        }

        // إذا كان اللاعب داخل غرفة تنافسية حالياً
        if (competitiveRoom != null) {
            val engineState = competitiveRoom.gameState
            val isHost = competitiveRoom.hostUid == authState.uid

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = SurfaceCardContainer,
                border = BorderStroke(1.5.dp, GoldPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    // شريط الرمز والرابط
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (isRtl) "رمز دعوة المباراة التنافسية:" else "Match Invite Code:",
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 9.sp
                            )
                            Text(
                                text = competitiveRoom.roomCode,
                                color = GoldPrimary,
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Button(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Tirb Match Code", competitiveRoom.roomCode))
                                    Toast.makeText(context, if (isRtl) "تم نسخ الرمز: ${competitiveRoom.roomCode}" else "Code copied!", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.height(26.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(text = if (isRtl) "نسخ الرمز 📋" else "Copy Code", color = Color.Black, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }

                            Spacer(modifier = Modifier.width(4.dp))

                            IconButton(
                                onClick = {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_SUBJECT, "دعوة لمباراة الترب")
                                        putExtra(Intent.EXTRA_TEXT, "انضم معي لمباراة الترب التنافسية برمز الغرفة: ${competitiveRoom.roomCode}\nرابط الانضمام: ${competitiveRoom.inviteLink}")
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "مشاركة دعوة المباراة"))
                                },
                                modifier = Modifier.size(26.dp)
                            ) {
                                Icon(Icons.Default.Send, contentDescription = "Share", tint = GoldLight, modifier = Modifier.size(13.dp))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // قائمة اللاعبين المتصلين في مقاعد الغرفة (5 مقاعد)
                    Text(
                        text = if (isRtl) "اللاعبون المتصلون (${engineState.players.size}/5):" else "Connected Players (${engineState.players.size}/5):",
                        color = GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        for (seat in 0..4) {
                            val player = engineState.players.find { it.seatId == seat }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (player != null) FeltGreenDark else Color.Black.copy(alpha = 0.3f),
                                border = BorderStroke(0.8.dp, if (player != null) GoldLight.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.15f)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(
                                    modifier = Modifier.padding(4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    if (player != null) {
                                        Text(text = player.avatarEmoji, fontSize = 16.sp)
                                        Text(
                                            text = player.username,
                                            color = if (player.isHost) GoldLight else Color.White,
                                            fontSize = 7.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1
                                        )
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(5.dp)
                                                    .clip(CircleShape)
                                                    .background(if (player.isConnected) SuccessGreen else Color.Gray)
                                            )
                                            Spacer(modifier = Modifier.width(2.dp))
                                            Text(
                                                text = if (player.isConnected) (if (isRtl) "متصل" else "On") else (if (isRtl) "منقطع" else "Off"),
                                                color = if (player.isConnected) SuccessGreen else Color.Gray,
                                                fontSize = 6.5.sp
                                            )
                                        }
                                    } else {
                                        Text(text = "🪑", fontSize = 14.sp)
                                        Text(
                                            text = if (isRtl) "شاغر" else "Empty",
                                            color = Color.Gray,
                                            fontSize = 7.5.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // أزرار التحكم بالمباراة
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = {
                                FirestoreMatchmakingService.leaveCurrentRoom(authState.uid)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(34.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = DangerRed.copy(alpha = 0.8f)),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(text = if (isRtl) "مغادرة 🚪" else "Leave", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                if (isHost) {
                                    FirestoreMatchmakingService.dispatchAction(
                                        AuthoritativePlayerAction.StartMatch(authState.uid)
                                    ) { ok, err ->
                                        if (ok) {
                                            onStartMatch(competitiveRoom)
                                        } else {
                                            Toast.makeText(context, err ?: "تعذر البدء", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                } else {
                                    onStartMatch(competitiveRoom)
                                }
                            },
                            modifier = Modifier
                                .weight(2f)
                                .height(34.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = if (isHost) (if (isRtl) "بدء المباراة التنافسية 🏆" else "Start Match 🏆") else (if (isRtl) "دخول الطاولة 🎮" else "Enter Table"),
                                color = Color.Black,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }
        } else {
            // واجهة إنشاء وانضمام لمباراة تنافسية
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    // قسم إنشاء مباراة تنافسية
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = SurfaceCardContainer,
                        border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.6f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = if (isRtl) "إنشاء مباراة تنافسية جديدة (رمز دعوة فريد):" else "Create Competitive Match:",
                                color = GoldLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.5.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(
                                    value = newRoomName,
                                    onValueChange = { newRoomName = it },
                                    placeholder = {
                                        Text(text = if (isRtl) "اسم الطاولة (اختياري)" else "Room Name", fontSize = 10.sp, color = Color.Gray)
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(42.dp),
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = GoldPrimary,
                                        unfocusedBorderColor = GoldDark.copy(alpha = 0.5f),
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White
                                    )
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Button(
                                    onClick = {
                                        val hostName = authState.displayName.ifBlank { currentUser.username }
                                        val hostUid = authState.uid.ifBlank { currentUser.playerId }
                                        val avatarEmoji = UserProfileManager.availableAvatars.getOrNull(currentUser.avatarId)?.emoji ?: "👑"
                                        FirestoreMatchmakingService.createMatch(
                                            roomName = newRoomName,
                                            hostUid = hostUid,
                                            hostName = hostName,
                                            avatarEmoji = avatarEmoji,
                                            avatarId = currentUser.avatarId
                                        ) { ok, code ->
                                            if (ok) {
                                                Toast.makeText(context, if (isRtl) "تم إنشاء الغرفة! الرمز: $code" else "Room created: $code", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    },
                                    enabled = !isLoading,
                                    modifier = Modifier.height(42.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(text = if (isRtl) "إنشاء 🎲" else "Create", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }

                item {
                    // قسم الانضمام برمز الدعوة
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = SurfaceCardContainer,
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = if (isRtl) "الانضمام لطاولة عبر رمز الدعوة:" else "Join Match via Code:",
                                color = GoldLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.5.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(
                                    value = joinRoomCodeInput,
                                    onValueChange = { joinRoomCodeInput = it },
                                    placeholder = {
                                        Text(text = if (isRtl) "أدخل الرمز (مثال: TRB-7824)" else "Enter code", fontSize = 10.sp, color = Color.Gray)
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(42.dp),
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = GoldPrimary,
                                        unfocusedBorderColor = GoldDark.copy(alpha = 0.5f),
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White
                                    )
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Button(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = clipboard.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
                                        val codeToUse = if (clip.isNotBlank() && joinRoomCodeInput.isBlank()) clip else joinRoomCodeInput
                                        val userName = authState.displayName.ifBlank { currentUser.username }
                                        val userUid = authState.uid.ifBlank { currentUser.playerId }
                                        val avatarEmoji = UserProfileManager.availableAvatars.getOrNull(currentUser.avatarId)?.emoji ?: "🎴"

                                        FirestoreMatchmakingService.joinMatch(
                                            inputCode = codeToUse,
                                            userUid = userUid,
                                            userName = userName,
                                            avatarEmoji = avatarEmoji,
                                            avatarId = currentUser.avatarId
                                        ) { ok, msg ->
                                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    enabled = !isLoading,
                                    modifier = Modifier.height(42.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = FeltGreenDark),
                                    border = BorderStroke(1.dp, GoldPrimary),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(text = if (isRtl) "انضمام 🚀" else "Join", color = GoldLight, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }

                // قسم الخادم الحاكم والأمان
                item {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = FeltGreenDark.copy(alpha = 0.5f),
                        border = BorderStroke(0.6.dp, GoldLight.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "🛡️", fontSize = 16.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isRtl) "الخادم الحاكم (Authoritative Server) هو المرجع الوحيد لحركات وقوانين اللعبة لحماية المنافسة ومنع أي تلاعب وتأكيد النزاهة 100%."
                                else "Authoritative Server guarantees 100% fair play and rules enforcement.",
                                color = Color.White.copy(alpha = 0.75f),
                                fontSize = 8.5.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
