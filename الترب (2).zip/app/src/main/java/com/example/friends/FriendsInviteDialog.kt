package com.example.friends

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ForwardToInbox
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.localization.LocalizationManager
import com.example.profile.UserProfileManager
import com.example.ui.theme.DangerRed
import com.example.ui.theme.FeltGreenDark
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceCardContainer
import com.example.ui.theme.SurfaceDarkNavy

/**
 * نافذة البحث عن اللاعبين بالـ ID ودعوة الأصدقاء المتاحين للجولات
 */
@Composable
fun FriendsInviteDialog(
    onDismiss: () -> Unit,
    roomCode: String = "",
    onFriendInvited: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentProfile by UserProfileManager.profile.collectAsState()
    val availableFriends by PlayerDirectoryService.availableFriendsToInvite.collectAsState()
    val isRtl = LocalizationManager.currentLanguage.collectAsState().value.isRtl

    var selectedTab by remember { mutableIntStateOf(0) } // 0: الأصدقاء المتاحون للدعوة، 1: البحث عن لاعب بالـ ID
    var searchIdInput by remember { mutableStateOf("") }
    var searchResult by remember { mutableStateOf<PlayerSearchResult?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDarkNavy),
            border = BorderStroke(2.dp, GoldPrimary),
            elevation = CardDefaults.cardElevation(defaultElevation = 14.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = FeltGreenDark,
                            border = BorderStroke(1.dp, GoldPrimary),
                            modifier = Modifier.size(34.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.ForwardToInbox,
                                    contentDescription = "Invite Friends",
                                    tint = GoldLight,
                                    modifier = Modifier.size(19.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = if (isRtl) "دعوة الأصدقاء للجولات" else "Invite Friends to Match",
                                color = GoldLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = if (roomCode.isNotBlank())
                                    "${if (isRtl) "كود الغرفة:" else "Room Code:"} $roomCode"
                                else
                                    if (isRtl) "البحث بالـ ID ودعوة اللاعبين المتاحين" else "Search by ID & invite available friends",
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 10.sp
                            )
                        }
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = GoldLight
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // تبويبات النافذة (الأصدقاء المتاحون للدعوة / البحث بالـ ID)
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = FeltGreenDark,
                    contentColor = GoldLight,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = GoldPrimary,
                            height = 3.dp
                        )
                    }
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (isRtl) "الأصدقاء المتاحون" else "Available Friends",
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                val availableCount = availableFriends.count { it.inviteStatus == FriendInviteStatus.AVAILABLE }
                                if (availableCount > 0) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = SuccessGreen
                                    ) {
                                        Text(
                                            text = "$availableCount",
                                            color = Color.Black,
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Black,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 0.5.dp)
                                        )
                                    }
                                }
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Search, contentDescription = null, tint = GoldLight, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isRtl) "بحث بالـ ID 🔍" else "Search ID",
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                when (selectedTab) {
                    // تبويب 0: قائمة الأصدقاء المتاحين لدعوتهم للجولات
                    0 -> AvailableFriendsListTab(
                        availableFriends = availableFriends,
                        onInviteFriend = { friend ->
                            PlayerDirectoryService.inviteFriendToRound(friend.playerId, roomCode)
                            onFriendInvited(friend.playerId)
                            Toast.makeText(
                                context,
                                if (isRtl) "تم إرسال دعوة الجولة إلى ${friend.username} بنجاح! 📨" else "Invitation sent to ${friend.username}!",
                                Toast.LENGTH_SHORT
                            ).show()
                        },
                        onInviteAll = {
                            val count = PlayerDirectoryService.inviteAllAvailableFriends(roomCode)
                            if (count > 0) {
                                Toast.makeText(
                                    context,
                                    if (isRtl) "تم إرسال دعوة الجولة إلى جميع الأصدقاء المتاحين ($count) بنجاح! 🚀" else "Invited all $count available friends!",
                                    Toast.LENGTH_SHORT
                                ).show()
                            } else {
                                Toast.makeText(
                                    context,
                                    if (isRtl) "تمت دعوة جميع الأصدقاء المتاحين مسبقاً" else "All available friends are already invited",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        },
                        onAddFriendFromList = { friend ->
                            PlayerDirectoryService.addSearchedPlayerAsFriend(friend)
                            Toast.makeText(context, if (isRtl) "تمت إضافة ${friend.username} لقائمة أصدقائك!" else "Friend added!", Toast.LENGTH_SHORT).show()
                        },
                        isRtl = isRtl
                    )

                    // تبويب 1: البحث عن لاعبين عبر الـ ID الخاص بهم وإضافتهم
                    1 -> SearchPlayerByIdTab(
                        searchIdInput = searchIdInput,
                        onSearchInputChange = { searchIdInput = it },
                        searchResult = searchResult,
                        onPerformSearch = {
                            searchResult = PlayerDirectoryService.searchPlayerById(searchIdInput, currentProfile)
                        },
                        onAddFriend = { player ->
                            val ok = PlayerDirectoryService.addSearchedPlayerAsFriend(player)
                            if (ok) {
                                searchResult = PlayerSearchResult.AlreadyFriend(player.copy(isAlreadyFriend = true))
                                Toast.makeText(context, if (isRtl) "تمت إضافة ${player.username} كصديق بنجاح! 🎉" else "Friend added successfully!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        onInviteSearchedPlayer = { player ->
                            PlayerDirectoryService.inviteFriendToRound(player.playerId, roomCode)
                            onFriendInvited(player.playerId)
                            Toast.makeText(context, if (isRtl) "تم إرسال دعوة الجولة إلى ${player.username}!" else "Invited ${player.username}!", Toast.LENGTH_SHORT).show()
                        },
                        currentProfile = currentProfile,
                        isRtl = isRtl,
                        context = context
                    )
                }
            }
        }
    }
}

/**
 * تبويب قائمة الأصدقاء المتاحين لدعوتهم للجولات
 */
@Composable
private fun AvailableFriendsListTab(
    availableFriends: List<SearchedPlayerProfile>,
    onInviteFriend: (SearchedPlayerProfile) -> Unit,
    onInviteAll: () -> Unit,
    onAddFriendFromList: (SearchedPlayerProfile) -> Unit,
    isRtl: Boolean
) {
    val availableCount = availableFriends.count { it.inviteStatus == FriendInviteStatus.AVAILABLE && !it.isInvited }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 320.dp)
    ) {
        // شريط زر "دعوة الكل" مع إحصائيات التوافر
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (isRtl) "الأصدقاء الجاهزون للعب:" else "Friends Ready to Play:",
                    color = GoldLight,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }

            Button(
                onClick = onInviteAll,
                enabled = availableCount > 0,
                modifier = Modifier.height(28.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (availableCount > 0) Color(0xFF00C853) else Color.Gray
                ),
                shape = RoundedCornerShape(6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Mail,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isRtl) "دعوة الكل 🚀 ($availableCount)" else "Invite All ($availableCount)",
                        color = Color.Black,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (availableFriends.isEmpty()) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                shape = RoundedCornerShape(10.dp),
                color = SurfaceCardContainer,
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = "🎴", fontSize = 26.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isRtl) "لا يوجد أصدقاء في قائمتك حالياً" else "No friends in your list",
                        color = GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = if (isRtl) "استخدم تبويب 'بحث بالـ ID' للبحث عن أصدقائك وإضافتهم لتتمكن من دعوتهم للجولات بلمسة واحدة!" else "Use 'Search ID' tab to find and add friends to invite them!",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 9.5.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(availableFriends) { friend ->
                    FriendInviteCard(
                        friend = friend,
                        onInvite = { onInviteFriend(friend) },
                        onAddFriend = { onAddFriendFromList(friend) },
                        isRtl = isRtl
                    )
                }
            }
        }
    }
}

/**
 * بطاقة الصديق في قائمة الدعوة
 */
@Composable
private fun FriendInviteCard(
    friend: SearchedPlayerProfile,
    onInvite: () -> Unit,
    onAddFriend: () -> Unit,
    isRtl: Boolean
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        color = SurfaceCardContainer,
        border = BorderStroke(
            1.dp,
            when {
                friend.isInvited -> SuccessGreen
                friend.inviteStatus == FriendInviteStatus.AVAILABLE -> GoldLight.copy(alpha = 0.6f)
                else -> Color.White.copy(alpha = 0.15f)
            }
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = CircleShape,
                    color = FeltGreenDark,
                    border = BorderStroke(1.dp, GoldLight),
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(text = friend.avatarEmoji, fontSize = 18.sp)
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = friend.username,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = GoldDark.copy(alpha = 0.5f)
                        ) {
                            Text(
                                text = "Lvl ${friend.level}",
                                color = GoldLight,
                                fontSize = 7.5.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 3.dp, vertical = 0.5.dp)
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(
                                    when (friend.inviteStatus) {
                                        FriendInviteStatus.AVAILABLE -> SuccessGreen
                                        FriendInviteStatus.IN_ROUND -> Color(0xFFFFB300)
                                        FriendInviteStatus.OFFLINE -> Color.Gray
                                    }
                                )
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${friend.playerId} • ${friend.inviteStatus.titleArabic}",
                            color = when (friend.inviteStatus) {
                                FriendInviteStatus.AVAILABLE -> SuccessGreen
                                FriendInviteStatus.IN_ROUND -> Color(0xFFFFB300)
                                FriendInviteStatus.OFFLINE -> Color.Gray
                            },
                            fontSize = 9.sp
                        )
                    }
                }
            }

            // أزرار الإجراء: دعوة للجولة أو إضافة كصديق
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!friend.isAlreadyFriend) {
                    Button(
                        onClick = onAddFriend,
                        modifier = Modifier.height(28.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = FeltGreenDark),
                        border = BorderStroke(1.dp, GoldPrimary),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(text = if (isRtl) "+ صديق" else "+ Friend", color = GoldLight, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                }

                Button(
                    onClick = onInvite,
                    enabled = !friend.isInvited && friend.inviteStatus == FriendInviteStatus.AVAILABLE,
                    modifier = Modifier.height(28.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = when {
                            friend.isInvited -> Color(0xFF1B5E20)
                            friend.inviteStatus == FriendInviteStatus.AVAILABLE -> GoldPrimary
                            else -> Color.DarkGray
                        }
                    ),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (friend.isInvited) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(text = if (isRtl) "تمت الدعوة ✓" else "Invited ✓", color = Color.White, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.Send, contentDescription = null, tint = Color.Black, modifier = Modifier.size(11.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = when (friend.inviteStatus) {
                                    FriendInviteStatus.AVAILABLE -> if (isRtl) "دعوة للجولة 📨" else "Invite"
                                    FriendInviteStatus.IN_ROUND -> if (isRtl) "في جولة" else "In Round"
                                    FriendInviteStatus.OFFLINE -> if (isRtl) "غير متصل" else "Offline"
                                },
                                color = if (friend.inviteStatus == FriendInviteStatus.AVAILABLE) Color.Black else Color.LightGray,
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * تبويب البحث عن اللاعبين بالـ ID وإضافتهم
 */
@Composable
private fun SearchPlayerByIdTab(
    searchIdInput: String,
    onSearchInputChange: (String) -> Unit,
    searchResult: PlayerSearchResult?,
    onPerformSearch: () -> Unit,
    onAddFriend: (SearchedPlayerProfile) -> Unit,
    onInviteSearchedPlayer: (SearchedPlayerProfile) -> Unit,
    currentProfile: com.example.profile.UserProfile,
    isRtl: Boolean,
    context: Context
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 320.dp)
    ) {
        Text(
            text = if (isRtl) "ابحث عن اللاعب عبر معرفه الخاص (Player ID):" else "Search player by Player ID:",
            color = GoldLight,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(6.dp))

        // حقل إدخال الـ ID وزر البحث
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = searchIdInput,
                onValueChange = onSearchInputChange,
                placeholder = {
                    Text(
                        text = if (isRtl) "أدخل الـ ID (مثال: #TRB-9104 أو 5520)" else "e.g. #TRB-9104 or 5520",
                        fontSize = 10.5.sp,
                        color = Color.Gray
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp),
                singleLine = true,
                trailingIcon = {
                    if (searchIdInput.isNotEmpty()) {
                        IconButton(onClick = { onSearchInputChange("") }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Clear", tint = Color.Gray, modifier = Modifier.size(14.dp))
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldPrimary,
                    unfocusedBorderColor = GoldDark.copy(alpha = 0.6f),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )

            Spacer(modifier = Modifier.width(6.dp))

            Button(
                onClick = onPerformSearch,
                modifier = Modifier.height(44.dp),
                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.Black, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = if (isRtl) "بحث 🔍" else "Search", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // شريط معرف اللاعب الشخصي وزر النسخ واللصق من الحافظة
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = FeltGreenDark,
            border = BorderStroke(1.dp, GoldLight.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "🆔", fontSize = 13.sp)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${if (isRtl) "معرفك للمشاركة:" else "Your ID:"} ${currentProfile.playerId}",
                        color = GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("My ID", currentProfile.playerId))
                            Toast.makeText(context, if (isRtl) "تم نسخ معرفك لمشاركته مع أصدقائك!" else "ID copied!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.height(26.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(text = if (isRtl) "نسخ معرفي 📋" else "Copy My ID", color = Color.Black, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    Button(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clipText = clipboard.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
                            if (clipText.isNotBlank()) {
                                onSearchInputChange(clipText.trim())
                                onPerformSearch()
                            }
                        },
                        modifier = Modifier.height(26.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceCardContainer),
                        border = BorderStroke(0.8.dp, GoldLight),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(text = if (isRtl) "لصق ID 📥" else "Paste ID", color = GoldLight, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // عرض نتيجة البحث
        when (searchResult) {
            null -> {
                // حالة البداية: توجيه للاعب
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    shape = RoundedCornerShape(10.dp),
                    color = SurfaceCardContainer,
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f))
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "📱", fontSize = 24.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isRtl) "أصدقاء حقيقيون فقط بدون أي أسماء وهمية" else "Real Players Only",
                            color = GoldLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (isRtl) "اطلب من صديقك الذي حمّل اللعبة على هاتفه مشاركة الـ ID الخاص به، ثم الصقه بالأعلى للبحث عنه وإضافته فوراً لدعوته في الجولات!" else "Enter the ID of your friend who installed the game to add and invite them!",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 9.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            is PlayerSearchResult.IsSelf -> {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = FeltGreenDark,
                    border = BorderStroke(1.dp, GoldPrimary)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "👑", fontSize = 22.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isRtl) "هذا هو المعرف الخاص بك (${currentProfile.playerId})!" else "This is your own Player ID!",
                            color = GoldLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp
                        )
                        Text(
                            text = if (isRtl) "شاركه مع أصدقائك ليقوموا بالبحث عنك وإضافتك!" else "Share it with friends so they can add you!",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 9.5.sp
                        )
                    }
                }
            }

            is PlayerSearchResult.NotFound -> {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = DangerRed.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, DangerRed)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "❌", fontSize = 20.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isRtl) "لم يتم العثور على لاعب بالمعرف: ${searchResult.searchedId}" else "Player not found for ID: ${searchResult.searchedId}",
                            color = DangerRed,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                        Text(
                            text = if (isRtl) "تأكد من كتابة المعرف بالصيغة الصحيحة (مثال: #TRB-9104)" else "Make sure to enter valid ID like #TRB-9104",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 9.sp
                        )
                    }
                }
            }

            is PlayerSearchResult.Error -> {
                Text(text = searchResult.message, color = DangerRed, fontSize = 10.sp)
            }

            is PlayerSearchResult.Success -> {
                SearchedPlayerCard(
                    player = searchResult.player,
                    onAdd = { onAddFriend(searchResult.player) },
                    onInvite = { onInviteSearchedPlayer(searchResult.player) },
                    isRtl = isRtl
                )
            }

            is PlayerSearchResult.AlreadyFriend -> {
                SearchedPlayerCard(
                    player = searchResult.player,
                    onAdd = null, // already friend
                    onInvite = { onInviteSearchedPlayer(searchResult.player) },
                    isRtl = isRtl
                )
            }
        }
    }
}

/**
 * بطاقة نتيجة البحث عن لاعب
 */
@Composable
private fun SearchedPlayerCard(
    player: SearchedPlayerProfile,
    onAdd: (() -> Unit)?,
    onInvite: () -> Unit,
    isRtl: Boolean
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = SurfaceCardContainer,
        border = BorderStroke(1.5.dp, GoldPrimary)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = FeltGreenDark,
                        border = BorderStroke(1.dp, GoldPrimary),
                        modifier = Modifier.size(42.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(text = player.avatarEmoji, fontSize = 22.sp)
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = player.username,
                                color = GoldLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = GoldDark.copy(alpha = 0.5f)
                            ) {
                                Text(
                                    text = "Lvl ${player.level}",
                                    color = GoldLight,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Text(
                            text = "${player.playerId} • ${player.title}",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 10.sp
                        )
                        Text(
                            text = "${if (isRtl) "الانتصارات:" else "Wins:"} ${player.wins} • ${if (isRtl) "نسبة الفوز:" else "Winrate:"} ${player.winRate}%",
                            color = SuccessGreen,
                            fontSize = 9.sp
                        )
                    }
                }

                // حالة التوافر
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = when (player.inviteStatus) {
                        FriendInviteStatus.AVAILABLE -> SuccessGreen.copy(alpha = 0.2f)
                        FriendInviteStatus.IN_ROUND -> Color(0xFFFFB300).copy(alpha = 0.2f)
                        FriendInviteStatus.OFFLINE -> Color.Gray.copy(alpha = 0.2f)
                    },
                    border = BorderStroke(0.6.dp, when (player.inviteStatus) {
                        FriendInviteStatus.AVAILABLE -> SuccessGreen
                        FriendInviteStatus.IN_ROUND -> Color(0xFFFFB300)
                        FriendInviteStatus.OFFLINE -> Color.Gray
                    })
                ) {
                    Text(
                        text = player.inviteStatus.titleArabic,
                        color = when (player.inviteStatus) {
                            FriendInviteStatus.AVAILABLE -> SuccessGreen
                            FriendInviteStatus.IN_ROUND -> Color(0xFFFFB300)
                            FriendInviteStatus.OFFLINE -> Color.Gray
                        },
                        fontSize = 8.5.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // أزرار الإجراء
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (onAdd != null) {
                    Button(
                        onClick = onAdd,
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PersonAdd, contentDescription = null, tint = Color.Black, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = if (isRtl) "إضافة كصديق ➕" else "Add Friend", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        }
                    }
                } else {
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp),
                        shape = RoundedCornerShape(8.dp),
                        color = FeltGreenDark,
                        border = BorderStroke(1.dp, SuccessGreen)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(text = if (isRtl) "صديق مضاف بالفعل ✓" else "Already in Friends ✓", color = SuccessGreen, fontWeight = FontWeight.Bold, fontSize = 9.5.sp)
                        }
                    }
                }

                Button(
                    onClick = onInvite,
                    enabled = !player.isInvited,
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (player.isInvited) Color(0xFF1B5E20) else Color(0xFF0288D1)
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (player.isInvited) Icons.Default.Check else Icons.Default.Send,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (player.isInvited) (if (isRtl) "تمت الدعوة ✓" else "Invited") else (if (isRtl) "دعوة للجولة 📨" else "Invite to Match"),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}
