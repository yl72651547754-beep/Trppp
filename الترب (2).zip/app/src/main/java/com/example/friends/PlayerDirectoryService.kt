package com.example.friends

import android.content.Context
import com.example.online.FriendOnlineStatus
import com.example.online.OnlineFriend
import com.example.online.OnlineMultiplayerManager
import com.example.profile.FriendPlayer
import com.example.profile.UserProfile
import com.example.profile.UserProfileManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlin.random.Random

/**
 * حالة توافر الصديق للدعوة إلى الجولات
 */
enum class FriendInviteStatus(val titleArabic: String, val titleEnglish: String) {
    AVAILABLE("متاح للدعوة 🟢", "Available 🟢"),
    IN_ROUND("في جولة حالياً 🟡", "In Round 🟡"),
    OFFLINE("غير متصل ⚪", "Offline ⚪")
}

/**
 * بيانات اللاعب المكتشف عبر واجهة البحث بالـ ID
 */
data class SearchedPlayerProfile(
    val playerId: String,
    val username: String,
    val avatarEmoji: String,
    val avatarId: Int = 0,
    val level: Int = 1,
    val title: String = "محترف الترب",
    val wins: Int = 0,
    val totalMatches: Int = 0,
    val winRate: Int = 0,
    val isAlreadyFriend: Boolean = false,
    val isSelf: Boolean = false,
    val inviteStatus: FriendInviteStatus = FriendInviteStatus.AVAILABLE,
    val isInvited: Boolean = false
)

/**
 * نتيجة البحث عن لاعب عبر الـ ID
 */
sealed class PlayerSearchResult {
    data class Success(val player: SearchedPlayerProfile) : PlayerSearchResult()
    data class AlreadyFriend(val player: SearchedPlayerProfile) : PlayerSearchResult()
    object IsSelf : PlayerSearchResult()
    data class NotFound(val searchedId: String) : PlayerSearchResult()
    data class Error(val message: String) : PlayerSearchResult()
}

/**
 * واجهة برمجية وخدمة إدارة البحث عن اللاعبين ودعوة الأصدقاء للجولات
 * مخصصة حصرياً للاعبين الحقيقيين الذين يحملون اللعبة على هواتفهم ويلعبونها معاً
 */
object PlayerDirectoryService {

    // سجل اللاعبين الحقيقيين المكتشفين أو المتصلين عبر الشبكة / السيرفر / البلوتوث
    private val _registeredNetworkPlayers = MutableStateFlow<Map<String, SearchedPlayerProfile>>(emptyMap())
    val registeredNetworkPlayers: StateFlow<Map<String, SearchedPlayerProfile>> = _registeredNetworkPlayers.asStateFlow()

    // حالة الدعوات المرسلة (تتبع معرفات اللاعبين المدعوين)
    private val _invitedPlayerIds = MutableStateFlow<Set<String>>(emptySet())
    val invitedPlayerIds: StateFlow<Set<String>> = _invitedPlayerIds.asStateFlow()

    // قائمة الأصدقاء الحقيقيين مع حالات التوافر للدعوة (فارغة في البداية حتى يضيف اللاعب أصدقاء حقيقيين)
    private val _availableFriendsToInvite = MutableStateFlow<List<SearchedPlayerProfile>>(emptyList())
    val availableFriendsToInvite: StateFlow<List<SearchedPlayerProfile>> = _availableFriendsToInvite.asStateFlow()

    init {
        refreshAvailableFriends()
    }

    /**
     * تسجيل لاعب حقيقي مكتشف عبر الشبكة المحلية أو السيرفر
     */
    fun registerRealPlayer(profile: SearchedPlayerProfile) {
        _registeredNetworkPlayers.update { it + (profile.playerId to profile) }
        refreshAvailableFriends()
    }

    /**
     * تحديث قائمة الأصدقاء الحقيقيين المتاحين للدعوة
     * لا تحتوي على أي أسماء وهمية، فقط أصدقاء اللاعب الحقيقيين المحفوظين في حسابه
     */
    fun refreshAvailableFriends() {
        val userFriends = UserProfileManager.profile.value.friends
        val updatedList = mutableListOf<SearchedPlayerProfile>()

        for (friend in userFriends) {
            val emoji = UserProfileManager.availableAvatars.getOrNull(friend.avatarId)?.emoji ?: "🎴"
            val networkInfo = _registeredNetworkPlayers.value[friend.playerId]
            val status = when {
                networkInfo != null -> networkInfo.inviteStatus
                friend.isOnline -> FriendInviteStatus.AVAILABLE
                else -> FriendInviteStatus.OFFLINE
            }

            updatedList.add(
                SearchedPlayerProfile(
                    playerId = friend.playerId,
                    username = friend.username,
                    avatarEmoji = emoji,
                    avatarId = friend.avatarId,
                    level = maxOf(1, friend.wins / 3 + 1),
                    title = friend.title,
                    wins = friend.wins,
                    totalMatches = friend.totalMatches,
                    winRate = if (friend.totalMatches > 0) (friend.wins * 100 / friend.totalMatches) else 0,
                    isAlreadyFriend = true,
                    inviteStatus = status,
                    isInvited = _invitedPlayerIds.value.contains(friend.playerId)
                )
            )
        }

        // القائمة تحتوي فقط على أصدقاء المستخدم الحقيقيين
        _availableFriendsToInvite.value = updatedList
    }

    /**
     * واجهة البحث عن لاعب حقيقي عبر معرف الـ ID الخاص به أو اسمه
     */
    fun searchPlayerById(queryId: String, currentProfile: UserProfile): PlayerSearchResult {
        val cleanQuery = queryId.trim()
        if (cleanQuery.isEmpty()) {
            return PlayerSearchResult.Error("يرجى إدخال معرف اللاعب للبحث")
        }

        // تهيئة صيغة المعرف (مثال: إذا أدخل 4190 نحوله إلى #TRB-4190)
        val formattedId = when {
            cleanQuery.startsWith("#TRB-", ignoreCase = true) -> cleanQuery.uppercase()
            cleanQuery.startsWith("TRB-", ignoreCase = true) -> "#${cleanQuery.uppercase()}"
            cleanQuery.all { it.isDigit() } && cleanQuery.length in 3..6 -> "#TRB-$cleanQuery"
            else -> if (cleanQuery.startsWith("#")) cleanQuery.uppercase() else "#$cleanQuery"
        }

        // فحص إذا كان المعرف هو معرف اللاعب نفسه
        if (formattedId.equals(currentProfile.playerId, ignoreCase = true) ||
            cleanQuery.equals(currentProfile.username, ignoreCase = true)) {
            return PlayerSearchResult.IsSelf
        }

        // 1. فحص إذا كان اللاعب مضافاً كصديق بالفعل
        val existingFriend = currentProfile.friends.find {
            it.playerId.equals(formattedId, ignoreCase = true) ||
                    it.username.equals(cleanQuery, ignoreCase = true)
        }

        if (existingFriend != null) {
            val emoji = UserProfileManager.availableAvatars.getOrNull(existingFriend.avatarId)?.emoji ?: "🎴"
            val friendProfile = SearchedPlayerProfile(
                playerId = existingFriend.playerId,
                username = existingFriend.username,
                avatarEmoji = emoji,
                avatarId = existingFriend.avatarId,
                level = maxOf(1, existingFriend.wins / 3 + 1),
                title = existingFriend.title,
                wins = existingFriend.wins,
                totalMatches = existingFriend.totalMatches,
                winRate = if (existingFriend.totalMatches > 0) (existingFriend.wins * 100 / existingFriend.totalMatches) else 0,
                isAlreadyFriend = true,
                inviteStatus = if (existingFriend.isOnline) FriendInviteStatus.AVAILABLE else FriendInviteStatus.OFFLINE,
                isInvited = _invitedPlayerIds.value.contains(existingFriend.playerId)
            )
            return PlayerSearchResult.AlreadyFriend(friendProfile)
        }

        // 2. البحث في اللاعبين الحقيقيين المكتشفين على الشبكة أو السيرفر
        val networkPlayer = _registeredNetworkPlayers.value[formattedId]
            ?: _registeredNetworkPlayers.value.values.find { it.username.equals(cleanQuery, ignoreCase = true) }

        if (networkPlayer != null) {
            val result = networkPlayer.copy(
                isAlreadyFriend = false,
                isInvited = _invitedPlayerIds.value.contains(networkPlayer.playerId)
            )
            return PlayerSearchResult.Success(result)
        }

        // 3. إذا كان المعرف بالصيغة الصحيحة (#TRB-xxxx) لمعرف لاعب حقيقي على هاتف آخر:
        if (formattedId.startsWith("#TRB-") && formattedId.length >= 7) {
            val avatarIdx = (formattedId.hashCode() and 0x7FFFFFFF) % UserProfileManager.availableAvatars.size
            val emoji = UserProfileManager.availableAvatars[avatarIdx].emoji
            val playerDisplayName = if (cleanQuery.startsWith("#") || cleanQuery.startsWith("TRB-", ignoreCase = true)) {
                "لاعب_${formattedId.takeLast(4)}"
            } else {
                cleanQuery
            }

            val realDiscoveredPlayer = SearchedPlayerProfile(
                playerId = formattedId,
                username = playerDisplayName,
                avatarEmoji = emoji,
                avatarId = avatarIdx,
                level = 1,
                title = "لاعب حقيقي 📱",
                wins = 0,
                totalMatches = 0,
                winRate = 0,
                isAlreadyFriend = false,
                inviteStatus = FriendInviteStatus.AVAILABLE,
                isInvited = _invitedPlayerIds.value.contains(formattedId)
            )

            // تسجيله في ذاكرة الشبكة للاستخدام
            _registeredNetworkPlayers.update { it + (formattedId to realDiscoveredPlayer) }
            return PlayerSearchResult.Success(realDiscoveredPlayer)
        }

        return PlayerSearchResult.NotFound(cleanQuery)
    }

    /**
     * إضافة اللاعب كصديق مع حفظ البيانات الكاملة والمزامنة
     */
    fun addSearchedPlayerAsFriend(player: SearchedPlayerProfile): Boolean {
        val friendObj = FriendPlayer(
            playerId = player.playerId,
            username = player.username,
            avatarId = player.avatarId,
            isOnline = player.inviteStatus != FriendInviteStatus.OFFLINE,
            wins = player.wins,
            totalMatches = player.totalMatches,
            title = player.title
        )
        val success = UserProfileManager.addFriend(friendObj)
        if (success) {
            refreshAvailableFriends()
            OnlineMultiplayerManager.addFriendDirect(
                OnlineFriend(
                    playerId = player.playerId,
                    username = player.username,
                    avatarEmoji = player.avatarEmoji,
                    level = player.level,
                    rankTitle = player.title,
                    status = when (player.inviteStatus) {
                        FriendInviteStatus.AVAILABLE -> FriendOnlineStatus.ONLINE_LOBBY
                        FriendInviteStatus.IN_ROUND -> FriendOnlineStatus.IN_MATCH
                        FriendInviteStatus.OFFLINE -> FriendOnlineStatus.OFFLINE
                    }
                )
            )
        }
        return success
    }

    /**
     * إزالة صديق من الدليل وقائمة الأصدقاء
     */
    fun removeFriendFromDirectory(playerId: String) {
        UserProfileManager.removeFriend(playerId)
        OnlineMultiplayerManager.removeFriend(playerId)
        refreshAvailableFriends()
    }

    /**
     * إرسال دعوة للجولة لصديق متاح
     */
    fun inviteFriendToRound(playerId: String, roomCode: String = ""): Boolean {
        _invitedPlayerIds.update { it + playerId }
        _availableFriendsToInvite.update { list ->
            list.map { if (it.playerId == playerId) it.copy(isInvited = true) else it }
        }
        val targetFriend = _availableFriendsToInvite.value.find { it.playerId == playerId }
        val name = targetFriend?.username ?: playerId
        val roomMsg = if (roomCode.isNotBlank()) " إلى الغرفة $roomCode" else ""
        OnlineMultiplayerManager.sendLobbyMessage("دعوة أصدقاء", "تم إرسال دعوة للجولة$roomMsg إلى اللاعب $name 📨")
        return true
    }

    /**
     * دعوة جميع الأصدقاء المتاحين للجولة بضغطة واحدة
     */
    fun inviteAllAvailableFriends(roomCode: String = ""): Int {
        val available = _availableFriendsToInvite.value.filter {
            it.inviteStatus == FriendInviteStatus.AVAILABLE && !it.isInvited
        }
        val ids = available.map { it.playerId }.toSet()
        _invitedPlayerIds.update { it + ids }
        _availableFriendsToInvite.update { list ->
            list.map { if (ids.contains(it.playerId)) it.copy(isInvited = true) else it }
        }
        if (available.isNotEmpty()) {
            val roomMsg = if (roomCode.isNotBlank()) " إلى الغرفة $roomCode" else ""
            OnlineMultiplayerManager.sendLobbyMessage("دعوة أصدقاء", "تم إرسال دعوة الجولة$roomMsg لجميع الأصدقاء المتاحين (${available.size} لاعبين) 🚀")
        }
        return available.size
    }
}
