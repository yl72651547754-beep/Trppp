package com.example.audio

import android.content.Context
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.InputStream

/**
 * مدير الأصوات والمؤثرات الصوتية للعبة الترب (Sound Manager):
 * - تشغيل المؤثرات الصوتية للأحداث الرئيسية:
 *   1. توزيع الأوراق (Card Dealing): صوت خفق وتوزيع الأوراق الاحترافي السريع.
 *   2. المزايدة في المزاد (Auction Bids): رنين فيش كازينو/جرس مزاد رنان وواضح.
 *   3. الفوز بالجولة والمباراة (Winning Rounds): نغمة بوق نصر ملكية احتفالية فاخرة.
 *   4. أحداث مساعدة: لعب ورقة في الأكلة (Card Play)، كسب أكلة (Trick Win)، وخسارة الجولة.
 * - دعم كتم/تفعيل الصوت وحفظ الإعدادات في SharedPreferences.
 * - استخدام تشغيل PCM عبر AudioTrack عالي الأداء لتفادي أخطاء Codec2 وبرامج فك التشفير في المحاكيات
 *   (Zero-latency, no Codec2 component interface errors).
 */
class SoundManager private constructor(context: Context) {

    private val appContext = context.applicationContext
    private val prefs: SharedPreferences =
        appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _isSoundEnabled = MutableStateFlow(prefs.getBoolean(KEY_SOUND_ENABLED, true))
    val isSoundEnabled: StateFlow<Boolean> = _isSoundEnabled.asStateFlow()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // مسارات الصوت الثابتة المجهزة ببيانات PCM المباشرة
    private var soundDeal: PcmSound? = null
    private var soundBid: PcmSound? = null
    private var soundWinRound: PcmSound? = null
    private var soundLoseRound: PcmSound? = null
    private var soundCardPlay: PcmSound? = null
    private var soundTrickWin: PcmSound? = null

    init {
        // تحميل أصوات PCM في الخلفية دون حظر واجهة المستخدم
        scope.launch {
            loadAllSounds()
        }
    }

    private fun loadAllSounds() {
        try {
            soundDeal = loadPcmSound(R.raw.sfx_card_deal, voicesCount = 2)
            soundBid = loadPcmSound(R.raw.sfx_bid, voicesCount = 1)
            soundWinRound = loadPcmSound(R.raw.sfx_win_round, voicesCount = 1)
            soundLoseRound = loadPcmSound(R.raw.sfx_round_lose, voicesCount = 1)
            soundCardPlay = loadPcmSound(R.raw.sfx_card_play, voicesCount = 2)
            soundTrickWin = loadPcmSound(R.raw.sfx_trick_win, voicesCount = 1)
        } catch (e: Exception) {
            Log.e(TAG, "Error loading PCM sounds", e)
        }
    }

    private fun loadPcmSound(rawResId: Int, voicesCount: Int = 1): PcmSound? {
        return try {
            val stream: InputStream = appContext.resources.openRawResource(rawResId)
            val pcmBytes = extractPcmFromWav(stream)
            stream.close()
            if (pcmBytes.isNotEmpty()) {
                PcmSound(pcmBytes, voicesCount)
            } else null
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load sound raw resource $rawResId", e)
            null
        }
    }

    private fun extractPcmFromWav(inputStream: InputStream): ByteArray {
        val bytes = inputStream.readBytes()
        val dataTag = byteArrayOf('d'.code.toByte(), 'a'.code.toByte(), 't'.code.toByte(), 'a'.code.toByte())
        var dataIndex = -1
        for (i in 0 until bytes.size - 8) {
            if (bytes[i] == dataTag[0] && bytes[i + 1] == dataTag[1] &&
                bytes[i + 2] == dataTag[2] && bytes[i + 3] == dataTag[3]) {
                dataIndex = i + 8
                break
            }
        }
        return if (dataIndex in 0 until bytes.size) {
            bytes.copyOfRange(dataIndex, bytes.size)
        } else {
            if (bytes.size > 44) bytes.copyOfRange(44, bytes.size) else bytes
        }
    }

    private fun playSound(sound: PcmSound?, volume: Float = 1.0f) {
        if (!_isSoundEnabled.value || sound == null) return
        try {
            sound.play(volume)
        } catch (e: Exception) {
            Log.e(TAG, "Error playing sound", e)
        }
    }

    /**
     * صوت توزيع الأوراق في بداية الجولة
     */
    fun playCardDeal() {
        playSound(soundDeal, volume = 0.95f)
    }

    /**
     * صوت المزايدة في طور المزاد (Auction Bid)
     */
    fun playAuctionBid() {
        playSound(soundBid, volume = 0.90f)
    }

    /**
     * صوت الفوز بالجولة وتحقيق المزاد (Winning Round Fanfare)
     */
    fun playRoundWin() {
        playSound(soundWinRound, volume = 1.0f)
    }

    /**
     * صوت خسارة الجولة وتجاوز حد الـ 187 نقطة
     */
    fun playRoundLose() {
        playSound(soundLoseRound, volume = 0.85f)
    }

    /**
     * صوت رمي ورقة لعب على الطاولة
     */
    fun playCardPlay() {
        playSound(soundCardPlay, volume = 0.70f)
    }

    /**
     * صوت حصد الأكلة الفائزة
     */
    fun playTrickWin() {
        playSound(soundTrickWin, volume = 0.80f)
    }

    /**
     * تفعيل أو كتم الصوت وحفظ الخيار
     */
    fun toggleSound(): Boolean {
        val newState = !_isSoundEnabled.value
        setSoundEnabled(newState)
        return newState
    }

    fun setSoundEnabled(enabled: Boolean) {
        _isSoundEnabled.value = enabled
        prefs.edit().putBoolean(KEY_SOUND_ENABLED, enabled).apply()
        if (enabled) {
            playAuctionBid() // صوت تأكيدي سريع عند تشغيل الصوت
        }
    }

    fun release() {
        try {
            soundDeal?.release()
            soundBid?.release()
            soundWinRound?.release()
            soundLoseRound?.release()
            soundCardPlay?.release()
            soundTrickWin?.release()
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing sounds: ${e.message}")
        }
    }

    /**
     * مشغل صوتي خفيف الوزن يعتمد على AudioTrack بوضع MODE_STATIC
     * يتيح تعدد الأصوات المتزامنة بدون استهلاك معالجات الوسائط (No Codec2 / MediaCodec overhead)
     */
    private class PcmSound(private val pcmData: ByteArray, voicesCount: Int = 1) {
        private val tracks = Array(voicesCount.coerceAtLeast(1)) {
            createTrack(pcmData)
        }
        private var currentVoice = 0

        private fun createTrack(data: ByteArray): AudioTrack? {
            return try {
                val audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()

                val audioFormat = AudioFormat.Builder()
                    .setSampleRate(44100)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()

                AudioTrack.Builder()
                    .setAudioAttributes(audioAttributes)
                    .setAudioFormat(audioFormat)
                    .setBufferSizeInBytes(data.size)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build().apply {
                        write(data, 0, data.size)
                    }
            } catch (e: Exception) {
                Log.e("PcmSound", "Failed to build AudioTrack", e)
                null
            }
        }

        @Synchronized
        fun play(volume: Float) {
            val track = tracks[currentVoice % tracks.size] ?: return
            currentVoice++
            try {
                track.setVolume(volume.coerceIn(0f, 1f))
                if (track.playState == AudioTrack.PLAYSTATE_PLAYING) {
                    track.stop()
                }
                track.reloadStaticData()
                track.play()
            } catch (e: Exception) {
                Log.e("PcmSound", "Error playing AudioTrack voice", e)
            }
        }

        fun release() {
            for (track in tracks) {
                try {
                    track?.stop()
                    track?.release()
                } catch (_: Exception) {}
            }
        }
    }

    companion object {
        private const val TAG = "SoundManager"
        private const val PREFS_NAME = "tirb_sound_prefs"
        private const val KEY_SOUND_ENABLED = "sound_enabled"

        @Volatile
        private var instance: SoundManager? = null

        fun getInstance(context: Context): SoundManager {
            return instance ?: synchronized(this) {
                instance ?: SoundManager(context.applicationContext).also { instance = it }
            }
        }

        fun init(context: Context): SoundManager {
            return getInstance(context)
        }
    }
}
