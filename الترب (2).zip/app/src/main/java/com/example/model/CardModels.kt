package com.example.model

import com.example.localization.LocalizedStrings
import com.example.localization.getDisplayName
import com.example.localization.getLocalizedName
import com.example.localization.getLocalizedTitle

/**
 * 4 فئات (الترب): سبيك ♠، هتين ♥، ديمن ♦، كراول ♣
 * يعتبر الجوكر تابعاً لفئة الكراول
 */
enum class Suit(
    val arabicName: String,
    val symbol: String,
    val isRed: Boolean
) {
    SPADES("سبيك", "♠", false),
    HEARTS("هتين", "♥", true),
    DIAMONDS("ديمن", "♦", true),
    CLUBS("كراول", "♣", false);

    companion object {
        fun fromSymbol(symbol: String): Suit? = entries.find { it.symbol == symbol }
    }
}

/**
 * ترتيب قوة الأوراق ونقاطها الثابتة:
 * الأوراق المشاركة في اللعبة 10 أوراق فقط لكل فئة (40 ورقة إجمالاً):
 * 1. الرقم 2 - أقوى صنف ورق في الميدان واللعبة (25ن في الكراول "الجوكر"، و10ن في السبيك والهتين والديمن)
 * 2. الآس (اليكه) - 11ن
 * 3. الملك (الشايب) - 4ن
 * 4. الملكة (البنت) - 4ن
 * 5. الجاك/الولد (الغلام) - 4ن
 * 6. العشرة (10) - 10ن
 * 7. التسعة (9) - 0ن
 * 8. الثمانية (8) - 0ن
 * 9. السبعة (7) - 0ن
 * 10. الستة (6) - 0ن
 * المجموع الإجمالي الثابت = 187 نقطة
 */
enum class Rank(
    val power: Int,
    val arabicName: String,
    val label: String
) {
    TWO(16, "اثنان", "2"),
    ACE(13, "آس (يكه)", "A"),
    KING(12, "شايب", "K"),
    QUEEN(11, "بنت", "Q"),
    JACK(10, "غلام", "J"),
    TEN(9, "عشرة", "10"),
    NINE(8, "تسعة", "9"),
    EIGHT(7, "ثمانية", "8"),
    SEVEN(6, "سبعة", "7"),
    SIX(5, "ستة", "6"),
    JOKER_BIG(15, "جوكر كبير", "★"),
    JOKER_SMALL(14, "جوكر صغير", "☆"),
    FIVE(4, "خمسة", "5"),
    FOUR(3, "أربعة", "4"),
    THREE(2, "ثلاثة", "3");

    companion object {
        /**
         * الأوراق الـ 10 المشاركة فقط في اللعبة لكل فئة
         */
        val ACTIVE_RANKS = listOf(
            TWO, ACE, KING, QUEEN, JACK, TEN, NINE, EIGHT, SEVEN, SIX
        )
    }
}

data class Card(
    val id: String,
    val suit: Suit,
    val rank: Rank,
    val points: Int,
    val isJoker: Boolean = false
) {
    val shortLabel: String
        get() = when (rank) {
            Rank.JOKER_BIG, Rank.JOKER_SMALL -> "🃏"
            else -> rank.label
        }

    val displayTitleArabic: String
        get() = when (rank) {
            Rank.JOKER_BIG -> "جوكر كبير (0ن)"
            Rank.JOKER_SMALL -> "جوكر صغير (0ن)"
            Rank.TWO -> if (suit == Suit.CLUBS) "2 كراول (الجوكر - 25ن)" else "2 ${suit.arabicName} (10ن)"
            Rank.ACE -> "يكه ${suit.arabicName} (11ن)"
            Rank.KING -> "شايب ${suit.arabicName} (4ن)"
            Rank.QUEEN -> "بنت ${suit.arabicName} (4ن)"
            Rank.JACK -> "غلام ${suit.arabicName} (4ن)"
            Rank.TEN -> "10 ${suit.arabicName} (10ن)"
            else -> "${rank.label} ${suit.arabicName}"
        }
}

data class Player(
    val id: Int,
    val name: String,
    val isHuman: Boolean,
    val hand: List<Card> = emptyList(),
    val pointsWon: Int = 0,
    val tricksWon: Int = 0,
    val hasPassedAuction: Boolean = false,
    val currentBid: Int = 0,
    val redCards: Int = 0,
    val blackCards: Int = 0,
    val isRemoteFriend: Boolean = false
) {
    val isExemptFromAuction: Boolean
        get() = redCards >= 2

    val isEliminated: Boolean
        get() = blackCards >= 2
}

data class TrickPlay(
    val playerId: Int,
    val playerName: String,
    val card: Card
)

enum class GamePhase {
    INITIAL_DEAL,        // التوزيع الأولي: 7 لكل لاعب و 5 في الميدان
    AUCTION,             // المزاد من 100 إلى 187
    FIELD_DISTRIBUTION,  // الفائز يأخذ الميدان ويوزع الـ5 ورق (ورقة لكل لاعب)
    DECLARE_TRUMP,       // التصريح بنوع الترب
    TRICK_PLAYING,       // الـ 8 جولات
    GAME_OVER            // النتيجة النهائية وحكم القاعدة الذهبية
}

data class GameUIState(
    val phase: GamePhase = GamePhase.INITIAL_DEAL,
    val players: List<Player> = emptyList(),
    val dealerPlayerId: Int = 0,                       // موزع الأوراق الحالي
    val matchRoundNumber: Int = 1,                     // رقم الجولة في المباراة التراكمية
    val isMatchOver: Boolean = false,                  // هل انتهت اللعبة التنافسية بحصول شخص على كرتين سود
    val matchLoserPlayerId: Int? = null,               // اللاعب الخاسر (صاحب كرتين سود)
    val roundRedCardAwardedPlayerId: Int? = null,      // اللاعب الذي نال كرت أحمر هذه الجولة
    val roundBlackCardAwardedPlayerId: Int? = null,    // اللاعب الذي نال كرت أسود هذه الجولة
    val fieldCards: List<Card> = emptyList(),          // الـ 5 ورق الأصلية في الميدان
    val unassignedFieldCards: List<Card> = emptyList(),// الأوراق المتبقية للتوزيع
    val fieldAssignments: Map<Int, Card> = emptyMap(), // اللاعب -> الورقة الموزعة له
    val currentTurnPlayerId: Int = 0,
    val starterPlayerId: Int = 0,
    val auctionStarterPlayerId: Int = 0,               // من بدأ المزاد (يفتتح أول جولة لعب)
    val buyerId: Int? = null,
    val winningBid: Int = 100,
    val currentAuctionBid: Int = 100,
    val highestBidderId: Int? = null,
    val trumpSuit: Suit? = null,
    val currentRound: Int = 1,                         // 1 إلى 8
    val currentTrickCards: List<TrickPlay> = emptyList(),
    val leadingSuit: Suit? = null,
    val lastTrickWinnerId: Int? = null,
    val lastTrickPoints: Int = 0,
    val showLastTrickSummary: Boolean = false,
    val gameLog: List<String> = emptyList(),
    val logEntries: List<GameLogEntry> = emptyList(),
    val winnerCelebration: String? = null,
    val isAiThinking: Boolean = false,
    val selectedCardForDistribution: Card? = null,
    val playedCards: List<Card> = emptyList(),
    val isMultiplayerMode: Boolean = false,
    val localPlayerSeatId: Int = 0,
    val multiplayerRoomName: String = ""
) {
    val buyer: Player?
        get() = buyerId?.let { id -> players.find { it.id == id } }

    val dealer: Player?
        get() = players.find { it.id == dealerPlayerId }

    val opponentsTotalPoints: Int
        get() = players.filter { it.id != buyerId }.sumOf { it.pointsWon }

    val goldenSum: Int
        get() = opponentsTotalPoints + winningBid

    val isBuyerWinner: Boolean
        get() = goldenSum <= 187

    val humanPlayer: Player?
        get() = players.find { it.isHuman }
}

sealed class GameLogEntry {
    data class RoundDeal(val roundNum: Int, val dealerId: Int, val starterId: Int, val exemptIds: List<Int> = emptyList()) : GameLogEntry()
    object DealInitialInstructions : GameLogEntry()
    data class AuctionStarted(val starterId: Int) : GameLogEntry()
    data class BidRaised(val playerId: Int, val bid: Int) : GameLogEntry()
    data class BidMaxReached(val playerId: Int) : GameLogEntry()
    data class PlayerPassed(val playerId: Int) : GameLogEntry()
    data class AuctionWon(val buyerId: Int, val bid: Int) : GameLogEntry()
    data class FieldDistributed(val buyerId: Int) : GameLogEntry()
    data class TrumpDeclared(val buyerId: Int, val suit: Suit) : GameLogEntry()
    data class TrickStarted(val round: Int, val starterId: Int) : GameLogEntry()
    data class CardPlayed(val playerId: Int, val card: Card) : GameLogEntry()
    data class TrickWon(val winnerId: Int, val points: Int, val round: Int) : GameLogEntry()
    data class RoundWonBuyer(val buyerId: Int) : GameLogEntry()
    data class RoundLostBuyer(val buyerId: Int) : GameLogEntry()
    data class MatchOver(val loserId: Int) : GameLogEntry()
    data class QuickChat(val senderName: String, val text: String, val emoji: String) : GameLogEntry()
    data class SimpleMessage(val rawText: String) : GameLogEntry()

    fun format(strings: LocalizedStrings, players: List<Player>): String {
        fun playerName(id: Int): String = players.find { it.id == id }?.let {
            it.getDisplayName(strings)
        } ?: "Player $id"

        return when (this) {
            is RoundDeal -> {
                val dealer = playerName(dealerId)
                val starter = playerName(starterId)
                val exemptText = if (exemptIds.isNotEmpty()) " (${strings.exemptBadge})" else ""
                String.format(strings.logRoundStarted, roundNum, dealer, starter) + exemptText
            }
            is DealInitialInstructions -> strings.logDealInitialInstructions
            is AuctionStarted -> String.format(strings.logAuctionStarted, playerName(starterId))
            is BidRaised -> String.format(strings.logPlayerRaisedBid, playerName(playerId), bid)
            is BidMaxReached -> String.format(strings.logMaxBidReached, playerName(playerId))
            is PlayerPassed -> String.format(strings.logPlayerPassedBid, playerName(playerId))
            is AuctionWon -> String.format(strings.logPlayerWonAuction, playerName(buyerId), bid)
            is FieldDistributed -> String.format(strings.logFieldDistributed, playerName(buyerId))
            is TrumpDeclared -> {
                val suitName = suit.getLocalizedName(strings)
                String.format(strings.logTrumpDeclared, playerName(buyerId), suitName, suit.symbol)
            }
            is TrickStarted -> String.format(strings.logTrickStarted, round, playerName(starterId))
            is CardPlayed -> {
                val cardTitle = card.getLocalizedTitle(strings)
                String.format(strings.logCardPlayed, playerName(playerId), cardTitle)
            }
            is TrickWon -> String.format(strings.logTrickWon, playerName(winnerId), points, round)
            is RoundWonBuyer -> String.format(strings.logRoundWonBuyer, playerName(buyerId))
            is RoundLostBuyer -> String.format(strings.logRoundLostBuyer, playerName(buyerId))
            is MatchOver -> String.format(strings.matchLoserCardBanner, playerName(loserId))
            is QuickChat -> "$emoji $senderName: $text"
            is SimpleMessage -> rawText
        }
    }
}

