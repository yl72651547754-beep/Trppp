package com.example.leaderboard

import android.content.Context
import com.example.profile.UserProfile
import com.example.profile.UserProfileManager

/**
 * نموذج إحصائيات لوحة الصدارة الحقيقية 100% بدون أي أسماء وهمية
 */
data class LeaderboardPlayer(
    val rank: Int,
    val playerId: String,
    val username: String,
    val avatarEmoji: String,
    val title: String,
    val matchesWon: Int,
    val totalMatches: Int,
    val redCardsWon: Int,
    val goldenPoints: Int,
    val isCurrentUser: Boolean = false,
    val isAiBot: Boolean = false,
    val playStyle: String = ""
) {
    val winRate: Int
        get() = if (totalMatches > 0) ((matchesWon.toDouble() / totalMatches) * 100).toInt() else 0
}

/**
 * بيانات منافسي الذكاء الاصطناعي الأربعة على الطاولة
 */
data class TableRival(
    val id: Int,
    val name: String,
    val avatarEmoji: String,
    val roleTitle: String,
    val playStyle: String,
    val matchesWon: Int,
    val totalMatches: Int,
    val redCardsWon: Int
)

object LeaderboardRepository {
    private const val PREFS_RIVALS = "tirb_table_rivals_prefs"
    private const val KEY_RIVAL_MATCHES = "rival_matches_total"
    private const val KEY_WINS_PREFIX = "rival_wins_"
    private const val KEY_REDS_PREFIX = "rival_reds_"

    /**
     * استرجاع دوري أبطال الطاولة الحقيقي (المستخدم الحالي + أبطال الذكاء الاصطناعي الأربعة)
     * يتم ترتيبهم بناءً على عدد مرات الفوز الفعلية المحققة في اللعبة!
     */
    fun getTableRivalsLeaderboard(context: Context, currentUser: UserProfile): List<LeaderboardPlayer> {
        val prefs = context.getSharedPreferences(PREFS_RIVALS, Context.MODE_PRIVATE)

        // إحصائيات الخصوم الحقيقيين على الطاولة (تُحدث مع كل مباراة فعلية)
        val rivalsDefs = listOf(
            Triple(1, "سارة", "🦅") to Pair("حكيمة الترب", "لعب تكتيكي متوازن"),
            Triple(2, "فهد", "🦁") to Pair("قناص المزادات", "مزايد هجومي ومنافس شرس"),
            Triple(3, "نورة", "🌟") to Pair("حاصدة الكروت", "تركيز عالي على نقاط الأكلات"),
            Triple(4, "كريم", "🛡️") to Pair("المدافع الصلب", "دفاع حذر وإسقاط المشتري")
        )

        val rivalsList = rivalsDefs.map { (info, desc) ->
            val id = info.first
            val name = info.second
            val emoji = info.third
            val wins = prefs.getInt("$KEY_WINS_PREFIX$id", 0)
            val reds = prefs.getInt("$KEY_REDS_PREFIX$id", 0)
            val total = currentUser.totalMatches // يلعبون نفس عدد مباريات المستخدم

            LeaderboardPlayer(
                rank = 0,
                playerId = "#AI-0$id",
                username = name,
                avatarEmoji = emoji,
                title = desc.first,
                matchesWon = wins,
                totalMatches = total,
                redCardsWon = reds,
                goldenPoints = wins * 20 + reds * 10,
                isCurrentUser = false,
                isAiBot = true,
                playStyle = desc.second
            )
        }

        // بطاقة المستخدم الحقيقي
        val userEntry = LeaderboardPlayer(
            rank = 0,
            playerId = currentUser.playerId,
            username = currentUser.username,
            avatarEmoji = UserProfileManager.availableAvatars.getOrNull(currentUser.avatarId)?.emoji ?: "👑",
            title = currentUser.title,
            matchesWon = currentUser.wins,
            totalMatches = currentUser.totalMatches,
            redCardsWon = currentUser.redCardsWon,
            goldenPoints = currentUser.wins * 20 + currentUser.redCardsWon * 10,
            isCurrentUser = true,
            isAiBot = false,
            playStyle = "لاعب بشري (أنت)"
        )

        val combined = (rivalsList + userEntry).sortedWith(
            compareByDescending<LeaderboardPlayer> { it.matchesWon }
                .thenByDescending { it.redCardsWon }
                .thenByDescending { it.goldenPoints }
        )

        return combined.mapIndexed { index, player ->
            player.copy(rank = index + 1)
        }
    }

    /**
     * قائمة الأصدقاء الحقيقيين (المضافين يدويّاً أو عبر البلوتوث) + المستخدم الحالي
     */
    fun getFriendsLeaderboard(currentUser: UserProfile): List<LeaderboardPlayer> {
        val userEntry = LeaderboardPlayer(
            rank = 0,
            playerId = currentUser.playerId,
            username = currentUser.username,
            avatarEmoji = UserProfileManager.availableAvatars.getOrNull(currentUser.avatarId)?.emoji ?: "👑",
            title = currentUser.title,
            matchesWon = currentUser.wins,
            totalMatches = currentUser.totalMatches,
            redCardsWon = currentUser.redCardsWon,
            goldenPoints = currentUser.wins * 20 + currentUser.redCardsWon * 10,
            isCurrentUser = true,
            isAiBot = false,
            playStyle = "حسابك الشخصي"
        )

        val friendsEntries = currentUser.friends.map { f ->
            LeaderboardPlayer(
                rank = 0,
                playerId = f.playerId,
                username = f.username,
                avatarEmoji = UserProfileManager.availableAvatars.getOrNull(f.avatarId)?.emoji ?: "🃏",
                title = f.title,
                matchesWon = f.wins,
                totalMatches = f.totalMatches,
                redCardsWon = (f.wins * 0.9).toInt(),
                goldenPoints = f.wins * 20,
                isCurrentUser = false,
                isAiBot = false,
                playStyle = "صديق"
            )
        }

        val combined = (friendsEntries + userEntry).sortedWith(
            compareByDescending<LeaderboardPlayer> { it.matchesWon }
                .thenByDescending { it.redCardsWon }
        )
        return combined.mapIndexed { index, player ->
            player.copy(rank = index + 1)
        }
    }

    /**
     * تسجيل نتيجة مباراة حقيقية لمنافسي الذكاء الاصطناعي في الدوري المحلي
     */
    fun recordRivalMatchResult(context: Context, buyerId: Int, isBuyerWon: Boolean) {
        val prefs = context.getSharedPreferences(PREFS_RIVALS, Context.MODE_PRIVATE)
        val editor = prefs.edit()

        if (isBuyerWon) {
            // المشتري فاز ونال كرت أحمر
            if (buyerId in 1..4) {
                val currentWins = prefs.getInt("$KEY_WINS_PREFIX$buyerId", 0)
                val currentReds = prefs.getInt("$KEY_REDS_PREFIX$buyerId", 0)
                editor.putInt("$KEY_WINS_PREFIX$buyerId", currentWins + 1)
                editor.putInt("$KEY_REDS_PREFIX$buyerId", currentReds + 1)
            }
        } else {
            // المدافعون الأربعة أسقطوا المشتري
            for (defenderId in 1..4) {
                if (defenderId != buyerId) {
                    val currentWins = prefs.getInt("$KEY_WINS_PREFIX$defenderId", 0)
                    editor.putInt("$KEY_WINS_PREFIX$defenderId", currentWins + 1)
                }
            }
        }
        editor.apply()
    }
}
