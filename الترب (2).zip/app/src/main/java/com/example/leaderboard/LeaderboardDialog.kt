package com.example.leaderboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.localization.LocalizationManager
import com.example.profile.UserProfileManager
import com.example.online.CompetitiveMatchRecord
import com.example.online.FirestoreMatchmakingService
import androidx.compose.material.icons.filled.Public
import com.example.ui.theme.CardIvory
import com.example.ui.theme.DangerRed
import com.example.ui.theme.FeltGreenDark
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.JokerViolet
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuitRed
import com.example.ui.theme.SurfaceCardContainer
import com.example.ui.theme.SurfaceDarkNavy

@Composable
fun LeaderboardDialog(
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val profile by UserProfileManager.profile.collectAsState()
    val strings = LocalizationManager.strings.collectAsState().value
    val isRtl = LocalizationManager.currentLanguage.collectAsState().value.isRtl
    val competitiveRecords by FirestoreMatchmakingService.competitiveLeaderboard.collectAsState()

    // 0: سجل الأرقام القياسية (Hall of Fame), 1: دوري أبطال الطاولة (Table Rivals), 2: الأصدقاء (Friends), 3: مباريات الأونلاين (Online)
    var selectedTab by remember { mutableIntStateOf(0) }

    val tableRivals = remember(profile) {
        LeaderboardRepository.getTableRivalsLeaderboard(context, profile)
    }

    val friendsList = remember(profile) {
        LeaderboardRepository.getFriendsLeaderboard(profile)
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDarkNavy),
            border = BorderStroke(2.dp, GoldPrimary),
            elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = "Leaderboard",
                            tint = GoldPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isRtl) "لوحة الصدارة وسجل الشرف" else "Hall of Fame & Rivals",
                            color = GoldLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = strings.closeButton,
                            tint = GoldLight
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Banner Image
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(85.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .border(BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.6f)), RoundedCornerShape(12.dp))
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_leaderboard_banner),
                        contentDescription = "Leaderboard Trophy",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f))
                                )
                            )
                    )
                    Text(
                        text = if (isRtl) "🏆 سجل حقيقي وموثق لإنجازاتك ومنافسيك على الطاولة 🎴" else "🏆 Verified Match Records & Table Rivals League",
                        color = GoldLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 6.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Tabs: 3 logical tabs
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = FeltGreenDark,
                    contentColor = GoldLight,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = GoldPrimary,
                            height = 3.dp
                        )
                    }
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.MilitaryTech, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isRtl) "أرقامي القياسية" else "My Records",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.EmojiEvents, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isRtl) "دوري الطاولة" else "Table League",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.People, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isRtl) "الأصدقاء (${profile.friends.size})" else "Friends (${profile.friends.size})",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Public, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = if (isRtl) "🏆 الأونلاين" else "Online",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                when (selectedTab) {
                    0 -> PersonalRecordsTab(profile = profile, isRtl = isRtl)
                    1 -> TableRivalsTab(playersList = tableRivals, isRtl = isRtl)
                    2 -> FriendsTab(
                        friendsList = friendsList,
                        profile = profile,
                        isRtl = isRtl,
                        context = context
                    )
                    3 -> CompetitiveOnlineLeaderboardTab(
                        records = competitiveRecords,
                        isRtl = isRtl
                    )
                }
            }
        }
    }
}

/**
 * تبويب الأرقام القياسية الشخصية الحقيقية للاعب
 */
@Composable
private fun PersonalRecordsTab(
    profile: com.example.profile.UserProfile,
    isRtl: Boolean
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 280.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (profile.totalMatches == 0) {
            // حالة أولية نظيفة
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "🎴", fontSize = 36.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isRtl) "لم تقم بخوض أي مباراة بعد" else "No matches played yet",
                        color = GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = if (isRtl) "ابدأ جولتك الأولى لتسجيل رقمك القياسي وكسب الكروت الحمر!" else "Play your first round to record achievements!",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                item {
                    // شارة الرتبة والمستوى
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = GoldDark.copy(alpha = 0.35f),
                        border = BorderStroke(1.dp, GoldPrimary)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = "👑", fontSize = 20.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = "${profile.username} • ${profile.title}",
                                        color = GoldLight,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = "${if (isRtl) "معرف اللاعب" else "Player ID"}: ${profile.playerId}",
                                        color = Color.White.copy(alpha = 0.7f),
                                        fontSize = 10.sp
                                    )
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = FeltGreenDark,
                                border = BorderStroke(1.dp, GoldLight)
                            ) {
                                Text(
                                    text = "${if (isRtl) "مستوى" else "Lvl"} ${profile.level}",
                                    color = GoldLight,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }

                item {
                    // شبكة الإنجازات
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        RecordStatCard(
                            icon = "🎯",
                            title = if (isRtl) "أعلى مزاد ناجح" else "Highest Bid",
                            value = if (profile.highestBidWon > 0) "${profile.highestBidWon}" else "-",
                            color = GoldPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        RecordStatCard(
                            icon = "🔥",
                            title = if (isRtl) "أطول سلسلة فوز" else "Best Streak",
                            value = "${profile.bestStreak} ${if (isRtl) "انتصارات" else "W"}",
                            color = SuccessGreen,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        RecordStatCard(
                            icon = "🟥",
                            title = if (isRtl) "كروت حمر مكتسبة" else "Red Cards",
                            value = "${profile.redCardsWon}",
                            color = SuitRed,
                            modifier = Modifier.weight(1f)
                        )
                        RecordStatCard(
                            icon = "⬛",
                            title = if (isRtl) "كروت سود متفاداة" else "Black Avoided",
                            value = "${profile.blackCardsAvoided}",
                            color = Color(0xFF90CAF9),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        RecordStatCard(
                            icon = "🏆",
                            title = if (isRtl) "المباريات الملعوبة" else "Matches Played",
                            value = "${profile.totalMatches} (${profile.wins} ${if (isRtl) "فوز" else "W"})",
                            color = GoldLight,
                            modifier = Modifier.weight(1f)
                        )
                        RecordStatCard(
                            icon = "📊",
                            title = if (isRtl) "نسبة الفوز الحقيقية" else "True Win Rate",
                            value = "${profile.winRate}%",
                            color = SuccessGreen,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

/**
 * تبويب دوري أبطال الطاولة (المستخدم + الأربعة ذكاء اصطناعي فهد، سارة، نورة، كريم)
 */
@Composable
private fun TableRivalsTab(
    playersList: List<LeaderboardPlayer>,
    isRtl: Boolean
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 280.dp)
    ) {
        // Podium Top 3 (if matches played)
        val hasAnyWins = playersList.any { it.matchesWon > 0 }
        if (hasAnyWins && playersList.size >= 3) {
            val first = playersList[0]
            val second = playersList[1]
            val third = playersList[2]

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.Bottom
            ) {
                // 2nd Place Silver
                PodiumPlayerCard(
                    player = second,
                    medal = "🥈",
                    medalColor = Color(0xFFC0C0C0),
                    height = 84.dp,
                    modifier = Modifier.weight(1f)
                )

                Spacer(modifier = Modifier.width(6.dp))

                // 1st Place Gold
                PodiumPlayerCard(
                    player = first,
                    medal = "🥇",
                    medalColor = GoldPrimary,
                    height = 98.dp,
                    isFirst = true,
                    modifier = Modifier.weight(1.1f)
                )

                Spacer(modifier = Modifier.width(6.dp))

                // 3rd Place Bronze
                PodiumPlayerCard(
                    player = third,
                    medal = "🥉",
                    medalColor = Color(0xFFCD7F32),
                    height = 76.dp,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
        }

        // Rankings List
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(playersList) { player ->
                TableRivalRow(player = player, isRtl = isRtl)
            }
        }
    }
}

/**
 * تبويب الأصدقاء الحقيقيين
 */
@Composable
private fun FriendsTab(
    friendsList: List<LeaderboardPlayer>,
    profile: com.example.profile.UserProfile,
    isRtl: Boolean,
    context: Context
) {
    var friendInput by remember { mutableStateOf("") }
    var friendMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 280.dp)
    ) {
        // بطاقة معرف اللاعب الشخصي
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Tirb Player ID", profile.playerId))
                    Toast.makeText(context, if (isRtl) "تم نسخ المعرف: ${profile.playerId}" else "Copied ID: ${profile.playerId}", Toast.LENGTH_SHORT).show()
                },
            shape = RoundedCornerShape(10.dp),
            color = FeltGreenDark,
            border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.8f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "🆔", fontSize = 14.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${if (isRtl) "معرفك الفريد" else "Your ID"}: ${profile.playerId}",
                        color = GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (isRtl) "نسخ" else "Copy",
                        color = GoldPrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy",
                        tint = GoldPrimary,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // إدخال إضافة صديق
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = friendInput,
                onValueChange = { friendInput = it },
                placeholder = {
                    Text(
                        text = if (isRtl) "أدخل معرف الصديق (#TRB-...)" else "Enter Friend ID (#TRB-...)",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldPrimary,
                    unfocusedBorderColor = GoldDark.copy(alpha = 0.6f),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
            Spacer(modifier = Modifier.width(6.dp))
            Button(
                onClick = {
                    val ok = UserProfileManager.addFriend(friendInput)
                    if (ok) {
                        friendMessage = if (isRtl) "تمت إضافة الصديق بنجاح!" else "Friend added!"
                        friendInput = ""
                    } else {
                        friendMessage = if (isRtl) "المعرف موجود مسبقاً أو غير صالح" else "Invalid or exists"
                    }
                },
                modifier = Modifier.height(44.dp),
                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = "Add", tint = FeltGreenDark, modifier = Modifier.size(16.dp))
            }
        }

        friendMessage?.let { msg ->
            Text(
                text = msg,
                color = if (msg.contains("نجاح") || msg.contains("added")) SuccessGreen else DangerRed,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 2.dp)
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        if (profile.friends.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "👥", fontSize = 28.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isRtl) "لا يوجد أصدقاء مضافون بعد" else "No friends added yet",
                        color = GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = if (isRtl) "أضف رفقاءك بالمعرف أو تنافس معهم عبر البلوتوث المحلي!" else "Add by ID or play together via Bluetooth!",
                        color = Color.White.copy(alpha = 0.65f),
                        fontSize = 10.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(profile.friends) { friend ->
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        color = SurfaceCardContainer,
                        border = BorderStroke(1.dp, GoldDark.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = "🃏", fontSize = 16.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = friend.username,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = friend.playerId,
                                        color = GoldLight.copy(alpha = 0.8f),
                                        fontSize = 9.sp
                                    )
                                }
                            }
                            Text(
                                text = "${friend.wins} ${if (isRtl) "فوز" else "W"}",
                                color = GoldLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RecordStatCard(
    icon: String,
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = SurfaceCardContainer,
        border = BorderStroke(1.dp, color.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = icon, fontSize = 18.sp)
            Spacer(modifier = Modifier.width(6.dp))
            Column {
                Text(text = value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black)
                Text(text = title, color = GoldLight, fontSize = 9.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun TableRivalRow(
    player: LeaderboardPlayer,
    isRtl: Boolean
) {
    val isUser = player.isCurrentUser
    val rankBadge = when (player.rank) {
        1 -> "🥇"
        2 -> "🥈"
        3 -> "🥉"
        else -> "#${player.rank}"
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        color = if (isUser) GoldDark.copy(alpha = 0.35f) else SurfaceCardContainer,
        border = BorderStroke(if (isUser) 1.5.dp else 0.5.dp, if (isUser) GoldPrimary else Color.White.copy(alpha = 0.15f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = rankBadge,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = GoldLight,
                    modifier = Modifier.width(26.dp)
                )
                Text(text = player.avatarEmoji, fontSize = 16.sp)
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = player.username,
                            color = if (isUser) GoldLight else Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        if (player.isAiBot) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = FeltGreenDark
                            ) {
                                Text(
                                    text = if (isRtl) "ذكاء" else "AI",
                                    color = Color(0xFF81C784),
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }
                    Text(
                        text = player.title,
                        color = Color.White.copy(alpha = 0.65f),
                        fontSize = 9.sp
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (player.redCardsWon > 0) {
                    Text(
                        text = "🟥${player.redCardsWon}",
                        fontSize = 10.sp,
                        color = SuitRed,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(
                    text = "${player.matchesWon} ${if (isRtl) "فوز" else "W"}",
                    color = if (player.matchesWon > 0) GoldLight else Color.Gray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun PodiumPlayerCard(
    player: LeaderboardPlayer,
    medal: String,
    medalColor: Color,
    height: androidx.compose.ui.unit.Dp,
    isFirst: Boolean = false,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.height(height),
        shape = RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp, bottomStart = 6.dp, bottomEnd = 6.dp),
        color = if (player.isCurrentUser) GoldDark.copy(alpha = 0.35f) else SurfaceCardContainer,
        border = BorderStroke(if (isFirst) 2.dp else 1.dp, medalColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            Text(text = medal, fontSize = if (isFirst) 18.sp else 15.sp)
            Text(text = player.avatarEmoji, fontSize = if (isFirst) 18.sp else 15.sp)
            Text(
                text = player.username,
                color = if (player.isCurrentUser) GoldLight else Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                maxLines = 1
            )
            Text(
                text = "${player.matchesWon} فوز",
                color = medalColor,
                fontWeight = FontWeight.Black,
                fontSize = 10.sp
            )
        }
    }
}

/**
 * تبويب نتائج مباريات اللعب التنافسي الموثقة عبر الخادم وسجل الفائزين (Firestore & Cloud Run)
 */
@Composable
private fun CompetitiveOnlineLeaderboardTab(
    records: List<CompetitiveMatchRecord>,
    isRtl: Boolean
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 280.dp)
    ) {
        // شريط الحالة والمعلومات
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = FeltGreenDark,
            border = BorderStroke(0.8.dp, GoldLight.copy(alpha = 0.5f)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "🛡️", fontSize = 14.sp)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isRtl) "لوحة صدارة مباريات الأونلاين المعتمدة من الخادم الحاكم"
                    else "Authoritative Server Verified Match Results",
                    color = GoldLight,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        if (records.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "🌐", fontSize = 32.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isRtl) "لا توجد مباريات تنافسية مسجلة بعد" else "No competitive matches recorded yet",
                        color = GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Text(
                        text = if (isRtl) "أنشئ مباراة من تبويب التنافس وشارك رمز الدعوة لتسجيل اسمك هنا!"
                        else "Create a match in the compete tab to log results!",
                        color = Color.White.copy(alpha = 0.65f),
                        fontSize = 9.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(records) { record ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = SurfaceCardContainer,
                        border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = "👑", fontSize = 20.sp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = record.winnerName,
                                            color = GoldLight,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = FeltGreenDark
                                        ) {
                                            Text(
                                                text = record.matchId,
                                                color = GoldPrimary,
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = if (isRtl) "مزايدة الفوز: ${record.winningBid} نقطة" else "Winning Bid: ${record.winningBid} pts",
                                        color = Color.White.copy(alpha = 0.7f),
                                        fontSize = 8.5.sp
                                    )
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = DangerRed.copy(alpha = 0.25f),
                                    border = BorderStroke(0.6.dp, DangerRed)
                                ) {
                                    Text(
                                        text = if (isRtl) "🔴 فاز بكارتين حمر" else "2 Red Cards",
                                        color = DangerRed,
                                        fontSize = 8.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
